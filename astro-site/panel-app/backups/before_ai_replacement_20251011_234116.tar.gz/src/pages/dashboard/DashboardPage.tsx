/**
 * Dashboard Page - Ana Sayfa
 * Stitch AI Design Pattern
 * Müşteri Paneli
 */
import React, { useState } from 'react';
import { Calendar, ChevronDown } from 'lucide-react';
import KPICards from '../../components/dashboard/KPICards';
import TrendChart from '../../components/dashboard/TrendChart';
import AIPerformance from '../../components/dashboard/AIPerformance';
import AlertList from '../../components/dashboard/AlertList';
import ChannelDistribution from '../../components/dashboard/ChannelDistribution';
import TeamPerformance from '../../components/dashboard/TeamPerformance';

type DateRangeType = '24h' | '7d' | '30d' | '1y' | 'custom';

const DashboardPage: React.FC = () => {
  console.log('📈 DashboardPage rendering...');
  
  const [dateRange, setDateRange] = useState<DateRangeType>('7d');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  const dateRangeOptions = [
    { value: '24h', label: 'Son 24 Saat' },
    { value: '7d', label: 'Son 7 Gün' },
    { value: '30d', label: 'Son 30 Gün' },
    { value: '1y', label: 'Son 1 Yıl' },
    { value: 'custom', label: 'Özel Tarih' }
  ];

  const getDateRangeLabel = () => {
    if (dateRange === 'custom' && customStartDate && customEndDate) {
      return `${customStartDate} - ${customEndDate}`;
    }
    return dateRangeOptions.find(opt => opt.value === dateRange)?.label || 'Son 7 Gün';
  };

  const getDateRangeDescription = () => {
    switch (dateRange) {
      case '24h': return 'Son 24 saatin performansına genel bir bakış';
      case '7d': return 'Son 7 günün performansına genel bir bakış';
      case '30d': return 'Son 30 günün performansına genel bir bakış';
      case '1y': return 'Son 1 yılın performansına genel bir bakış';
      case 'custom': return 'Seçili tarih aralığının performansına genel bir bakış';
      default: return 'Bugünün performansına genel bir bakış';
    }
  };

  // Calculate dynamic values based on date range
  const getMultiplier = () => {
    switch (dateRange) {
      case '24h': return 0.15;
      case '7d': return 1;
      case '30d': return 4;
      case '1y': return 50;
      case 'custom': return 2;
      default: return 1;
    }
  };

  const multiplier = getMultiplier();
  const baseConversations = 125;
  const baseRevenue = 15000;

  const currentConversations = Math.round(baseConversations * multiplier);
  const currentRevenue = Math.round(baseRevenue * multiplier);
  
  return (
    <div className="flex flex-col w-full overflow-x-hidden">
      {/* Page Header with Date Range Filter */}
      <div className="flex flex-col sm:flex-row flex-wrap justify-between gap-3 p-2 sm:p-4">
        <div className="flex flex-col gap-2 sm:gap-3 min-w-0">
          <p className="text-[#0e131b] dark:text-gray-100 tracking-light text-2xl sm:text-[32px] font-bold leading-tight">Ana Sayfa</p>
          <p className="text-[#4d6a99] dark:text-gray-400 text-xs sm:text-sm font-normal leading-normal">{getDateRangeDescription()}</p>
        </div>
        
        {/* Date Range Selector */}
        <div className="relative">
          <button
            onClick={() => setShowDatePicker(!showDatePicker)}
            className="flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-600 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
          >
            <Calendar className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            <span className="font-medium text-gray-900 dark:text-gray-100">{getDateRangeLabel()}</span>
            <ChevronDown className="w-4 h-4 text-gray-600 dark:text-gray-400" />
          </button>

          {/* Date Range Dropdown */}
          {showDatePicker && (
            <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-600 rounded-xl shadow-lg z-10">
              <div className="p-2">
                {dateRangeOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => {
                      setDateRange(option.value as DateRangeType);
                      if (option.value !== 'custom') {
                        setShowDatePicker(false);
                      }
                    }}
                    className={`w-full text-left px-4 py-2.5 rounded-lg transition-colors ${
                      dateRange === option.value
                        ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 font-medium'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>

              {/* Custom Date Range Picker */}
              {dateRange === 'custom' && (
                <div className="border-t border-gray-200 dark:border-slate-600 p-4 space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Başlangıç Tarihi
                    </label>
                    <input
                      type="date"
                      value={customStartDate}
                      onChange={(e) => setCustomStartDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Bitiş Tarihi
                    </label>
                    <input
                      type="date"
                      value={customEndDate}
                      onChange={(e) => setCustomEndDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-gray-900 dark:text-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>
                  <button
                    onClick={() => {
                      if (customStartDate && customEndDate) {
                        setShowDatePicker(false);
                      } else {
                        alert('Lütfen başlangıç ve bitiş tarihlerini seçin');
                      }
                    }}
                    className="w-full px-4 py-2 bg-blue-600 dark:bg-blue-500 text-white rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors font-medium"
                  >
                    Uygula
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <KPICards dateRange={dateRange} />

      {/* Metrikler Section */}
      <h2 className="text-[#0e131b] dark:text-gray-100 text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
        Metrikler
      </h2>
      
      {/* Trend Charts */}
      <div className="flex flex-wrap gap-4 px-4 py-6">
        <TrendChart
          title="Gelir Trendleri"
          value={`₺${currentRevenue.toLocaleString('tr-TR')}`}
          subtitle={getDateRangeLabel()}
          change="+8%"
          dateRange={dateRange}
          type="revenue"
        />
        <TrendChart
          title="Konuşma Trendleri"
          value={currentConversations.toLocaleString('tr-TR')}
          subtitle={getDateRangeLabel()}
          change="+10%"
          dateRange={dateRange}
          type="conversation"
        />
      </div>

      {/* AI Performance */}
      <div className="flex flex-wrap gap-4 px-4 py-6">
        <AIPerformance dateRange={dateRange} />
      </div>

      {/* Son Uyarılar */}
      <h2 className="text-[#0e131b] dark:text-gray-100 text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
        Son Uyarılar
      </h2>
      <AlertList dateRange={dateRange} />

      {/* Kanal Dağılımı */}
      <h2 className="text-[#0e131b] dark:text-gray-100 text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
        Kanal Dağılımı
      </h2>
      <div className="flex flex-wrap gap-4 px-4 py-6">
        <ChannelDistribution dateRange={dateRange} />
      </div>

      {/* Ekip Performansı */}
      <h2 className="text-[#0e131b] dark:text-gray-100 text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
        Ekip Performansı
      </h2>
      <TeamPerformance dateRange={dateRange} />
    </div>
  );
};

export default DashboardPage;
