import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Search,
  Filter,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  AlertCircle,
  CheckCircle,
  Clock,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  Download,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { TenantBilling, TenantSubscription } from '../../types';
import CreateTenantModal, { TenantFormData } from '../../components/tenants/CreateTenantModal';

// Mock data - Backend'den gelecek
const mockTenants: TenantBilling[] = [
  {
    tenantId: '1',
    tenantName: 'Acme E-commerce',
    subscription: {
      plan: 'enterprise',
      status: 'active',
      currentPeriodStart: '2025-10-01',
      currentPeriodEnd: '2025-11-01',
      limits: { conversations: 10000, users: 50, storage: 500, apiCalls: 1000000 },
      usage: { conversations: 7500, users: 35, storage: 320, apiCalls: 750000 },
    },
    monthlyRevenue: 2500,
    totalRevenue: 25000,
    apiCosts: {
      llm: {
        provider: 'openai',
        totalCalls: 150000,
        totalTokens: 45000000,
        totalCost: 450,
        breakdown: {
          gpt4: { calls: 50000, tokens: 25000000, cost: 300 },
          gpt35: { calls: 80000, tokens: 15000000, cost: 120 },
          embedding: { calls: 20000, tokens: 5000000, cost: 30 },
        },
      },
      voice: { provider: 'elevenlabs', totalMinutes: 500, totalCost: 150 },
      whatsapp: { totalMessages: 25000, totalCost: 250 },
      storage: { totalGB: 320, totalCost: 32 },
      other: [],
      totalMonthlyCost: 882,
    },
    profitMargin: 64.7,
    paymentStatus: 'paid',
    lastPaymentDate: '2025-10-01',
    nextBillingDate: '2025-11-01',
    billingEmail: 'billing@acme.com',
  },
  {
    tenantId: '2',
    tenantName: 'TechStart SaaS',
    subscription: {
      plan: 'professional',
      status: 'active',
      currentPeriodStart: '2025-10-05',
      currentPeriodEnd: '2025-11-05',
      limits: { conversations: 5000, users: 20, storage: 200, apiCalls: 500000 },
      usage: { conversations: 3200, users: 15, storage: 120, apiCalls: 320000 },
    },
    monthlyRevenue: 999,
    totalRevenue: 5994,
    apiCosts: {
      llm: {
        provider: 'openai',
        totalCalls: 80000,
        totalTokens: 20000000,
        totalCost: 200,
        breakdown: {
          gpt4: { calls: 20000, tokens: 10000000, cost: 120 },
          gpt35: { calls: 50000, tokens: 8000000, cost: 64 },
          embedding: { calls: 10000, tokens: 2000000, cost: 16 },
        },
      },
      voice: { provider: 'azure', totalMinutes: 200, totalCost: 40 },
      whatsapp: { totalMessages: 10000, totalCost: 100 },
      storage: { totalGB: 120, totalCost: 12 },
      other: [],
      totalMonthlyCost: 352,
    },
    profitMargin: 64.8,
    paymentStatus: 'paid',
    lastPaymentDate: '2025-10-05',
    nextBillingDate: '2025-11-05',
    billingEmail: 'finance@techstart.io',
  },
  {
    tenantId: '3',
    tenantName: 'Fashion Boutique',
    subscription: {
      plan: 'starter',
      status: 'trial',
      currentPeriodStart: '2025-10-08',
      currentPeriodEnd: '2025-10-22',
      limits: { conversations: 1000, users: 5, storage: 50, apiCalls: 100000 },
      usage: { conversations: 450, users: 3, storage: 15, apiCalls: 45000 },
    },
    monthlyRevenue: 0,
    totalRevenue: 0,
    apiCosts: {
      llm: {
        provider: 'openai',
        totalCalls: 12000,
        totalTokens: 3000000,
        totalCost: 30,
        breakdown: {
          gpt4: { calls: 2000, tokens: 1000000, cost: 12 },
          gpt35: { calls: 8000, tokens: 1500000, cost: 12 },
          embedding: { calls: 2000, tokens: 500000, cost: 6 },
        },
      },
      voice: { provider: 'elevenlabs', totalMinutes: 50, totalCost: 15 },
      whatsapp: { totalMessages: 2000, totalCost: 20 },
      storage: { totalGB: 15, totalCost: 1.5 },
      other: [],
      totalMonthlyCost: 66.5,
    },
    profitMargin: -100,
    paymentStatus: 'pending',
    nextBillingDate: '2025-10-22',
    billingEmail: 'owner@fashionboutique.com',
  },
  {
    tenantId: '4',
    tenantName: 'HealthCare Plus',
    subscription: {
      plan: 'professional',
      status: 'past_due',
      currentPeriodStart: '2025-09-15',
      currentPeriodEnd: '2025-10-15',
      limits: { conversations: 5000, users: 20, storage: 200, apiCalls: 500000 },
      usage: { conversations: 4800, users: 18, storage: 180, apiCalls: 480000 },
    },
    monthlyRevenue: 999,
    totalRevenue: 8991,
    apiCosts: {
      llm: {
        provider: 'anthropic',
        totalCalls: 95000,
        totalTokens: 28000000,
        totalCost: 280,
        breakdown: {
          gpt4: { calls: 30000, tokens: 15000000, cost: 180 },
          gpt35: { calls: 55000, tokens: 10000000, cost: 80 },
          embedding: { calls: 10000, tokens: 3000000, cost: 20 },
        },
      },
      voice: { provider: 'google', totalMinutes: 300, totalCost: 60 },
      whatsapp: { totalMessages: 15000, totalCost: 150 },
      storage: { totalGB: 180, totalCost: 18 },
      other: [],
      totalMonthlyCost: 508,
    },
    profitMargin: 49.1,
    paymentStatus: 'overdue',
    lastPaymentDate: '2025-09-15',
    nextBillingDate: '2025-10-15',
    billingEmail: 'billing@healthcareplus.com',
  },
];

const TenantsPage: React.FC = () => {
  const [tenants] = useState<TenantBilling[]>(mockTenants);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'trial' | 'past_due'>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Filter tenants
  const filteredTenants = tenants.filter((tenant) => {
    const matchesSearch = tenant.tenantName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || tenant.subscription.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  // Calculate summary stats
  const totalRevenue = tenants.reduce((sum, t) => sum + t.monthlyRevenue, 0);
  const totalCosts = tenants.reduce((sum, t) => sum + t.apiCosts.totalMonthlyCost, 0);
  const totalProfit = totalRevenue - totalCosts;
  const avgProfitMargin = tenants.length > 0 
    ? tenants.reduce((sum, t) => sum + t.profitMargin, 0) / tenants.length 
    : 0;

  const getStatusBadge = (status: TenantSubscription['status']) => {
    const styles = {
      active: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
      trial: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
      past_due: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
      canceled: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400',
    };
    const labels = {
      active: 'Aktif',
      trial: 'Deneme',
      past_due: 'Gecikmiş',
      canceled: 'İptal',
    };
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  const getPlanBadge = (plan: TenantSubscription['plan']) => {
    const styles = {
      free: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
      starter: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
      professional: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
      enterprise: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
    };
    const labels = {
      free: 'Ücretsiz',
      starter: 'Başlangıç',
      professional: 'Profesyonel',
      enterprise: 'Kurumsal',
    };
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-lg ${styles[plan]}`}>
        {labels[plan]}
      </span>
    );
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">
            Firma Yönetimi
          </h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            Tüm müşteri firmalarınızı ve finansal durumlarını yönetin
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Yeni Firma Ekle</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Toplam Gelir</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">
                ${totalRevenue.toLocaleString()}
              </p>
            </div>
            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm text-green-600 dark:text-green-400">
            <TrendingUp className="w-4 h-4" />
            <span>+12.5% bu ay</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Toplam Maliyet</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">
                ${totalCosts.toLocaleString()}
              </p>
            </div>
            <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-lg">
              <TrendingDown className="w-6 h-6 text-red-600 dark:text-red-400" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm text-gray-600 dark:text-gray-400">
            <span>API + Altyapı</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Net Kar</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">
                ${totalProfit.toLocaleString()}
              </p>
            </div>
            <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
              <TrendingUp className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm text-blue-600 dark:text-blue-400">
            <span>{avgProfitMargin.toFixed(1)}% kar marjı</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Aktif Firmalar</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">
                {tenants.filter(t => t.subscription.status === 'active').length}
              </p>
            </div>
            <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
              <Users className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm text-gray-600 dark:text-gray-400">
            <span>/{tenants.length} toplam</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-4 border border-gray-200 dark:border-slate-700">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Firma ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
            />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
            >
              <option value="all">Tüm Durumlar</option>
              <option value="active">Aktif</option>
              <option value="trial">Deneme</option>
              <option value="past_due">Gecikmiş</option>
            </select>
          </div>

          {/* Export Button */}
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 text-gray-700 dark:text-gray-300 transition-colors">
            <Download className="w-5 h-5" />
            <span className="hidden sm:inline">Dışa Aktar</span>
          </button>
        </div>
      </div>

      {/* Tenants Table */}
      <div className="bg-white dark:bg-slate-800 rounded-lg border border-gray-200 dark:border-slate-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Firma
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Plan
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Durum
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Aylık Gelir
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  API Maliyeti
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Kar Marjı
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Ödeme
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  İşlemler
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-slate-700">
              {filteredTenants.map((tenant) => (
                <tr
                  key={tenant.tenantId}
                  className="hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                        <Building2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                          {tenant.tenantName}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          ID: {tenant.tenantId}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getPlanBadge(tenant.subscription.plan)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(tenant.subscription.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                      ${tenant.monthlyRevenue.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      ${tenant.totalRevenue.toLocaleString()} toplam
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                      ${tenant.apiCosts.totalMonthlyCost.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {tenant.apiCosts.llm.provider}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div
                      className={`text-sm font-medium ${
                        tenant.profitMargin > 0
                          ? 'text-green-600 dark:text-green-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {tenant.profitMargin > 0 ? '+' : ''}
                      {tenant.profitMargin.toFixed(1)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {tenant.paymentStatus === 'paid' && (
                        <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                      )}
                      {tenant.paymentStatus === 'pending' && (
                        <Clock className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                      )}
                      {tenant.paymentStatus === 'overdue' && (
                        <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                      )}
                      <span className="text-xs text-gray-600 dark:text-gray-400">
                        {tenant.paymentStatus === 'paid' && 'Ödendi'}
                        {tenant.paymentStatus === 'pending' && 'Bekliyor'}
                        {tenant.paymentStatus === 'overdue' && 'Gecikmiş'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Link
                        to={`/admin/tenants/${tenant.tenantId}`}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-slate-600 rounded-lg transition-colors"
                        title="Detayları Görüntüle"
                      >
                        <Eye className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                      </Link>
                      <button
                        className="p-2 hover:bg-gray-100 dark:hover:bg-slate-600 rounded-lg transition-colors"
                        title="Düzenle"
                      >
                        <Edit className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                      </button>
                      <button
                        className="p-2 hover:bg-gray-100 dark:hover:bg-slate-600 rounded-lg transition-colors"
                        title="Daha Fazla"
                      >
                        <MoreVertical className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredTenants.length === 0 && (
          <div className="text-center py-12">
            <Building2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Firma bulunamadı</p>
          </div>
        )}
      </div>

      {/* Create Tenant Modal */}
      <CreateTenantModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={(data: TenantFormData) => {
          console.log('New tenant data:', data);
          // TODO: Backend'e gönder
          alert('Firma başarıyla oluşturuldu! (Backend entegrasyonu yapılacak)');
        }}
      />
    </div>
  );
};

export default TenantsPage;

