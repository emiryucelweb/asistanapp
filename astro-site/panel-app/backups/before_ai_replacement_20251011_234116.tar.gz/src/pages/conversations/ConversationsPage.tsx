import React, { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Instagram, 
  Facebook, 
  Globe,
  Clock,
  Search,
  Filter,
  ChevronDown,
  User,
  Paperclip,
  Image,
  Video,
  FileText,
  X as XIcon,
  Send,
  Phone,
  Mail,
  ExternalLink,
  MapPin,
  AlertCircle,
  UserCheck,
  Bot as BotIcon,
  PhoneCall,
  Mic,
  Volume2,
  PhoneIncoming,
  PhoneMissed
} from 'lucide-react';

// WhatsApp icon component (Lucide doesn't have it, so we'll create a simple one)
const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
  </svg>
);

type Channel = 'instagram' | 'whatsapp' | 'facebook' | 'web' | 'phone';

interface Message {
  id: string;
  text: string;
  sender: 'customer' | 'agent';
  timestamp: Date;
  agentName?: string; // 'AI Asistan', 'Ahmet (Ekip)', 'Firma Sahibi' vs.
  attachments?: {
    type: 'image' | 'video' | 'file';
    name: string;
    url: string;
  }[];
  isVoiceTranscript?: boolean; // Sesli konuşmadan transkript mi?
  voiceDuration?: number; // Sesli mesaj süresi (saniye)
}

interface Conversation {
  id: string;
  channel: Channel;
  customerName: string;
  customerAvatar?: string;
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  messages: Message[];
  needsHelp: boolean; // AI tıkandı, insan yardımı gerekli
  assignedTo?: 'ai' | 'human'; // Kime atanmış
  assignedAgent?: string; // Hangi ekip üyesine atanmış
  aiStuckReason?: string; // AI neden tıkandı
  isLiveCall?: boolean; // Şu anda canlı arama var mı?
  isUrgent?: boolean; // Acil durum mu?
  callDuration?: number; // Arama süresi (saniye)
  customerProfile: {
    instagram?: {
      username: string;
      profileUrl: string;
    };
    whatsapp?: {
      phoneNumber: string;
    };
    facebook?: {
      name: string;
      profileUrl: string;
    };
    web?: {
      firstName: string;
      lastName: string;
      email: string;
      phoneNumber?: string;
    };
    phone?: {
      phoneNumber: string;
      callHistory?: {
        date: Date;
        duration: number;
        answeredBy: 'ai' | 'human' | 'missed';
      }[];
    };
  };
}

const channelIcons: Record<Channel, { icon: React.ReactNode; color: string; bg: string }> = {
  instagram: {
    icon: <Instagram className="w-5 h-5" />,
    color: 'text-pink-600',
    bg: 'bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500'
  },
  whatsapp: {
    icon: <WhatsAppIcon />,
    color: 'text-green-600',
    bg: 'bg-green-500'
  },
  facebook: {
    icon: <Facebook className="w-5 h-5" />,
    color: 'text-blue-600',
    bg: 'bg-blue-600'
  },
  web: {
    icon: <Globe className="w-5 h-5" />,
    color: 'text-orange-600',
    bg: 'bg-orange-500'
  },
  phone: {
    icon: <PhoneCall className="w-5 h-5" />,
    color: 'text-purple-600',
    bg: 'bg-gradient-to-br from-purple-500 to-purple-700'
  }
};

// Mock data generator
const generateMockConversations = (count: number, isActive: boolean): Conversation[] => {
  const channels: Channel[] = ['instagram', 'whatsapp', 'facebook', 'web', 'phone'];
  const names = [
    'Ayşe Yılmaz', 'Mehmet Kaya', 'Zeynep Demir', 'Ali Şahin', 
    'Fatma Öztürk', 'Ahmet Aydın', 'Elif Çelik', 'Mustafa Yıldız',
    'Hatice Arslan', 'İbrahim Koç', 'Emine Özkan', 'Hasan Erdoğan',
    'Merve Güneş', 'Yusuf Kılıç', 'Ayşegül Şimşek', 'Osman Polat'
  ];
  
  // Kanala göre gerçekçi mesajlar
  const messagesByChannel = {
    instagram: [
      'Merhaba, fiyat listesi paylaşabilir misiniz? 😊',
      'Dm\'den ulaşmak istedim, randevu alabilir miyim?',
      'Hikayenizde gördüğüm kampanya hala geçerli mi?',
      'Diş beyazlatma işlemi ne kadar sürer?',
      'Instagram\'dan yazıyorum, bugün için müsaitlik var mı?'
    ],
    whatsapp: [
      'Merhaba, yarın için randevu alabilir miyim?',
      'Dr. Ayşe Hanım\'dan randevu rica ediyorum',
      'Öğleden sonra müsaitlik var mı acaba?',
      'Geçen hafta başladığımız tedavinin devamı için gelmem gerekiyor',
      'Acil bir durumum var, bugün gelme şansım var mı?'
    ],
    facebook: [
      'Sayfanızı görüp yazmak istedim, fiyatlar hakkında bilgi alabilir miyim?',
      'Facebook\'tan yazdım, implant tedavisi için bilgi istiyorum',
      'Perşembe günü müsait saatleriniz var mı?',
      'Özel sigorta kabul ediyor musunuz?',
      'Sayfanızdaki kampanyayı görmek istiyorum'
    ],
    web: [
      'Web sitenizden randevu formunu doldurdum',
      'Site üzerinden bilgi almak istemiştim, geri dönüş bekliyorum',
      'Online randevu sisteminiz çok pratik, teşekkürler',
      'Formda belirttiğim tarih için onay alabilir miyim?',
      'Web sitenizdeki fiyat listesini inceledim, detaylı bilgi istiyorum'
    ],
    phone: [
      'Alo, merhaba. Randevu almak için arıyorum',
      'Bugün akşam saatlerinde müsaitlik var mı?',
      'Çocuğum için pedodontist randevusu istiyorum',
      'Acil bir diş ağrım var, bugün bakabilir misiniz?',
      'Kanal tedavisi yaptırmam gerekiyor, ne zaman gelebilirim?'
    ]
  };

  const conversations: Conversation[] = [];
  
  // Telefon konuşmaları için özel ağırlık - %20 telefon, %80 diğerleri
  const weightedChannels: Channel[] = [];
  channels.forEach(ch => {
    if (ch === 'phone') {
      weightedChannels.push(ch, ch); // 2x
    } else {
      weightedChannels.push(ch, ch, ch, ch); // 4x her biri
    }
  });
  
  for (let i = 0; i < count; i++) {
    const channel = weightedChannels[Math.floor(Math.random() * weightedChannels.length)];
    const name = names[Math.floor(Math.random() * names.length)];
    const channelMessages = messagesByChannel[channel];
    const lastMsg = channelMessages[Math.floor(Math.random() * channelMessages.length)];
    
    // Active conversations: last message within 30 minutes
    // Past conversations: last message older than 30 minutes
    const minutesAgo = isActive 
      ? Math.floor(Math.random() * 29) + 1  // 1-29 minutes ago
      : Math.floor(Math.random() * 1440) + 31; // 31 minutes to 24 hours ago
    
    const lastMessageTime = new Date(Date.now() - minutesAgo * 60 * 1000);
    
    // Generate realistic conversation messages
    const conversationMessages: Message[] = [];
    const agentNames = ['AI Asistan', 'Dr. Ayşe Yılmaz', 'Resepsiyonist Elif', 'Müşteri Temsilcisi'];
    
    // Telefon konuşmaları için sesli transkriptler
    const phoneTranscripts = [
      { customer: 'Merhaba, bugün için acil randevu alabilir miyim? Dişimde çok ağrı var.', agent: 'Merhaba, anlıyorum. Saat 15:30\'da bir yerimiz var, size uyar mı?' },
      { customer: 'Diş çekimi için geldim geçen hafta, kontrol randevusu almam gerekiyor.', agent: 'Tabii, sistemden bakıyorum. Yarın saat 14:00\'te müsait yerimiz var.' },
      { customer: 'Çocuğum için pedodontist randevusu istiyorum.', agent: 'Kaç yaşında çocuğunuz? Pedodontist doktorumuz Salı ve Perşembe günleri klinikte.' },
      { customer: 'Diş beyazlatma fiyatları hakkında bilgi alabilir miyim?', agent: 'Elbette. Office bleaching 3500 TL, home bleaching 2000 TL. Hangisi ilginizi çekiyor?' },
      { customer: 'İmplant tedavisi yaptırmak istiyorum, önce muayene gerekli mi?', agent: 'Evet, önce detaylı muayene ve röntgen çekeceğiz. Ücretsiz konsültasyon randevusu verebilirim.' }
    ];
    
    const webResponses = [
      { customer: 'Web sitenizden randevu formu gönderdim', agent: 'Formunuzu aldık, teşekkürler. Sizin için en uygun tarih 24 Mayıs Çarşamba 10:00. Onaylıyor musunuz?' },
      { customer: 'Online ödeme yapabilir miyim?', agent: 'Evet, web sitemizden güvenli ödeme yapabilirsiniz. Randevunuzdan sonra SMS ile link göndereceğiz.' },
      { customer: 'Kampanyanız hala geçerli mi?', agent: 'Evet, diş taşı temizliği + polish kampanyamız 31 Mayıs\'a kadar geçerli. 750 TL yerine 500 TL.' }
    ];
    
    const generalResponses = [
      { customer: 'Randevu saatimi değiştirebilir miyim?', agent: 'Tabii ki. Hangi tarih size daha uygun?' },
      { customer: 'Sigorta kabul ediyor musunuz?', agent: 'Evet, SGK ve tüm özel sigortalarla çalışıyoruz. Sigorta bilgilerinizi randevuya gelirken getirin lütfen.' },
      { customer: 'Teşekkür ederim, yarın görüşürüz.', agent: 'Rica ederim, yarın görüşmek üzere. İyi günler! 😊' },
      { customer: 'Ağrı kesici yazmıştınız, çok iyi geldi.', agent: 'Harika! Ağrınız geçtiyse yarın kontrole gelin. Geçmiş olsun.' }
    ];
    
    if (channel === 'phone') {
      // Telefon konuşması - sesli transkript
      const transcript = phoneTranscripts[Math.floor(Math.random() * phoneTranscripts.length)];
      const callDur = Math.floor(Math.random() * 180) + 60; // 60-240 saniye
      
      conversationMessages.push(
        {
          id: `msg-${i}-0`,
          text: transcript.customer,
          sender: 'customer',
          timestamp: new Date(lastMessageTime.getTime() - 3 * 60 * 1000),
          isVoiceTranscript: true,
          voiceDuration: Math.floor(callDur * 0.4)
        },
        {
          id: `msg-${i}-1`,
          text: transcript.agent,
          sender: 'agent',
          timestamp: new Date(lastMessageTime.getTime() - 2 * 60 * 1000),
          agentName: agentNames[Math.floor(Math.random() * (agentNames.length - 1)) + 1], // AI Asistan hariç
          isVoiceTranscript: true,
          voiceDuration: Math.floor(callDur * 0.6)
        }
      );
    } else if (channel === 'web') {
      // Web widget konuşması
      const webConv = webResponses[Math.floor(Math.random() * webResponses.length)];
      conversationMessages.push(
        {
          id: `msg-${i}-0`,
          text: webConv.customer,
          sender: 'customer',
          timestamp: new Date(lastMessageTime.getTime() - 10 * 60 * 1000)
        },
        {
          id: `msg-${i}-1`,
          text: webConv.agent,
          sender: 'agent',
          timestamp: new Date(lastMessageTime.getTime() - 2 * 60 * 1000),
          agentName: 'AI Asistan'
        }
      );
    } else {
      // Diğer kanallar için normal mesajlaşma
      const convTemplate = generalResponses[Math.floor(Math.random() * generalResponses.length)];
      
      // 3-5 mesaj arası
      const msgCount = Math.floor(Math.random() * 3) + 3;
      for (let j = 0; j < msgCount; j++) {
        const isCustomer = j % 2 === 0;
        let msgText;
        
        if (j === 0) {
          msgText = channelMessages[Math.floor(Math.random() * channelMessages.length)];
        } else if (j === msgCount - 1) {
          msgText = isCustomer ? convTemplate.customer : convTemplate.agent;
        } else {
          msgText = isCustomer 
            ? channelMessages[Math.floor(Math.random() * channelMessages.length)]
            : generalResponses[Math.floor(Math.random() * generalResponses.length)].agent;
        }
        
        conversationMessages.push({
          id: `msg-${i}-${j}`,
          text: msgText,
          sender: isCustomer ? 'customer' : 'agent',
          timestamp: new Date(lastMessageTime.getTime() - (msgCount - j) * 3 * 60 * 1000),
          agentName: isCustomer ? undefined : (Math.random() > 0.5 ? 'AI Asistan' : agentNames[Math.floor(Math.random() * (agentNames.length - 1)) + 1])
        });
      }
    }
    
    // Generate customer profile data based on channel
    let customerProfile: Conversation['customerProfile'] = {};
    
    if (channel === 'instagram') {
      customerProfile.instagram = {
        username: `@${name.toLowerCase().replace(/\s+/g, '_')}`,
        profileUrl: `https://instagram.com/${name.toLowerCase().replace(/\s+/g, '_')}`
      };
    } else if (channel === 'whatsapp') {
      customerProfile.whatsapp = {
        phoneNumber: `+90 5${Math.floor(Math.random() * 9)}${Math.floor(Math.random() * 9)} ${Math.floor(100 + Math.random() * 900)} ${Math.floor(10 + Math.random() * 90)} ${Math.floor(10 + Math.random() * 90)}`
      };
    } else if (channel === 'facebook') {
      customerProfile.facebook = {
        name: name,
        profileUrl: `https://facebook.com/${name.toLowerCase().replace(/\s+/g, '.')}`
      };
    } else if (channel === 'web') {
      const nameParts = name.split(' ');
      customerProfile.web = {
        firstName: nameParts[0] || '',
        lastName: nameParts.slice(1).join(' ') || '',
        email: `${name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
        phoneNumber: Math.random() > 0.3 ? `+90 5${Math.floor(Math.random() * 9)}${Math.floor(Math.random() * 9)} ${Math.floor(100 + Math.random() * 900)} ${Math.floor(10 + Math.random() * 90)} ${Math.floor(10 + Math.random() * 90)}` : undefined
      };
    } else if (channel === 'phone') {
      customerProfile.phone = {
        phoneNumber: `+90 5${Math.floor(Math.random() * 9)}${Math.floor(Math.random() * 9)} ${Math.floor(100 + Math.random() * 900)} ${Math.floor(10 + Math.random() * 90)} ${Math.floor(10 + Math.random() * 90)}`,
        callHistory: []
      };
    }
    
    // Randomly assign some conversations as needing help (AI stuck)
    let needsHelp = Math.random() > 0.75; // 25% chance AI needs help
    const aiStuckReasons = [
      'Müşteri kompleks implant tedavisi hakkında detaylı bilgi istiyor',
      'Özel fiyat teklifi ve taksit seçenekleri konusunda yetkim yok',
      'İptal edilen randevunun iadesini talep ediyor',
      'Tedavi sonrası komplikasyon şikayeti - doktor müdahalesi gerekli',
      'Sigorta geri ödemesi için özel form doldurmak istiyor',
      'Başka klinikte başlanan tedaviyi devam ettirmek istiyor'
    ];
    
    // Sesli aramalar için özel durumlar
    const isLiveCall = channel === 'phone' && isActive && Math.random() > 0.85; // 15% şans canlı arama
    const isUrgent = isLiveCall && Math.random() > 0.7; // Canlı aramaların %30'u acil
    const callDuration = isLiveCall ? Math.floor(Math.random() * 240) + 45 : undefined; // 45-285 saniye
    
    // Acil aramalar otomatik olarak yardım gerektirir
    if (isUrgent) {
      needsHelp = true;
    }
    
    conversations.push({
      id: `conv-${i}`,
      channel,
      customerName: name,
      customerAvatar: undefined,
      lastMessage: lastMsg,
      lastMessageTime,
      unreadCount: isActive ? Math.floor(Math.random() * 5) : 0,
      messages: conversationMessages,
      customerProfile,
      needsHelp,
      assignedTo: needsHelp ? 'human' : 'ai',
      assignedAgent: needsHelp ? ['Ahmet', 'Ayşe', 'Mehmet'][Math.floor(Math.random() * 3)] : undefined,
      aiStuckReason: needsHelp ? aiStuckReasons[Math.floor(Math.random() * aiStuckReasons.length)] : undefined,
      isLiveCall,
      isUrgent,
      callDuration
    });
  }
  
  return conversations.sort((a, b) => b.lastMessageTime.getTime() - a.lastMessageTime.getTime());
};

const ConversationsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'active' | 'past' | 'phone'>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChannel, setSelectedChannel] = useState<Channel | 'all'>('all');
  const [filterNeedsHelp, setFilterNeedsHelp] = useState(false); // Filter for AI stuck conversations
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  
  // Active conversations - load all at once
  const [activeConversations, setActiveConversations] = useState<Conversation[]>([]);
  
  // Past conversations - load 20 at a time
  const [pastConversations, setPastConversations] = useState<Conversation[]>([]);
  const [pastPage, setPastPage] = useState(1);
  const [hasMorePast, setHasMorePast] = useState(true);
  const PAST_PAGE_SIZE = 20;
  
  useEffect(() => {
    // Load active conversations (all at once)
    const active = generateMockConversations(15, true);
    setActiveConversations(active);
    
    // Load first page of past conversations
    const past = generateMockConversations(50, false);
    setPastConversations(past.slice(0, PAST_PAGE_SIZE));
    setHasMorePast(past.length > PAST_PAGE_SIZE);
  }, []);
  
  const loadMorePast = () => {
    // Simulate loading more past conversations
    const allPast = generateMockConversations(50, false);
    const nextPage = pastPage + 1;
    const startIdx = pastPage * PAST_PAGE_SIZE;
    const endIdx = nextPage * PAST_PAGE_SIZE;
    
    setPastConversations(prev => [...prev, ...allPast.slice(startIdx, endIdx)]);
    setPastPage(nextPage);
    setHasMorePast(endIdx < allPast.length);
  };
  
  const getFilteredConversations = () => {
    let conversations: Conversation[] = [];
    
    if (activeTab === 'phone') {
      // Telefon konuşmaları - tüm telefonları göster (aktif + geçmiş)
      conversations = [...activeConversations, ...pastConversations].filter(c => c.channel === 'phone');
    } else {
      conversations = activeTab === 'active' ? activeConversations : pastConversations;
    }
    
    return conversations.filter(conv => {
      const matchesSearch = conv.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          conv.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesChannel = selectedChannel === 'all' || conv.channel === selectedChannel;
      const matchesNeedsHelp = !filterNeedsHelp || conv.needsHelp;
      
      // Telefon tab'ındayken kanal filtresini atlıyoruz
      if (activeTab === 'phone') {
        return matchesSearch && matchesNeedsHelp;
      }
      
      return matchesSearch && matchesChannel && matchesNeedsHelp;
    });
  };
  
  const handleTransferToHuman = () => {
    if (!selectedConversation) return;
    
    // TODO: API call to transfer conversation to human
    console.log('Transferring conversation to human:', selectedConversation.id);
    
    // Update local state
    if (activeTab === 'active') {
      setActiveConversations(prev => 
        prev.map(conv => 
          conv.id === selectedConversation.id 
            ? { ...conv, assignedTo: 'human' as const, needsHelp: true }
            : conv
        )
      );
    }
  };
  
  const handleTransferToAI = () => {
    if (!selectedConversation) return;
    
    // TODO: API call to transfer conversation back to AI
    console.log('Transferring conversation back to AI:', selectedConversation.id);
    
    // Update local state
    if (activeTab === 'active') {
      setActiveConversations(prev => 
        prev.map(conv => 
          conv.id === selectedConversation.id 
            ? { ...conv, assignedTo: 'ai' as const, needsHelp: false }
            : conv
        )
      );
    }
  };
  
  const formatTime = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Şimdi';
    if (diffMins < 60) return `${diffMins} dk önce`;
    if (diffHours < 24) return `${diffHours} saat önce`;
    if (diffDays < 7) return `${diffDays} gün önce`;
    
    return date.toLocaleDateString('tr-TR', { day: '2-digit', month: 'short' });
  };
  
  const handleFileSelect = (type: 'image' | 'video' | 'file') => {
    const input = document.createElement('input');
    input.type = 'file';
    
    if (type === 'image') {
      input.accept = 'image/*';
    } else if (type === 'video') {
      input.accept = 'video/*';
    } else {
      input.accept = '*/*';
    }
    
    input.multiple = true;
    input.onchange = (e) => {
      const files = Array.from((e.target as HTMLInputElement).files || []);
      setAttachments(prev => [...prev, ...files]);
      setShowAttachmentMenu(false);
    };
    
    input.click();
  };
  
  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };
  
  const handleSendMessage = () => {
    if (!messageInput.trim() && attachments.length === 0) return;
    
    // TODO: API call to send message
    console.log('Sending message:', { text: messageInput, attachments });
    
    setMessageInput('');
    setAttachments([]);
  };
  
  const filteredConversations = getFilteredConversations();
  const needsHelpCount = (activeTab === 'active' ? activeConversations : pastConversations).filter(c => c.needsHelp).length;
  const phoneCallsCount = [...activeConversations, ...pastConversations].filter(c => c.channel === 'phone').length;
  const liveCallsCount = activeConversations.filter(c => c.isLiveCall).length;
  const urgentCallsCount = activeConversations.filter(c => c.isUrgent).length;
  
  const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700">
        <div className="px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4 sm:mb-6">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">Konuşmalar</h1>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">Tüm kanallardan gelen mesajları yönetin</p>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Acil Aramalar Alert */}
              {urgentCallsCount > 0 && (
                <div className="flex items-center gap-2 px-4 py-2 bg-red-50 border-2 border-red-300 rounded-lg animate-pulse">
                  <PhoneCall className="w-4 h-4 text-red-600 animate-bounce" />
                  <span className="text-sm font-bold text-red-900">
                    {urgentCallsCount} ACİL ARAMA!
                  </span>
                </div>
              )}
              
              {/* Canlı Aramalar */}
              {liveCallsCount > 0 && (
                <div className="flex items-center gap-2 px-4 py-2 bg-purple-50 border border-purple-200 rounded-lg">
                  <PhoneIncoming className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-purple-900">
                    {liveCallsCount} canlı arama
                  </span>
                </div>
              )}
              
              {/* Yardım Bekleyenler */}
              {needsHelpCount > 0 && !urgentCallsCount && (
                <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200 rounded-lg">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-900">
                    {needsHelpCount} konuşma yardım bekliyor
                  </span>
                </div>
              )}
            </div>
          </div>
          
          {/* Search and Channel Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Konuşmalarda ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 sm:pl-10 pr-4 py-2 sm:py-2.5 text-sm bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
              />
            </div>
            
            {/* Channel Filter */}
            <div className="flex items-center gap-1 sm:gap-2 bg-gray-50 dark:bg-slate-900 p-1 rounded-lg border border-gray-200 dark:border-slate-700 overflow-x-auto">
              <button
                onClick={() => setSelectedChannel('all')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  selectedChannel === 'all'
                    ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
                }`}
              >
                Tümü
              </button>
              {(Object.keys(channelIcons) as Channel[]).map((channel) => (
                <button
                  key={channel}
                  onClick={() => setSelectedChannel(channel)}
                  className={`p-2 rounded-md transition-colors ${
                    selectedChannel === channel
                      ? `${channelIcons[channel].color} bg-white dark:bg-slate-800 shadow-sm`
                      : 'text-gray-400 hover:text-gray-600 dark:text-gray-400'
                  }`}
                  title={channel}
                >
                  {channelIcons[channel].icon}
                </button>
              ))}
            </div>
          </div>
          
          {/* Tabs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 mt-4 sm:mt-6">
            <div className="flex items-center gap-1 bg-gray-100 dark:bg-slate-700 p-1 rounded-lg overflow-x-auto">
              <button
                onClick={() => setActiveTab('active')}
                className={`px-3 sm:px-6 py-2 rounded-md text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === 'active'
                    ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
                }`}
              >
                <span className="hidden sm:inline">Aktif Konuşmalar</span>
                <span className="sm:hidden">Aktif</span>
                <span className="ml-1 sm:ml-2 px-1.5 sm:px-2 py-0.5 bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300 text-xs font-semibold rounded-full">
                  {activeConversations.length}
                </span>
              </button>
              <button
                onClick={() => setActiveTab('past')}
                className={`px-3 sm:px-6 py-2 rounded-md text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === 'past'
                    ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
                }`}
              >
                <span className="hidden sm:inline">Geçmiş Konuşmalar</span>
                <span className="sm:hidden">Geçmiş</span>
                <span className="ml-1 sm:ml-2 px-1.5 sm:px-2 py-0.5 bg-gray-200 dark:bg-slate-600 text-gray-700 dark:text-gray-300 text-xs font-semibold rounded-full">
                  {pastConversations.length}+
                </span>
              </button>
              <button
                onClick={() => setActiveTab('phone')}
                className={`px-3 sm:px-6 py-2 rounded-md text-xs sm:text-sm font-medium transition-all flex items-center gap-1 sm:gap-2 whitespace-nowrap ${
                  activeTab === 'phone'
                    ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
                }`}
              >
                <PhoneCall className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Telefon Konuşmaları</span>
                <span className="sm:hidden">Telefon</span>
                <span className={`px-1.5 sm:px-2 py-0.5 text-xs font-semibold rounded-full ${
                  activeTab === 'phone'
                    ? 'bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300'
                    : 'bg-gray-200 dark:bg-slate-600 text-gray-700 dark:text-gray-300'
                }`}>
                  {phoneCallsCount}
                </span>
              </button>
            </div>
            
            {/* Yardım Gerekli Tab */}
            <button 
              onClick={() => setFilterNeedsHelp(!filterNeedsHelp)}
              className={`px-3 sm:px-6 py-2 text-xs sm:text-sm font-medium border rounded-lg transition-all flex items-center gap-1 sm:gap-2 whitespace-nowrap ${
                filterNeedsHelp 
                  ? 'bg-amber-500 text-white border-amber-600 hover:bg-amber-600 shadow-sm'
                  : 'text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-700 hover:bg-amber-100 dark:hover:bg-amber-900/30'
              }`}
            >
              <AlertCircle className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Yardım Gerekli</span>
              <span className="sm:hidden">Yardım</span>
              {needsHelpCount > 0 && (
                <span className={`px-1.5 sm:px-2 py-0.5 text-xs font-semibold rounded-full ${
                  filterNeedsHelp 
                    ? 'bg-amber-600 text-white'
                    : 'bg-amber-200 dark:bg-amber-800 text-amber-900 dark:text-amber-100'
                }`}>
                  {needsHelpCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Conversations List */}
          <div className="lg:col-span-1 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <div className="divide-y divide-gray-100 dark:divide-slate-700 max-h-[400px] sm:max-h-[500px] lg:max-h-[calc(100vh-240px)] overflow-y-auto">
              {filteredConversations.length === 0 ? (
                <div className="p-8 text-center">
                  <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500 dark:text-gray-400 text-sm">Konuşma bulunamadı</p>
                </div>
              ) : (
                <>
                  {filteredConversations.map((conversation) => (
                    <button
                      key={conversation.id}
                      onClick={() => setSelectedConversation(conversation)}
                      className={`w-full p-4 hover:bg-gray-50 dark:hover:bg-slate-700 dark:bg-slate-900 transition-colors text-left relative ${
                        selectedConversation?.id === conversation.id ? 'bg-orange-50' : ''
                      } ${conversation.isUrgent ? 'border-l-4 border-red-500 bg-red-50/30' : conversation.needsHelp ? 'border-l-4 border-amber-500' : ''}`}
                    >
                      <div className="flex items-start gap-3">
                        {/* Channel Icon */}
                        <div className="relative flex-shrink-0">
                          <div className={`w-12 h-12 ${channelIcons[conversation.channel].bg} rounded-full flex items-center justify-center text-white`}>
                            {conversation.customerAvatar ? (
                              <img src={conversation.customerAvatar} alt="" className="w-full h-full rounded-full object-cover" />
                            ) : (
                              <User className="w-6 h-6" />
                            )}
                          </div>
                          <div className={`absolute -bottom-1 -right-1 w-6 h-6 ${channelIcons[conversation.channel].bg} rounded-full flex items-center justify-center text-white border-2 border-white`}>
                            {channelIcons[conversation.channel].icon}
                          </div>
                        </div>
                        
                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-1">
                            <div className="flex items-center gap-2 flex-1 min-w-0">
                              <h3 className="font-semibold text-gray-900 dark:text-gray-100 text-sm truncate">
                                {conversation.customerName}
                              </h3>
                              {conversation.needsHelp && (
                                <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" aria-label="Yardım gerekli" />
                              )}
                            </div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 ml-2 flex-shrink-0">
                              {formatTime(conversation.lastMessageTime)}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                            {conversation.lastMessage}
                          </p>
                          
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            {/* ACİL ARAMA - En yüksek öncelik */}
                            {conversation.isUrgent && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded-full animate-pulse">
                                <PhoneCall className="w-3 h-3" />
                                ACİL ARAMA
                              </span>
                            )}
                            
                            {/* Canlı Arama */}
                            {conversation.isLiveCall && !conversation.isUrgent && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-800 text-xs font-semibold rounded-full">
                                <PhoneIncoming className="w-3 h-3 animate-pulse" />
                                Canlı: {formatCallDuration(conversation.callDuration || 0)}
                              </span>
                            )}
                            
                            {conversation.unreadCount > 0 && (
                              <span className="inline-flex items-center justify-center px-2 py-0.5 bg-orange-500 text-white text-xs font-semibold rounded-full">
                                {conversation.unreadCount} yeni mesaj
                              </span>
                            )}
                            {conversation.needsHelp && !conversation.isLiveCall && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-800 text-xs font-semibold rounded-full">
                                <UserCheck className="w-3 h-3" />
                                {conversation.assignedAgent || 'İnsan yardımı'}
                              </span>
                            )}
                            {conversation.assignedTo === 'ai' && !conversation.needsHelp && !conversation.isLiveCall && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full">
                                <BotIcon className="w-3 h-3" />
                                AI
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                  
                  {/* Load More Button for Past Conversations */}
                  {activeTab === 'past' && hasMorePast && (
                    <button
                      onClick={loadMorePast}
                      className="w-full p-4 text-center text-sm font-medium text-orange-600 hover:bg-orange-50 transition-colors"
                    >
                      Daha Fazla Yükle (20 konuşma)
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
          
          {/* Conversation Detail */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            {selectedConversation ? (
              <div className="flex flex-col h-[500px] sm:h-[600px] lg:h-[calc(100vh-240px)]">
                {/* Conversation Header */}
                <div className="px-6 py-4 border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className={`w-10 h-10 ${channelIcons[selectedConversation.channel].bg} rounded-full flex items-center justify-center text-white`}>
                          <User className="w-5 h-5" />
                        </div>
                        <div className={`absolute -bottom-0.5 -right-0.5 w-5 h-5 ${channelIcons[selectedConversation.channel].bg} rounded-full flex items-center justify-center text-white border-2 border-white`}>
                          <div className="scale-75">
                            {channelIcons[selectedConversation.channel].icon}
                          </div>
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-gray-100">{selectedConversation.customerName}</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Son mesaj: {formatTime(selectedConversation.lastMessageTime)}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {/* Canlı Arama için Katıl Butonu */}
                      {selectedConversation.isLiveCall && (
                        <button 
                          className={`px-4 py-2 text-sm font-bold rounded-lg transition-all flex items-center gap-2 ${
                            selectedConversation.isUrgent 
                              ? 'bg-red-500 text-white hover:bg-red-600 animate-pulse'
                              : 'bg-purple-500 text-white hover:bg-purple-600'
                          }`}
                        >
                          <PhoneCall className="w-4 h-4" />
                          {selectedConversation.isUrgent ? 'ACİL - ARAMAYA KATIL' : 'Aramaya Katıl'}
                        </button>
                      )}
                      
                      {!selectedConversation.isLiveCall && (
                        selectedConversation.assignedTo === 'ai' && !selectedConversation.needsHelp ? (
                          <button 
                            onClick={handleTransferToHuman}
                            className="px-3 py-1.5 text-sm font-medium text-amber-700 bg-amber-50 border border-amber-300 rounded-lg hover:bg-amber-100 transition-colors flex items-center gap-2"
                          >
                            <UserCheck className="w-4 h-4" />
                            İnsana Devret
                          </button>
                        ) : (
                          <button 
                            onClick={handleTransferToAI}
                            className="px-3 py-1.5 text-sm font-medium text-blue-700 bg-blue-50 border border-blue-300 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-2"
                          >
                            <BotIcon className="w-4 h-4" />
                            AI'ya Devret
                          </button>
                        )
                      )}
                      
                      <button 
                        onClick={() => setShowProfileModal(true)}
                        className="px-3 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
                      >
                        Profili Görüntüle
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* Acil Arama Alert */}
                {selectedConversation.isUrgent && (
                  <div className="mx-6 mt-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg animate-pulse">
                    <div className="flex items-start gap-3">
                      <PhoneCall className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0 animate-bounce" />
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-red-900 mb-1">🚨 ACİL ARAMA - MÜDAHALE GEREKLİ</h4>
                        <p className="text-sm text-red-800">
                          Müşteri acil yardım talep ediyor. Lütfen hemen aramaya katılın!
                        </p>
                        <p className="text-xs text-red-700 mt-2 flex items-center gap-2">
                          <Clock className="w-3 h-3" />
                          Arama süresi: <strong>{formatCallDuration(selectedConversation.callDuration || 0)}</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Canlı Arama Durumu */}
                {selectedConversation.isLiveCall && !selectedConversation.isUrgent && (
                  <div className="mx-6 mt-6 p-4 bg-purple-50 border-l-4 border-purple-500 rounded-r-lg">
                    <div className="flex items-start gap-3">
                      <PhoneIncoming className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-purple-900 mb-1">📞 Canlı Arama Devam Ediyor</h4>
                        <p className="text-sm text-purple-800">
                          {selectedConversation.assignedTo === 'ai' 
                            ? 'AI asistan müşteriyle konuşuyor. Gerekirse aramaya katılabilirsiniz.'
                            : `${selectedConversation.assignedAgent} müşteriyle konuşuyor.`}
                        </p>
                        <p className="text-xs text-purple-700 mt-2 flex items-center gap-2">
                          <Clock className="w-3 h-3" />
                          Arama süresi: <strong>{formatCallDuration(selectedConversation.callDuration || 0)}</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* AI Stuck Warning */}
                {selectedConversation.needsHelp && selectedConversation.aiStuckReason && !selectedConversation.isLiveCall && (
                  <div className="mx-6 mt-6 p-4 bg-amber-50 border-l-4 border-amber-500 rounded-r-lg">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-amber-900 mb-1">AI Yardım Bekliyor</h4>
                        <p className="text-sm text-amber-800">{selectedConversation.aiStuckReason}</p>
                        {selectedConversation.assignedAgent && (
                          <p className="text-xs text-amber-700 mt-2 flex items-center gap-1">
                            <UserCheck className="w-3 h-3" />
                            <strong>{selectedConversation.assignedAgent}</strong> konuşmayı devralıyor
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {selectedConversation.messages.map((message, idx) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === 'agent' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] ${message.sender === 'agent' ? 'order-2' : 'order-1'}`}>
                        {/* Sesli konuşma transkripti göstergesi */}
                        {message.isVoiceTranscript && (
                          <div className={`flex items-center gap-2 mb-1 text-xs ${
                            message.sender === 'agent' ? 'justify-end' : 'justify-start'
                          }`}>
                            <Mic className="w-3 h-3 text-purple-500" />
                            <span className="text-purple-600 font-medium">Sesli konuşma transkripti</span>
                            {message.voiceDuration && (
                              <span className="text-gray-500 dark:text-gray-400">({formatCallDuration(message.voiceDuration)})</span>
                            )}
                          </div>
                        )}
                        
                        <div
                          className={`rounded-2xl px-4 py-2.5 ${
                            message.sender === 'agent'
                              ? message.isVoiceTranscript 
                                ? 'bg-purple-500 text-white rounded-br-sm'
                                : 'bg-orange-500 text-white rounded-br-sm'
                              : message.isVoiceTranscript
                                ? 'bg-purple-50 dark:bg-purple-900/30 text-gray-900 dark:text-gray-100 border border-purple-200 dark:border-purple-700 rounded-bl-sm'
                                : 'bg-gray-100 dark:bg-slate-700 text-gray-900 dark:text-gray-100 rounded-bl-sm'
                          }`}
                        >
                          <p className="text-sm">{message.text}</p>
                        </div>
                        <div className={`flex items-center gap-2 mt-1 px-1 ${message.sender === 'agent' ? 'justify-end' : 'justify-start'}`}>
                          <p className="text-xs text-gray-400">
                            {message.timestamp.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                          </p>
                          {message.sender === 'agent' && message.agentName && (
                            <>
                              <span className="text-xs text-gray-300">•</span>
                              <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                                {message.agentName}
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Message Input */}
                <div className="p-3 sm:p-4 border-t border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900">
                  {/* Attachments Preview */}
                  {attachments.length > 0 && (
                    <div className="mb-2 sm:mb-3 flex flex-wrap gap-1.5 sm:gap-2">
                      {attachments.map((file, index) => (
                        <div
                          key={index}
                          className="relative group bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-2 sm:px-3 py-1.5 sm:py-2 flex items-center gap-1.5 sm:gap-2"
                        >
                          {file.type.startsWith('image/') && <Image className="w-3 h-3 sm:w-4 sm:h-4 text-blue-500 flex-shrink-0" />}
                          {file.type.startsWith('video/') && <Video className="w-3 h-3 sm:w-4 sm:h-4 text-purple-500 flex-shrink-0" />}
                          {!file.type.startsWith('image/') && !file.type.startsWith('video/') && (
                            <FileText className="w-3 h-3 sm:w-4 sm:h-4 text-gray-500 dark:text-gray-400 flex-shrink-0" />
                          )}
                          <span className="text-xs text-gray-700 dark:text-gray-300 max-w-[100px] sm:max-w-[150px] truncate">
                            {file.name}
                          </span>
                          <button
                            onClick={() => removeAttachment(index)}
                            className="ml-1 text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                            aria-label={`${file.name} dosyasını kaldır`}
                          >
                            <XIcon className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-end gap-1 sm:gap-2">
                    {/* Attachment Menu */}
                    <div className="relative flex-shrink-0">
                      <button
                        onClick={() => setShowAttachmentMenu(!showAttachmentMenu)}
                        className="p-2 sm:p-2.5 text-gray-600 dark:text-gray-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors"
                        title="Dosya ekle"
                        aria-label="Dosya ekle"
                      >
                        <Paperclip className="w-4 h-4 sm:w-5 sm:h-5" />
                      </button>
                      
                      {showAttachmentMenu && (
                        <div className="absolute bottom-full left-0 mb-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg overflow-hidden z-10 min-w-[160px]">
                          <button
                            onClick={() => handleFileSelect('image')}
                            className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-left text-xs sm:text-sm hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 sm:gap-3 transition-colors"
                          >
                            <Image className="w-3 h-3 sm:w-4 sm:h-4 text-blue-500 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">Fotoğraf</span>
                          </button>
                          <button
                            onClick={() => handleFileSelect('video')}
                            className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-left text-xs sm:text-sm hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 sm:gap-3 transition-colors"
                          >
                            <Video className="w-3 h-3 sm:w-4 sm:h-4 text-purple-500 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">Video</span>
                          </button>
                          <button
                            onClick={() => handleFileSelect('file')}
                            className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-left text-xs sm:text-sm hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center gap-2 sm:gap-3 transition-colors"
                          >
                            <FileText className="w-3 h-3 sm:w-4 sm:h-4 text-gray-500 dark:text-gray-400 flex-shrink-0" />
                            <span className="text-gray-700 dark:text-gray-300">Dosya</span>
                          </button>
                        </div>
                      )}
                    </div>
                    
                    {/* Message Input */}
                    <input
                      type="text"
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder="Mesajınızı yazın..."
                      className="flex-1 min-w-0 px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500"
                    />
                    
                    {/* Send Button */}
                    <button
                      onClick={handleSendMessage}
                      disabled={!messageInput.trim() && attachments.length === 0}
                      className="px-3 sm:px-6 py-2 sm:py-2.5 bg-orange-500 text-white font-medium rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1 sm:gap-2 flex-shrink-0"
                      aria-label="Mesaj gönder"
                    >
                      <Send className="w-4 h-4" />
                      <span className="hidden sm:inline">Gönder</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-[calc(100vh-240px)] flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Konuşma Seçin</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Mesajlaşmaya başlamak için bir konuşma seçin</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Profile Modal */}
      {showProfileModal && selectedConversation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-slate-700">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 ${channelIcons[selectedConversation.channel].bg} rounded-full flex items-center justify-center text-white`}>
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 dark:text-gray-100">{selectedConversation.customerName}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 capitalize flex items-center gap-1">
                    {channelIcons[selectedConversation.channel].icon}
                    <span className="ml-1">{selectedConversation.channel === 'web' ? 'Web Widget' : selectedConversation.channel.charAt(0).toUpperCase() + selectedConversation.channel.slice(1)}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors p-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg"
              >
                <XIcon className="w-5 h-5" />
              </button>
            </div>
            
            {/* Modal Content */}
            <div className="p-6 space-y-4">
              {/* Instagram Profile */}
              {selectedConversation.customerProfile.instagram && (
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-pink-100">
                    <Instagram className="w-5 h-5 text-pink-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Instagram Kullanıcı Adı</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">{selectedConversation.customerProfile.instagram.username}</p>
                      <a
                        href={selectedConversation.customerProfile.instagram.profileUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-sm text-pink-600 hover:text-pink-700 font-medium"
                      >
                        Profili Ziyaret Et
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Phone Profile */}
              {selectedConversation.customerProfile.phone && (
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg border border-purple-100">
                    <PhoneCall className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Telefon Numarası</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">{selectedConversation.customerProfile.phone.phoneNumber}</p>
                      <div className="flex items-center gap-2">
                        <a
                          href={`tel:${selectedConversation.customerProfile.phone.phoneNumber.replace(/\s+/g, '')}`}
                          className="inline-flex items-center gap-1 text-sm text-purple-600 hover:text-purple-700 font-medium"
                        >
                          Ara
                          <Phone className="w-3 h-3" />
                        </a>
                        {selectedConversation.isLiveCall && (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-purple-100 text-purple-800 text-xs font-semibold rounded-full">
                            <PhoneIncoming className="w-3 h-3 animate-pulse" />
                            Canlı Arama
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* WhatsApp Profile */}
              {selectedConversation.customerProfile.whatsapp && (
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-100">
                    <Phone className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Telefon Numarası</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">{selectedConversation.customerProfile.whatsapp.phoneNumber}</p>
                      <a
                        href={`tel:${selectedConversation.customerProfile.whatsapp.phoneNumber.replace(/\s+/g, '')}`}
                        className="inline-flex items-center gap-1 text-sm text-green-600 hover:text-green-700 font-medium"
                      >
                        Ara
                        <Phone className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Facebook Profile */}
              {selectedConversation.customerProfile.facebook && (
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
                    <Facebook className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Facebook Profili</p>
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">{selectedConversation.customerProfile.facebook.name}</p>
                      <a
                        href={selectedConversation.customerProfile.facebook.profileUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700 font-medium"
                      >
                        Profili Ziyaret Et
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Web Widget Profile */}
              {selectedConversation.customerProfile.web && (
                <div className="space-y-3">
                  <div className="p-4 bg-orange-50 rounded-lg border border-orange-100 space-y-3">
                    <div className="flex items-center gap-2 mb-3">
                      <Globe className="w-5 h-5 text-orange-600" />
                      <p className="text-sm font-bold text-gray-900 dark:text-gray-100">Web Formundan Gelen Bilgiler</p>
                    </div>
                    
                    <div className="space-y-2">
                      <div>
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Ad Soyad</p>
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                          {selectedConversation.customerProfile.web.firstName} {selectedConversation.customerProfile.web.lastName}
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1 flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          E-posta
                        </p>
                        <a
                          href={`mailto:${selectedConversation.customerProfile.web.email}`}
                          className="text-sm font-medium text-orange-600 hover:text-orange-700"
                        >
                          {selectedConversation.customerProfile.web.email}
                        </a>
                      </div>
                      
                      {selectedConversation.customerProfile.web.phoneNumber && (
                        <div>
                          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1 flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            Telefon (Opsiyonel)
                          </p>
                          <a
                            href={`tel:${selectedConversation.customerProfile.web.phoneNumber.replace(/\s+/g, '')}`}
                            className="text-sm font-medium text-orange-600 hover:text-orange-700"
                          >
                            {selectedConversation.customerProfile.web.phoneNumber}
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900 rounded-b-2xl">
              <button
                onClick={() => setShowProfileModal(false)}
                className="w-full px-4 py-2.5 bg-gray-900 text-white font-medium rounded-lg hover:bg-gray-800 transition-colors"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConversationsPage;

