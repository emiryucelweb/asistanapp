/* eslint-disable */
import React, { useState } from 'react';
import {
  HelpCircle,
  Search,
  Video,
  FileText,
  MessageCircle,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Book,
  PlayCircle,
  Mail,
  Phone,
  Clock,
  CheckCircle,
  AlertCircle,
  Lightbulb,
  Rocket,
  Settings,
  Users,
  BarChart3,
  Send
} from 'lucide-react';

interface FAQItem {
  id: string;
  category: string;
  question: string;
  answer: string;
}

interface VideoTutorial {
  id: string;
  title: string;
  duration: string;
  thumbnail: string;
  category: string;
  views: number;
}

interface SupportTicket {
  id: string;
  subject: string;
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: string;
  lastUpdate: string;
}

const HelpPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);
  const [showTicketForm, setShowTicketForm] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketPriority, setTicketPriority] = useState('normal');

  const categories = [
    { id: 'all', label: 'Tümü', icon: <Book className="w-5 h-5" /> },
    { id: 'getting_started', label: 'Başlangıç', icon: <Rocket className="w-5 h-5" /> },
    { id: 'features', label: 'Özellikler', icon: <Lightbulb className="w-5 h-5" /> },
    { id: 'settings', label: 'Ayarlar', icon: <Settings className="w-5 h-5" /> },
    { id: 'team', label: 'Ekip Yönetimi', icon: <Users className="w-5 h-5" /> },
    { id: 'analytics', label: 'Raporlama', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'troubleshooting', label: 'Sorun Giderme', icon: <AlertCircle className="w-5 h-5" /> }
  ];

  const faqItems: FAQItem[] = [
    {
      id: '1',
      category: 'getting_started',
      question: 'AsistanApp nasıl başlarım?',
      answer: 'AsistanApp\'e başlamak için önce hesap ayarlarınızı tamamlayın. Ardından AI asistanınızı özelleştirin ve sosyal medya kanallarınızı bağlayın. İlk adımlar rehberimizden detaylı bilgi alabilirsiniz.'
    },
    {
      id: '2',
      category: 'getting_started',
      question: 'İlk AI asistanımı nasıl oluştururum?',
      answer: 'Ayarlar > AI Asistan bölümünden yeni bir AI asistan oluşturabilirsiniz. İşletme bilgilerinizi girin, tonunu seçin ve eğitim verilerinizi yükleyin. Sistem otomatik olarak öğrenmeye başlayacaktır.'
    },
    {
      id: '3',
      category: 'features',
      question: 'WhatsApp entegrasyonu nasıl yapılır?',
      answer: 'Ayarlar > Kanal Entegrasyonları > WhatsApp bölümünden QR kodu okutarak veya API key ile entegrasyon yapabilirsiniz. Detaylı kurulum rehberimizi takip edin.'
    },
    {
      id: '4',
      category: 'features',
      question: 'AI konuşmaları nasıl insana devredebilirim?',
      answer: 'Konuşmalar ekranında aktif bir konuşmanın detayına girip "İnsana Devret" butonuna tıklayarak manuel olarak devredebilirsiniz. Ayrıca AI belirli durumlarda (anlaşılamayan sorular, karmaşık talepler) otomatik olarak yardım isteyebilir.'
    },
    {
      id: '5',
      category: 'features',
      question: 'Randevu sistemi nasıl çalışır?',
      answer: 'AI asistanınız müşterilerinizle konuşurken uygun randevu saatlerini önerir. Siz de Ayarlar > Randevu Ayarları bölümünden çalışma saatlerinizi, randevu sürelerinizi ve özel günlerinizi belirleyebilirsiniz.'
    },
    {
      id: '6',
      category: 'settings',
      question: 'Bildirim ayarlarımı nasıl değiştiririm?',
      answer: 'Ayarlar > Bildirimler bölümünden email, SMS ve push bildirim tercihlerinizi ayarlayabilirsiniz. Her kanal için ayrı bildirim kuralları oluşturabilirsiniz.'
    },
    {
      id: '7',
      category: 'team',
      question: 'Yeni ekip üyesi nasıl eklerim?',
      answer: 'Ekip sayfasından "Yeni Ekip Üyesi Ekle" butonuna tıklayın. Email, rol ve yetkileri belirleyin. Eklenen üye email ile davet alacaktır.'
    },
    {
      id: '8',
      category: 'team',
      question: 'Ekip üyelerine nasıl yetki veririm?',
      answer: 'Ekip sayfasından ilgili üyeyi seçin ve "Düzenle" butonuna tıklayın. Yetki ayarları bölümünden konuşma yönetimi, rapor görüntüleme, ayar değiştirme gibi yetkileri seçebilirsiniz.'
    },
    {
      id: '9',
      category: 'analytics',
      question: 'Raporları nasıl dışa aktarırım?',
      answer: 'Raporlar sayfasında istediğiniz raporu seçin. Tarih aralığını belirleyin ve sağ üst köşedeki "Excel\'e Aktar" veya "PDF\'e Aktar" butonlarını kullanın.'
    },
    {
      id: '10',
      category: 'analytics',
      question: 'AI performans metriklerini nasıl yorumlarım?',
      answer: 'AI performans raporunda yanıt süresi, başarı oranı, müşteri memnuniyeti gibi metrikler bulunur. Yeşil değerler iyi performansı, sarı değerler gelişim alanlarını gösterir.'
    },
    {
      id: '11',
      category: 'troubleshooting',
      question: 'AI yanıt vermiyor, ne yapmalıyım?',
      answer: 'İlk olarak internet bağlantınızı kontrol edin. Ayarlar > AI Asistan bölümünden AI durumunu kontrol edin. Sorun devam ederse destek ekibimize ticket açın.'
    },
    {
      id: '12',
      category: 'troubleshooting',
      question: 'Mesajlar gecikmeli geliyor?',
      answer: 'Kanal entegrasyonlarınızı kontrol edin. WhatsApp ve diğer platformlar için bağlantı durumunu Ayarlar > Kanal Entegrasyonları bölümünden kontrol edebilirsiniz.'
    }
  ];

  const videoTutorials: VideoTutorial[] = [
    {
      id: '1',
      title: 'AsistanApp\'e Hızlı Başlangıç',
      duration: '5:30',
      thumbnail: 'https://via.placeholder.com/320x180/3b82f6/ffffff?text=Quick+Start',
      category: 'getting_started',
      views: 1250
    },
    {
      id: '2',
      title: 'AI Asistan Kurulumu ve Özelleştirme',
      duration: '8:45',
      thumbnail: 'https://via.placeholder.com/320x180/8b5cf6/ffffff?text=AI+Setup',
      category: 'getting_started',
      views: 980
    },
    {
      id: '3',
      title: 'WhatsApp ve Instagram Entegrasyonu',
      duration: '6:20',
      thumbnail: 'https://via.placeholder.com/320x180/10b981/ffffff?text=Social+Media',
      category: 'features',
      views: 1540
    },
    {
      id: '4',
      title: 'Konuşma Yönetimi ve AI Devresi',
      duration: '7:15',
      thumbnail: 'https://via.placeholder.com/320x180/f59e0b/ffffff?text=Conversations',
      category: 'features',
      views: 870
    },
    {
      id: '5',
      title: 'Rapor ve Analiz Araçları',
      duration: '9:30',
      thumbnail: 'https://via.placeholder.com/320x180/ef4444/ffffff?text=Analytics',
      category: 'analytics',
      views: 650
    },
    {
      id: '6',
      title: 'Ekip Yönetimi ve Yetkilendirme',
      duration: '6:50',
      thumbnail: 'https://via.placeholder.com/320x180/06b6d4/ffffff?text=Team',
      category: 'team',
      views: 720
    }
  ];

  const supportTickets: SupportTicket[] = [
    {
      id: 'TKT-001',
      subject: 'WhatsApp bağlantı sorunu',
      status: 'in_progress',
      createdAt: '2024-10-08',
      lastUpdate: '2 saat önce'
    },
    {
      id: 'TKT-002',
      subject: 'Fatura indirme hatası',
      status: 'resolved',
      createdAt: '2024-10-05',
      lastUpdate: '3 gün önce'
    }
  ];

  const filteredFAQs = faqItems.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredVideos = videoTutorials.filter(video => {
    const matchesCategory = activeCategory === 'all' || video.category === activeCategory;
    return matchesCategory;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">Açık</span>;
      case 'in_progress':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">İşlemde</span>;
      case 'resolved':
        return <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">Çözüldü</span>;
      default:
        return null;
    }
  };

  const handleSubmitTicket = () => {
    if (!ticketSubject.trim() || !ticketMessage.trim()) {
      alert('Lütfen konu ve mesaj alanlarını doldurun.');
      return;
    }

    console.log('Ticket submitted:', { ticketSubject, ticketMessage, ticketPriority });
    alert('Destek talebiniz başarıyla oluşturuldu! Kısa süre içinde size dönüş yapacağız.');
    setShowTicketForm(false);
    setTicketSubject('');
    setTicketMessage('');
    setTicketPriority('normal');
  };

  return (
    <div className="flex flex-col max-w-[1600px] mx-auto px-8 py-6 gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-3">
            <HelpCircle className="w-7 h-7 text-blue-600" />
            Yardım Merkezi
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Sorularınızın cevaplarını bulun ve destek alın</p>
        </div>
        <button
          onClick={() => setShowTicketForm(true)}
          className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2"
        >
          <MessageCircle className="w-5 h-5" />
          Destek Talebi Oluştur
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Toplam Makale</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">{faqItems.length}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Video Eğitim</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">{videoTutorials.length}</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <Video className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Aktif Talepler</p>
              <p className="text-2xl font-bold text-yellow-600 mt-1">
                {supportTickets.filter(t => t.status !== 'resolved').length}
              </p>
            </div>
            <div className="p-3 bg-yellow-100 rounded-lg">
              <MessageCircle className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Ort. Yanıt Süresi</p>
              <p className="text-2xl font-bold text-green-600 mt-1">2 saat</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <Clock className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Aradığınız soruyu veya konuyu yazın..."
            className="w-full pl-14 pr-4 py-4 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-lg"
          />
        </div>
      </div>

      {/* Category Filter */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-4">
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${ activeCategory === category.id ? 'bg-blue-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200' }`}
            >
              {category.icon}
              {category.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Tabs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FAQ Section */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            Sık Sorulan Sorular
          </h2>
          <div className="space-y-3">
            {filteredFAQs.length > 0 ? (
              filteredFAQs.map((faq) => (
                <div
                  key={faq.id}
                  className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden"
                >
                  <button
                    onClick={() => setExpandedFAQ(expandedFAQ === faq.id ? null : faq.id)}
                    className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 dark:bg-slate-900 transition-colors"
                  >
                    <span className="font-medium text-gray-900 dark:text-gray-100 text-left">{faq.question}</span>
                    {expandedFAQ === faq.id ? (
                      <ChevronDown className="w-5 h-5 text-gray-600 dark:text-gray-400 flex-shrink-0" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-gray-600 dark:text-gray-400 flex-shrink-0" />
                    )}
                  </button>
                  {expandedFAQ === faq.id && (
                    <div className="px-6 py-4 bg-gray-50 dark:bg-slate-900 border-t border-gray-200 dark:border-slate-700">
                      <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-8 text-center">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 dark:text-gray-400">Arama kriterlerinize uygun sonuç bulunamadı.</p>
              </div>
            )}
          </div>

          {/* Video Tutorials */}
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2 mt-8">
            <Video className="w-6 h-6 text-purple-600" />
            Video Eğitimler
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredVideos.map((video) => (
              <div
                key={video.id}
                className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
              >
                <div className="relative">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <PlayCircle className="w-12 h-12 text-white" />
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs font-medium">
                    {video.duration}
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">{video.title}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{video.views} görüntülenme</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar - Contact & Tickets */}
        <div className="space-y-4">
          {/* Contact Support */}
          <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl p-6 text-white">
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Canlı Destek
            </h3>
            <p className="text-blue-100 mb-4 text-sm">
              Sorununuzu hemen çözmek için destek ekibimizle iletişime geçin.
            </p>
            <div className="space-y-3">
              <button className="w-full px-4 py-2.5 bg-white dark:bg-slate-800 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-medium flex items-center justify-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Canlı Chat Başlat
              </button>
              <a
                href="mailto:destek@asistanapp.com"
                className="w-full px-4 py-2.5 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors font-medium flex items-center justify-center gap-2"
              >
                <Mail className="w-5 h-5" />
                Email Gönder
              </a>
              <a
                href="tel:+908501234567"
                className="w-full px-4 py-2.5 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors font-medium flex items-center justify-center gap-2"
              >
                <Phone className="w-5 h-5" />
                +90 850 123 4567
              </a>
            </div>
          </div>

          {/* My Tickets */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
            <h3 className="font-bold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              Taleplerim
            </h3>
            {supportTickets.length > 0 ? (
              <div className="space-y-3">
                {supportTickets.map((ticket) => (
                  <div
                    key={ticket.id}
                    className="border border-gray-200 dark:border-slate-700 rounded-lg p-3 hover:bg-gray-50 dark:bg-slate-900 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-xs font-mono text-gray-600 dark:text-gray-400">{ticket.id}</span>
                      {getStatusBadge(ticket.status)}
                    </div>
                    <p className="font-medium text-gray-900 dark:text-gray-100 text-sm mb-1">{ticket.subject}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Son güncelleme: {ticket.lastUpdate}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-600 dark:text-gray-400">Henüz destek talebiniz bulunmuyor.</p>
            )}
          </div>

          {/* Documentation Links */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
            <h3 className="font-bold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
              <Book className="w-5 h-5 text-blue-600" />
              Dokümantasyon
            </h3>
            <div className="space-y-2">
              <a
                href="#"
                className="flex items-center justify-between px-3 py-2 hover:bg-gray-50 dark:bg-slate-900 rounded-lg transition-colors text-sm"
              >
                <span className="text-gray-700 dark:text-gray-300">API Dokümantasyonu</span>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </a>
              <a
                href="#"
                className="flex items-center justify-between px-3 py-2 hover:bg-gray-50 dark:bg-slate-900 rounded-lg transition-colors text-sm"
              >
                <span className="text-gray-700 dark:text-gray-300">Entegrasyon Rehberi</span>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </a>
              <a
                href="#"
                className="flex items-center justify-between px-3 py-2 hover:bg-gray-50 dark:bg-slate-900 rounded-lg transition-colors text-sm"
              >
                <span className="text-gray-700 dark:text-gray-300">Güvenlik & Gizlilik</span>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </a>
              <a
                href="#"
                className="flex items-center justify-between px-3 py-2 hover:bg-gray-50 dark:bg-slate-900 rounded-lg transition-colors text-sm"
              >
                <span className="text-gray-700 dark:text-gray-300">Sürüm Notları</span>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Create Ticket Modal */}
      {showTicketForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-slate-700">
              <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Destek Talebi Oluştur</h2>
              <p className="text-gray-600 dark:text-gray-400 mt-1">Sorununuzu detaylı bir şekilde açıklayın</p>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Konu <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  placeholder="Sorununuzu kısaca özetleyin"
                  className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Öncelik
                </label>
                <select
                  value={ticketPriority}
                  onChange={(e) => setTicketPriority(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                >
                  <option value="low">Düşük</option>
                  <option value="normal">Normal</option>
                  <option value="high">Yüksek</option>
                  <option value="urgent">Acil</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Açıklama <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  placeholder="Sorununuzu detaylı bir şekilde açıklayın..."
                  rows={6}
                  className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none"
                />
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex gap-3">
                  <Lightbulb className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-700">
                    <p className="font-medium mb-1">İpucu:</p>
                    <p>Sorununuzu detaylı açıklamanız, daha hızlı çözüm bulmamıza yardımcı olur. Ekran görüntüleri ekleyebilirsiniz.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowTicketForm(false);
                  setTicketSubject('');
                  setTicketMessage('');
                  setTicketPriority('normal');
                }}
                className="px-5 py-2.5 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
              >
                İptal
              </button>
              <button
                onClick={handleSubmitTicket}
                className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                Talep Oluştur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HelpPage;

