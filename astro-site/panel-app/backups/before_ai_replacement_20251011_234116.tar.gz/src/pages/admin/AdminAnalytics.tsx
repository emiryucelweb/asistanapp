/**
 * Super Admin Analytics Page - Platform Analitiği
 */
import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Users,
  MessageSquare,
  DollarSign,
  Globe,
  Zap,
} from 'lucide-react';

const AdminAnalytics: React.FC = () => {
  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
          Platform Analitiği
        </h1>
        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
          Tüm platform genelinde detaylı istatistikler
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">Toplam Konuşma</p>
            <MessageSquare className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">45.2K</p>
          <div className="flex items-center gap-1 mt-2 text-sm text-green-600 dark:text-green-400">
            <TrendingUp className="w-4 h-4" />
            <span>+12.5%</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">Aktif Kullanıcı</p>
            <Users className="w-5 h-5 text-green-600 dark:text-green-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">1,284</p>
          <div className="flex items-center gap-1 mt-2 text-sm text-green-600 dark:text-green-400">
            <TrendingUp className="w-4 h-4" />
            <span>+8.2%</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">API Çağrıları</p>
            <Zap className="w-5 h-5 text-orange-600 dark:text-orange-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">2.1M</p>
          <div className="flex items-center gap-1 mt-2 text-sm text-red-600 dark:text-red-400">
            <TrendingDown className="w-4 h-4" />
            <span>-2.1%</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">Ortalama Yanıt</p>
            <Activity className="w-5 h-5 text-purple-600 dark:text-purple-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">2.3s</p>
          <div className="flex items-center gap-1 mt-2 text-sm text-green-600 dark:text-green-400">
            <TrendingUp className="w-4 h-4" />
            <span>%15 daha hızlı</span>
          </div>
        </div>
      </div>

      {/* Charts Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Konuşma Trendi
          </h2>
          <div className="h-64 flex items-center justify-center text-gray-400">
            Grafik buraya gelecek (Chart.js/Recharts)
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Kanal Dağılımı
          </h2>
          <div className="h-64 flex items-center justify-center text-gray-400">
            Grafik buraya gelecek (Chart.js/Recharts)
          </div>
        </div>
      </div>

      {/* Channel Performance */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          Kanal Performansı
        </h2>
        <div className="space-y-4">
          {[
            { channel: 'WhatsApp', count: 18500, percentage: 41, color: 'green' },
            { channel: 'Instagram', count: 12300, percentage: 27, color: 'pink' },
            { channel: 'Web', count: 8900, percentage: 20, color: 'blue' },
            { channel: 'Facebook', count: 5500, percentage: 12, color: 'blue' },
          ].map((item) => (
            <div key={item.channel}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {item.channel}
                </span>
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {item.count.toLocaleString()} konuşma
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${
                    item.color === 'green'
                      ? 'bg-green-600'
                      : item.color === 'pink'
                      ? 'bg-pink-600'
                      : 'bg-blue-600'
                  }`}
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminAnalytics;



