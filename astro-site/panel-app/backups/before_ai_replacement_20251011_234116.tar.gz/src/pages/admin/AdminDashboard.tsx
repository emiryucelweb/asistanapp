/**
 * Super Admin Dashboard - AsistanApp Genel Bakış
 */
import React from 'react';
import {
  Building2,
  DollarSign,
  TrendingUp,
  Users,
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';

const AdminDashboard: React.FC = () => {
  // Mock data
  const stats = {
    totalTenants: 24,
    activeTenants: 18,
    trialTenants: 4,
    pastDueTenants: 2,
    totalMonthlyRevenue: 45750,
    totalMonthlyCosts: 15280,
    totalProfit: 30470,
    profitMargin: 66.6,
    growthRate: 15.3,
    churnRate: 2.5,
  };

  const recentActivity = [
    { id: 1, type: 'new', tenant: 'Fashion Boutique', action: 'Yeni firma kaydı', time: '5 dakika önce', color: 'green' },
    { id: 2, type: 'payment', tenant: 'Acme E-commerce', action: 'Ödeme alındı ($2,500)', time: '1 saat önce', color: 'blue' },
    { id: 3, type: 'upgrade', tenant: 'TechStart SaaS', action: 'Enterprise plana yükseltildi', time: '3 saat önce', color: 'purple' },
    { id: 4, type: 'warning', tenant: 'HealthCare Plus', action: 'Ödeme gecikmesi', time: '5 saat önce', color: 'red' },
    { id: 5, type: 'api', tenant: 'Food Delivery Co', action: 'API limiti %80 doldu', time: '1 gün önce', color: 'yellow' },
  ];

  const topTenants = [
    { name: 'Acme E-commerce', revenue: 2500, growth: 12.5, plan: 'Enterprise' },
    { name: 'TechStart SaaS', revenue: 2400, growth: 18.2, plan: 'Professional' },
    { name: 'HealthCare Plus', revenue: 2200, growth: -5.3, plan: 'Professional' },
    { name: 'Fashion Boutique', revenue: 1999, growth: 22.1, plan: 'Starter' },
    { name: 'Food Delivery Co', revenue: 1899, growth: 8.7, plan: 'Professional' },
  ];

  const systemHealth = [
    { name: 'API Status', status: 'operational', uptime: '99.9%', color: 'green' },
    { name: 'Database', status: 'operational', uptime: '100%', color: 'green' },
    { name: 'Storage', status: 'degraded', uptime: '95.2%', color: 'yellow' },
    { name: 'WhatsApp API', status: 'operational', uptime: '99.5%', color: 'green' },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
          Genel Bakış
        </h1>
        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
          AsistanApp platformu yönetim paneli
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm opacity-90">Toplam Firma</p>
            <Building2 className="w-5 h-5 opacity-90" />
          </div>
          <p className="text-3xl font-bold">{stats.totalTenants}</p>
          <div className="flex items-center gap-2 mt-2 text-sm">
            <span className="px-2 py-0.5 bg-white/20 rounded-full">{stats.activeTenants} aktif</span>
            <span className="px-2 py-0.5 bg-white/20 rounded-full">{stats.trialTenants} deneme</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm opacity-90">Aylık Gelir</p>
            <DollarSign className="w-5 h-5 opacity-90" />
          </div>
          <p className="text-3xl font-bold">${stats.totalMonthlyRevenue.toLocaleString()}</p>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <TrendingUp className="w-4 h-4" />
            <span>+{stats.growthRate}% bu ay</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm opacity-90">Net Kar</p>
            <TrendingUp className="w-5 h-5 opacity-90" />
          </div>
          <p className="text-3xl font-bold">${stats.totalProfit.toLocaleString()}</p>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <span>{stats.profitMargin}% kar marjı</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm opacity-90">Sistem Sağlığı</p>
            <Activity className="w-5 h-5 opacity-90" />
          </div>
          <p className="text-3xl font-bold">99.8%</p>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <CheckCircle className="w-4 h-4" />
            <span>Tüm sistemler çalışıyor</span>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Son Aktiviteler
          </h2>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="flex items-start gap-4 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors"
              >
                <div
                  className={`p-2 rounded-lg ${
                    activity.color === 'green'
                      ? 'bg-green-100 dark:bg-green-900/30'
                      : activity.color === 'blue'
                      ? 'bg-blue-100 dark:bg-blue-900/30'
                      : activity.color === 'purple'
                      ? 'bg-purple-100 dark:bg-purple-900/30'
                      : activity.color === 'red'
                      ? 'bg-red-100 dark:bg-red-900/30'
                      : 'bg-yellow-100 dark:bg-yellow-900/30'
                  }`}
                >
                  {activity.type === 'new' && <Building2 className="w-4 h-4 text-green-600 dark:text-green-400" />}
                  {activity.type === 'payment' && <DollarSign className="w-4 h-4 text-blue-600 dark:text-blue-400" />}
                  {activity.type === 'upgrade' && <TrendingUp className="w-4 h-4 text-purple-600 dark:text-purple-400" />}
                  {activity.type === 'warning' && <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400" />}
                  {activity.type === 'api' && <Activity className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {activity.tenant}
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {activity.action}
                  </p>
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {activity.time}
                </div>
              </div>
            ))}
          </div>
          <Link
            to="/asistansuper/tenants"
            className="block mt-4 text-center text-sm text-blue-600 dark:text-blue-400 hover:underline"
          >
            Tüm firmalar görüntüle →
          </Link>
        </div>

        {/* System Health */}
        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Sistem Durumu
          </h2>
          <div className="space-y-4">
            {systemHealth.map((system) => (
              <div key={system.name} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {system.name}
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    Uptime: {system.uptime}
                  </p>
                </div>
                <div
                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                    system.color === 'green'
                      ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                      : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'
                  }`}
                >
                  {system.status === 'operational' ? 'Çalışıyor' : 'Yavaş'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Tenants */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            En İyi Performans Gösteren Firmalar
          </h2>
          <Link
            to="/asistansuper/financial-reports"
            className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
          >
            Tüm raporlar →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200 dark:border-slate-700">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                  Firma
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                  Plan
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                  Aylık Gelir
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                  Büyüme
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-slate-700">
              {topTenants.map((tenant, index) => (
                <tr key={index} className="hover:bg-gray-50 dark:hover:bg-slate-700/50">
                  <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center text-blue-600 dark:text-blue-400 font-semibold text-sm">
                        {index + 1}
                      </div>
                      <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                        {tenant.name}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {tenant.plan}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                      ${tenant.revenue.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right">
                    <div className="flex items-center justify-end gap-1">
                      {tenant.growth > 0 ? (
                        <>
                          <ArrowUpRight className="w-4 h-4 text-green-600 dark:text-green-400" />
                          <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                            +{tenant.growth}%
                          </span>
                        </>
                      ) : (
                        <>
                          <ArrowDownRight className="w-4 h-4 text-red-600 dark:text-red-400" />
                          <span className="text-sm font-semibold text-red-600 dark:text-red-400">
                            {tenant.growth}%
                          </span>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Link
          to="/asistansuper/tenants"
          className="p-4 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:shadow-lg transition-shadow"
        >
          <Building2 className="w-8 h-8 text-blue-600 dark:text-blue-400 mb-2" />
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Firmalar Yönetimi</p>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Tüm firmaları görüntüle</p>
        </Link>

        <Link
          to="/asistansuper/financial-reports"
          className="p-4 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:shadow-lg transition-shadow"
        >
          <DollarSign className="w-8 h-8 text-green-600 dark:text-green-400 mb-2" />
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Finansal Raporlar</p>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Gelir ve maliyet analizi</p>
        </Link>

        <Link
          to="/asistansuper/analytics"
          className="p-4 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:shadow-lg transition-shadow"
        >
          <Activity className="w-8 h-8 text-purple-600 dark:text-purple-400 mb-2" />
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Analitik</p>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Detaylı istatistikler</p>
        </Link>

        <Link
          to="/asistansuper/system"
          className="p-4 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg hover:shadow-lg transition-shadow"
        >
          <CheckCircle className="w-8 h-8 text-orange-600 dark:text-orange-400 mb-2" />
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Sistem</p>
          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Sistem durumu ve loglar</p>
        </Link>
      </div>
    </div>
  );
};

export default AdminDashboard;



