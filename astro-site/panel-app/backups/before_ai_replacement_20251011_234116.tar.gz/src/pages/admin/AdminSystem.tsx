/**
 * Super Admin System Page - Sistem Yönetimi
 */
import React from 'react';
import {
  Server,
  Database,
  Activity,
  HardDrive,
  Cpu,
  Wifi,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
} from 'lucide-react';

const AdminSystem: React.FC = () => {
  const systemStatus = [
    {
      name: 'API Server',
      status: 'operational',
      uptime: '99.98%',
      responseTime: '45ms',
      requests: '2.1M/day',
      color: 'green',
    },
    {
      name: 'Database (PostgreSQL)',
      status: 'operational',
      uptime: '100%',
      responseTime: '12ms',
      connections: '145/500',
      color: 'green',
    },
    {
      name: 'Redis Cache',
      status: 'operational',
      uptime: '99.95%',
      memory: '2.3GB/8GB',
      hitRate: '94.2%',
      color: 'green',
    },
    {
      name: 'Storage (S3)',
      status: 'degraded',
      uptime: '95.2%',
      usage: '245GB/500GB',
      bandwidth: '12GB/day',
      color: 'yellow',
    },
    {
      name: 'WhatsApp API',
      status: 'operational',
      uptime: '99.5%',
      messages: '18K/day',
      queue: '0',
      color: 'green',
    },
    {
      name: 'OpenAI API',
      status: 'operational',
      uptime: '99.7%',
      tokens: '45M/day',
      cost: '$450/day',
      color: 'green',
    },
  ];

  const recentLogs = [
    {
      id: 1,
      level: 'info',
      message: 'Database backup completed successfully',
      time: '2 dakika önce',
      service: 'backup-service',
    },
    {
      id: 2,
      level: 'warning',
      message: 'Storage usage exceeded 80% threshold',
      time: '15 dakika önce',
      service: 'storage-monitor',
    },
    {
      id: 3,
      level: 'error',
      message: 'Failed to send WhatsApp message (retry: 3/3)',
      time: '1 saat önce',
      service: 'whatsapp-service',
    },
    {
      id: 4,
      level: 'info',
      message: 'Scheduled maintenance completed',
      time: '3 saat önce',
      service: 'maintenance',
    },
    {
      id: 5,
      level: 'info',
      message: 'API rate limit increased for tenant: acme-ecommerce',
      time: '5 saat önce',
      service: 'api-gateway',
    },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
          Sistem Yönetimi
        </h1>
        <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
          Platform altyapısı ve sistem durumu
        </p>
      </div>

      {/* System Health Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">CPU Kullanımı</p>
            <Cpu className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">23%</p>
          <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2 mt-2">
            <div className="bg-blue-600 h-2 rounded-full" style={{ width: '23%' }} />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">RAM Kullanımı</p>
            <HardDrive className="w-5 h-5 text-green-600 dark:text-green-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">67%</p>
          <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2 mt-2">
            <div className="bg-green-600 h-2 rounded-full" style={{ width: '67%' }} />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">Disk Kullanımı</p>
            <Database className="w-5 h-5 text-orange-600 dark:text-orange-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">49%</p>
          <div className="w-full bg-gray-200 dark:bg-slate-700 rounded-full h-2 mt-2">
            <div className="bg-orange-600 h-2 rounded-full" style={{ width: '49%' }} />
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">Network</p>
            <Wifi className="w-5 h-5 text-purple-600 dark:text-purple-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">125MB/s</p>
          <div className="flex items-center gap-1 mt-2 text-sm text-gray-600 dark:text-gray-400">
            <TrendingUp className="w-4 h-4" />
            <span>↑ 45MB/s ↓ 80MB/s</span>
          </div>
        </div>
      </div>

      {/* Services Status */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          Servis Durumu
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {systemStatus.map((service) => (
            <div
              key={service.name}
              className="p-4 border border-gray-200 dark:border-slate-700 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                    {service.name}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Uptime: {service.uptime}
                  </p>
                </div>
                <div
                  className={`p-2 rounded-lg ${
                    service.color === 'green'
                      ? 'bg-green-100 dark:bg-green-900/30'
                      : 'bg-yellow-100 dark:bg-yellow-900/30'
                  }`}
                >
                  {service.color === 'green' ? (
                    <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                  )}
                </div>
              </div>
              <div className="space-y-1">
                {Object.entries(service)
                  .filter(([key]) => !['name', 'status', 'uptime', 'color'].includes(key))
                  .map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between text-xs">
                      <span className="text-gray-600 dark:text-gray-400 capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}:
                      </span>
                      <span className="text-gray-900 dark:text-gray-100 font-medium">
                        {value}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Logs */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 border border-gray-200 dark:border-slate-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          Son Sistem Logları
        </h2>
        <div className="space-y-3">
          {recentLogs.map((log) => (
            <div
              key={log.id}
              className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors"
            >
              <div
                className={`p-2 rounded-lg mt-0.5 ${
                  log.level === 'info'
                    ? 'bg-blue-100 dark:bg-blue-900/30'
                    : log.level === 'warning'
                    ? 'bg-yellow-100 dark:bg-yellow-900/30'
                    : 'bg-red-100 dark:bg-red-900/30'
                }`}
              >
                {log.level === 'info' ? (
                  <Activity className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                ) : log.level === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400" />
                )}
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-900 dark:text-gray-100">{log.message}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {log.service}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                    <Clock className="w-3 h-3" />
                    {log.time}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <button className="mt-4 w-full text-center text-sm text-blue-600 dark:text-blue-400 hover:underline">
          Tüm logları görüntüle →
        </button>
      </div>
    </div>
  );
};

export default AdminSystem;



