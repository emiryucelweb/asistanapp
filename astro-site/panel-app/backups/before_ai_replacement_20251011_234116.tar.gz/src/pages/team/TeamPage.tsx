/* eslint-disable */
import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  MoreVertical,
  Mail,
  Phone,
  Clock,
  TrendingUp,
  Activity,
  Award,
  Calendar,
  MessageSquare,
  Settings,
  Trash2,
  Edit,
  CheckCircle,
  XCircle,
  Crown,
  Shield,
  User
} from 'lucide-react';
import { formatNumber } from '../../utils/formatters';

interface TeamMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'owner' | 'admin' | 'agent' | 'viewer';
  department: string;
  status: 'active' | 'inactive' | 'on_leave';
  avatar: string;
  joinDate: string;
  lastActive: string;
  performance: {
    conversationsHandled: number;
    avgResponseTime: string;
    satisfactionScore: number;
    tasksCompleted: number;
  };
  permissions: string[];
}

const TeamPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showAddMember, setShowAddMember] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  // Mock team data
  const teamMembers: TeamMember[] = [
    {
      id: '1',
      name: 'Ahmet Yılmaz',
      email: 'ahmet@asistanapp.com',
      phone: '+90 532 123 4567',
      role: 'owner',
      department: 'Yönetim',
      status: 'active',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmet',
      joinDate: '2024-01-15',
      lastActive: '2 dakika önce',
      performance: {
        conversationsHandled: 1250,
        avgResponseTime: '2 dk 30 sn',
        satisfactionScore: 4.8,
        tasksCompleted: 340
      },
      permissions: ['all']
    },
    {
      id: '2',
      name: 'Zeynep Kaya',
      email: 'zeynep@asistanapp.com',
      phone: '+90 533 234 5678',
      role: 'admin',
      department: 'Müşteri İlişkileri',
      status: 'active',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Zeynep',
      joinDate: '2024-02-10',
      lastActive: '15 dakika önce',
      performance: {
        conversationsHandled: 890,
        avgResponseTime: '3 dk 15 sn',
        satisfactionScore: 4.6,
        tasksCompleted: 280
      },
      permissions: ['manage_team', 'view_reports', 'handle_conversations']
    },
    {
      id: '3',
      name: 'Mehmet Demir',
      email: 'mehmet@asistanapp.com',
      phone: '+90 534 345 6789',
      role: 'agent',
      department: 'Destek',
      status: 'active',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mehmet',
      joinDate: '2024-03-05',
      lastActive: '1 saat önce',
      performance: {
        conversationsHandled: 650,
        avgResponseTime: '4 dk 20 sn',
        satisfactionScore: 4.4,
        tasksCompleted: 195
      },
      permissions: ['handle_conversations', 'view_customer_profiles']
    },
    {
      id: '4',
      name: 'Ayşe Şahin',
      email: 'ayse@asistanapp.com',
      phone: '+90 535 456 7890',
      role: 'agent',
      department: 'Satış',
      status: 'active',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ayse',
      joinDate: '2024-03-20',
      lastActive: '30 dakika önce',
      performance: {
        conversationsHandled: 520,
        avgResponseTime: '3 dk 45 sn',
        satisfactionScore: 4.7,
        tasksCompleted: 160
      },
      permissions: ['handle_conversations', 'create_appointments']
    },
    {
      id: '5',
      name: 'Can Özkan',
      email: 'can@asistanapp.com',
      phone: '+90 536 567 8901',
      role: 'agent',
      department: 'Teknik Destek',
      status: 'on_leave',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Can',
      joinDate: '2024-04-01',
      lastActive: '3 gün önce',
      performance: {
        conversationsHandled: 380,
        avgResponseTime: '5 dk 10 sn',
        satisfactionScore: 4.3,
        tasksCompleted: 120
      },
      permissions: ['handle_conversations']
    },
    {
      id: '6',
      name: 'Elif Yurt',
      email: 'elif@asistanapp.com',
      phone: '+90 537 678 9012',
      role: 'viewer',
      department: 'Analiz',
      status: 'active',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Elif',
      joinDate: '2024-04-15',
      lastActive: '2 saat önce',
      performance: {
        conversationsHandled: 0,
        avgResponseTime: '-',
        satisfactionScore: 0,
        tasksCompleted: 45
      },
      permissions: ['view_reports', 'view_analytics']
    }
  ];

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return <Crown className="w-4 h-4" />;
      case 'admin': return <Shield className="w-4 h-4" />;
      case 'agent': return <User className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'owner': return 'bg-purple-100 text-purple-700';
      case 'admin': return 'bg-blue-100 text-blue-700';
      case 'agent': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300';
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'owner': return 'Sahip';
      case 'admin': return 'Yönetici';
      case 'agent': return 'Temsilci';
      case 'viewer': return 'İzleyici';
      default: return role;
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700';
      case 'inactive': return 'bg-red-100 text-red-700';
      case 'on_leave': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Aktif';
      case 'inactive': return 'Pasif';
      case 'on_leave': return 'İzinde';
      default: return status;
    }
  };

  const filteredMembers = teamMembers.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = filterRole === 'all' || member.role === filterRole;
    const matchesStatus = filterStatus === 'all' || member.status === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const teamStats = {
    total: teamMembers.length,
    active: teamMembers.filter(m => m.status === 'active').length,
    onLeave: teamMembers.filter(m => m.status === 'on_leave').length,
    avgSatisfaction: (teamMembers.reduce((acc, m) => acc + m.performance.satisfactionScore, 0) / teamMembers.length).toFixed(1)
  };

  return (
    <div className="flex flex-col max-w-[1600px] mx-auto px-8 py-6 gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-3">
            <Users className="w-7 h-7 text-blue-600" />
            Ekip Yönetimi
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Ekip üyelerini yönet ve performanslarını takip et</p>
        </div>
        <button
          onClick={() => setShowAddMember(true)}
          className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2"
        >
          <UserPlus className="w-5 h-5" />
          Yeni Ekip Üyesi Ekle
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Toplam Ekip</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100 mt-1">{teamStats.total}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Aktif Üyeler</p>
              <p className="text-2xl font-bold text-green-600 mt-1">{teamStats.active}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">İzinde</p>
              <p className="text-2xl font-bold text-yellow-600 mt-1">{teamStats.onLeave}</p>
            </div>
            <div className="p-3 bg-yellow-100 rounded-lg">
              <Calendar className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Ort. Memnuniyet</p>
              <p className="text-2xl font-bold text-purple-600 mt-1">{teamStats.avgSatisfaction}</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <Award className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Ekip üyesi ara (isim, email)..."
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          {/* Role Filter */}
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          >
            <option value="all">Tüm Roller</option>
            <option value="owner">Sahip</option>
            <option value="admin">Yönetici</option>
            <option value="agent">Temsilci</option>
            <option value="viewer">İzleyici</option>
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          >
            <option value="all">Tüm Durumlar</option>
            <option value="active">Aktif</option>
            <option value="inactive">Pasif</option>
            <option value="on_leave">İzinde</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex gap-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-4 py-2.5 rounded-lg font-medium transition-colors ${( viewMode === 'grid' ) ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200'}`}
            >
              Grid
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2.5 rounded-lg font-medium transition-colors ${( viewMode === 'list' ) ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200'}`}
            >
              Liste
            </button>
          </div>
        </div>
      </div>

      {/* Team Members Grid/List */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMembers.map((member) => (
            <div
              key={member.id}
              className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-gray-100">{member.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{member.department}</p>
                  </div>
                </div>
                <button className="p-2 hover:bg-gray-100 dark:bg-slate-700 rounded-lg transition-colors">
                  <MoreVertical className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                </button>
              </div>

              {/* Badges */}
              <div className="flex gap-2 mb-4">
                <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${getRoleBadgeColor(member.role)}`}>
                  {getRoleIcon(member.role)}
                  {getRoleLabel(member.role)}
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(member.status)}`}>
                  {getStatusLabel(member.status)}
                </span>
              </div>

              {/* Contact Info */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Mail className="w-4 h-4" />
                  {member.email}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Phone className="w-4 h-4" />
                  {member.phone}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Clock className="w-4 h-4" />
                  {member.lastActive}
                </div>
              </div>

              {/* Performance Stats */}
              <div className="pt-4 border-t border-gray-200 dark:border-slate-700">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Konuşmalar</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{formatNumber(member.performance.conversationsHandled)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Memnuniyet</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{member.performance.satisfactionScore}/5</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Ort. Yanıt</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{member.performance.avgResponseTime}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Görevler</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{formatNumber(member.performance.tasksCompleted)}</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => setSelectedMember(member)}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  Detaylar
                </button>
                <button className="px-4 py-2 border border-gray-200 dark:border-slate-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors">
                  <Edit className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-400 uppercase tracking-wider">Üye</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-400 uppercase tracking-wider">Rol</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-400 uppercase tracking-wider">Durum</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-400 uppercase tracking-wider">Performans</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-600 dark:text-gray-400 uppercase tracking-wider">Son Aktivite</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-600 dark:text-gray-400 uppercase tracking-wider">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredMembers.map((member) => (
                <tr key={member.id} className="hover:bg-gray-50 dark:bg-slate-900 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={member.avatar}
                        alt={member.name}
                        className="w-10 h-10 rounded-full"
                      />
                      <div>
                        <p className="font-medium text-gray-900 dark:text-gray-100">{member.name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{member.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium inline-flex items-center gap-1 ${getRoleBadgeColor(member.role)}`}>
                      {getRoleIcon(member.role)}
                      {getRoleLabel(member.role)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(member.status)}`}>
                      {getStatusLabel(member.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <div className="text-sm">
                        <p className="font-medium text-gray-900 dark:text-gray-100">{formatNumber(member.performance.conversationsHandled)} konuşma</p>
                        <p className="text-gray-600 dark:text-gray-400">{member.performance.satisfactionScore}/5 ⭐</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-gray-600 dark:text-gray-400">{member.lastActive}</p>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedMember(member)}
                        className="px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                      >
                        Detaylar
                      </button>
                      <button className="p-2 hover:bg-gray-100 dark:bg-slate-700 rounded-lg transition-colors">
                        <Edit className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                      </button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Member Modal */}
      {showAddMember && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-slate-700">
              <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Yeni Ekip Üyesi Ekle</h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Ad Soyad</label>
                  <input
                    type="text"
                    placeholder="Ahmet Yılmaz"
                    className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Email</label>
                  <input
                    type="email"
                    placeholder="ahmet@asistanapp.com"
                    className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Telefon</label>
                  <input
                    type="tel"
                    placeholder="+90 532 123 4567"
                    className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Rol</label>
                  <select className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500">
                    <option value="agent">Temsilci</option>
                    <option value="admin">Yönetici</option>
                    <option value="viewer">İzleyici</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Departman</label>
                  <input
                    type="text"
                    placeholder="Müşteri İlişkileri"
                    className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setShowAddMember(false)}
                className="px-5 py-2.5 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
              >
                İptal
              </button>
              <button
                onClick={() => {
                  alert('Yeni ekip üyesi eklendi!');
                  setShowAddMember(false);
                }}
                className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Ekle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Member Detail Modal */}
      {selectedMember && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <img
                    src={selectedMember.avatar}
                    alt={selectedMember.name}
                    className="w-16 h-16 rounded-full"
                  />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{selectedMember.name}</h2>
                    <p className="text-gray-600 dark:text-gray-400">{selectedMember.email}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedMember(null)}
                  className="p-2 hover:bg-gray-100 dark:bg-slate-700 rounded-lg transition-colors"
                >
                  <XCircle className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                </button>
              </div>
            </div>
            <div className="p-6 space-y-6">
              {/* Info Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-50 dark:bg-slate-900 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Rol</p>
                  <div className="flex items-center gap-2">
                    {getRoleIcon(selectedMember.role)}
                    <p className="font-medium text-gray-900 dark:text-gray-100">{getRoleLabel(selectedMember.role)}</p>
                  </div>
                </div>
                <div className="bg-gray-50 dark:bg-slate-900 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Durum</p>
                  <p className="font-medium text-gray-900 dark:text-gray-100">{getStatusLabel(selectedMember.status)}</p>
                </div>
                <div className="bg-gray-50 dark:bg-slate-900 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Departman</p>
                  <p className="font-medium text-gray-900 dark:text-gray-100">{selectedMember.department}</p>
                </div>
                <div className="bg-gray-50 dark:bg-slate-900 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Katılım Tarihi</p>
                  <p className="font-medium text-gray-900 dark:text-gray-100">{selectedMember.joinDate}</p>
                </div>
              </div>

              {/* Performance Metrics */}
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Performans Metrikleri
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-blue-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-blue-600 mb-1">Konuşmalar</p>
                    <p className="text-2xl font-bold text-blue-700">{formatNumber(selectedMember.performance.conversationsHandled)}</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-green-600 mb-1">Memnuniyet</p>
                    <p className="text-2xl font-bold text-green-700">{selectedMember.performance.satisfactionScore}/5</p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-purple-600 mb-1">Ort. Yanıt</p>
                    <p className="text-2xl font-bold text-purple-700">{selectedMember.performance.avgResponseTime}</p>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-4 text-center">
                    <p className="text-sm text-orange-600 mb-1">Görevler</p>
                    <p className="text-2xl font-bold text-orange-700">{formatNumber(selectedMember.performance.tasksCompleted)}</p>
                  </div>
                </div>
              </div>

              {/* Permissions */}
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-blue-600" />
                  Yetkiler
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedMember.permissions.map((permission, index) => (
                    <span
                      key={index}
                      className="px-3 py-1.5 bg-blue-100 text-blue-700 rounded-lg text-sm font-medium"
                    >
                      {permission}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-200 dark:border-slate-700 flex justify-end gap-3">
              <button
                onClick={() => setSelectedMember(null)}
                className="px-5 py-2.5 border border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
              >
                Kapat
              </button>
              <button className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2">
                <Edit className="w-4 h-4" />
                Düzenle
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamPage;

