/**
 * Team Chat Page - Internal Team Communication (Slack-like)
 * Firma sahibi ve çalışanlar arası iletişim
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  Hash,
  Lock,
  Users,
  Plus,
  Search,
  Settings,
  Bell,
  Pin,
  Star,
  MoreVertical,
  Send,
  Smile,
  Paperclip,
  AtSign,
  MessageSquare,
  Phone,
  Video,
  X,
  ChevronDown,
  Check,
  CheckCheck,
  Edit2,
  Trash2,
  Reply,
  Share2,
  Bookmark,
  FileText,
} from 'lucide-react';
import { useAuthStore } from '../../stores/auth-store';
import type { TeamChannel, TeamChatMessage, TeamPresence } from '../../types';

const TeamChatPage: React.FC = () => {
  const { user } = useAuthStore();
  const [channels, setChannels] = useState<TeamChannel[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<TeamChannel | null>(null);
  const [messages, setMessages] = useState<TeamChatMessage[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [showChannelSidebar, setShowChannelSidebar] = useState(true);
  const [showMemberSidebar, setShowMemberSidebar] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState<TeamPresence[]>([]);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Mock data - gerçek API'den gelecek
  useEffect(() => {
    loadMockData();
  }, []);

  const loadMockData = () => {
    const mockChannels: TeamChannel[] = [
      {
        id: '1',
        tenantId: 'tenant1',
        name: 'genel',
        description: 'Genel konuşmalar',
        type: 'public',
        createdBy: 'owner1',
        createdAt: '2024-01-01',
        updatedAt: '2024-01-15',
        members: [],
        unreadCount: 3,
        isPinned: true,
        metadata: { topic: 'Şirket geneli konuşmalar' },
      },
      {
        id: '2',
        tenantId: 'tenant1',
        name: 'satış-ekibi',
        description: 'Satış ekibi koordinasyonu',
        type: 'private',
        createdBy: 'owner1',
        createdAt: '2024-01-05',
        updatedAt: '2024-01-15',
        members: [],
        unreadCount: 0,
        isPinned: false,
        metadata: { topic: 'Satış stratejileri ve hedefler' },
      },
      {
        id: '3',
        tenantId: 'tenant1',
        name: 'Ahmet Yılmaz',
        type: 'direct',
        createdBy: 'owner1',
        createdAt: '2024-01-10',
        updatedAt: '2024-01-15',
        members: [],
        unreadCount: 1,
        isPinned: false,
        metadata: { avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ahmet' },
      },
    ];

    setChannels(mockChannels);
    if (mockChannels.length > 0) {
      setSelectedChannel(mockChannels[0]);
      loadMessagesForChannel(mockChannels[0].id);
    }
  };

  const loadMessagesForChannel = (channelId: string) => {
    // Mock messages
    const mockMessages: TeamChatMessage[] = [
      {
        id: '1',
        channelId,
        tenantId: 'tenant1',
        userId: 'user1',
        content: 'Merhaba ekip! Yeni kampanyayı görüştünüz mü?',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        type: 'text',
        mentions: [],
        reactions: [
          { emoji: '👍', userId: 'user2', timestamp: new Date().toISOString() },
          { emoji: '❤️', userId: 'user3', timestamp: new Date().toISOString() },
        ],
        attachments: [],
        isPinned: false,
        metadata: { isEdited: false, isForwarded: false },
      },
      {
        id: '2',
        channelId,
        tenantId: 'tenant1',
        userId: 'user2',
        content: 'Evet, çok güzel hazırlanmış. @ahmet ile pazartesi sunuma hazırlanıyoruz.',
        timestamp: new Date(Date.now() - 1800000).toISOString(),
        type: 'text',
        mentions: ['user3'],
        reactions: [],
        attachments: [],
        threadRepliesCount: 2,
        isPinned: false,
        metadata: { isEdited: false, isForwarded: false },
      },
    ];

    setMessages(mockMessages);
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedChannel) return;

    const newMessage: TeamChatMessage = {
      id: Date.now().toString(),
      channelId: selectedChannel.id,
      tenantId: user?.tenantId || '',
      userId: user?.id || '',
      content: messageInput,
      timestamp: new Date().toISOString(),
      type: 'text',
      mentions: [],
      reactions: [],
      attachments: [],
      isPinned: false,
      metadata: { isEdited: false, isForwarded: false },
    };

    setMessages([...messages, newMessage]);
    setMessageInput('');
    scrollToBottom();
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' });
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-slate-900">
      {/* Channel Sidebar */}
      <div
        className={`${
          showChannelSidebar ? 'w-64' : 'w-0'
        } bg-purple-900 dark:bg-purple-950 text-white transition-all duration-300 overflow-hidden flex-shrink-0`}
      >
        <div className="flex flex-col h-full">
          {/* Workspace Header */}
          <div className="p-4 border-b border-purple-800 dark:border-purple-900">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-lg truncate">{user?.tenantId || 'Workspace'}</h2>
              <button className="p-1 hover:bg-purple-800 dark:hover:bg-purple-900 rounded">
                <ChevronDown className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Channel List */}
          <div className="flex-1 overflow-y-auto p-2">
            {/* Search */}
            <div className="mb-4 px-2">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-300" />
                <input
                  type="text"
                  placeholder="Ara..."
                  className="w-full pl-8 pr-3 py-1.5 bg-purple-800 dark:bg-purple-900 text-white placeholder-purple-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            {/* Threads */}
            <div className="mb-4">
              <button className="w-full flex items-center gap-2 px-2 py-1.5 hover:bg-purple-800 dark:hover:bg-purple-900 rounded text-sm">
                <MessageSquare className="w-4 h-4" />
                <span>Konular</span>
              </button>
            </div>

            {/* Channels */}
            <div className="mb-4">
              <div className="flex items-center justify-between px-2 mb-2">
                <span className="text-xs font-semibold text-purple-300">KANALLAR</span>
                <button
                  onClick={() => setShowCreateChannel(true)}
                  className="p-0.5 hover:bg-purple-800 dark:hover:bg-purple-900 rounded"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              {channels
                .filter((ch) => ch.type === 'public' || ch.type === 'private')
                .map((channel) => (
                  <button
                    key={channel.id}
                    onClick={() => {
                      setSelectedChannel(channel);
                      loadMessagesForChannel(channel.id);
                    }}
                    className={`w-full flex items-center justify-between gap-2 px-2 py-1.5 rounded text-sm mb-1 ${
                      selectedChannel?.id === channel.id
                        ? 'bg-purple-700 dark:bg-purple-800 text-white'
                        : 'hover:bg-purple-800 dark:hover:bg-purple-900'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {channel.type === 'private' ? (
                        <Lock className="w-4 h-4 flex-shrink-0" />
                      ) : (
                        <Hash className="w-4 h-4 flex-shrink-0" />
                      )}
                      <span className="truncate">{channel.name}</span>
                    </div>
                    {channel.unreadCount > 0 && (
                      <span className="px-1.5 py-0.5 bg-red-500 text-white text-xs rounded-full flex-shrink-0">
                        {channel.unreadCount}
                      </span>
                    )}
                  </button>
                ))}
            </div>

            {/* Direct Messages */}
            <div className="mb-4">
              <div className="flex items-center justify-between px-2 mb-2">
                <span className="text-xs font-semibold text-purple-300">DİREKT MESAJLAR</span>
                <button className="p-0.5 hover:bg-purple-800 dark:hover:bg-purple-900 rounded">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              {channels
                .filter((ch) => ch.type === 'direct')
                .map((channel) => (
                  <button
                    key={channel.id}
                    onClick={() => {
                      setSelectedChannel(channel);
                      loadMessagesForChannel(channel.id);
                    }}
                    className={`w-full flex items-center justify-between gap-2 px-2 py-1.5 rounded text-sm mb-1 ${
                      selectedChannel?.id === channel.id
                        ? 'bg-purple-700 dark:bg-purple-800 text-white'
                        : 'hover:bg-purple-800 dark:hover:bg-purple-900'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="relative">
                        <img
                          src={channel.metadata?.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=default'}
                          alt={channel.name}
                          className="w-5 h-5 rounded"
                        />
                        <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 border-2 border-purple-900 rounded-full" />
                      </div>
                      <span className="truncate">{channel.name}</span>
                    </div>
                    {channel.unreadCount > 0 && (
                      <span className="px-1.5 py-0.5 bg-red-500 text-white text-xs rounded-full flex-shrink-0">
                        {channel.unreadCount}
                      </span>
                    )}
                  </button>
                ))}
            </div>
          </div>

          {/* User Profile */}
          <div className="p-3 border-t border-purple-800 dark:border-purple-900">
            <div className="flex items-center gap-2">
              <div className="relative">
                <img
                  src={user?.profile?.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=user'}
                  alt={user?.name}
                  className="w-8 h-8 rounded"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-purple-900 rounded-full" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.name}</p>
                <p className="text-xs text-purple-300">🟢 Aktif</p>
              </div>
              <button className="p-1 hover:bg-purple-800 dark:hover:bg-purple-900 rounded">
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {selectedChannel ? (
          <>
            {/* Chat Header */}
            <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 px-4 py-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowChannelSidebar(!showChannelSidebar)}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded lg:hidden"
                  >
                    <Hash className="w-5 h-5" />
                  </button>
                  <div>
                    <div className="flex items-center gap-2">
                      {selectedChannel.type === 'direct' ? (
                        <img
                          src={selectedChannel.metadata?.avatar || ''}
                          alt={selectedChannel.name}
                          className="w-6 h-6 rounded"
                        />
                      ) : selectedChannel.type === 'private' ? (
                        <Lock className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      ) : (
                        <Hash className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      )}
                      <h3 className="font-bold text-gray-900 dark:text-white">{selectedChannel.name}</h3>
                      {selectedChannel.isPinned && <Pin className="w-4 h-4 text-orange-500" />}
                    </div>
                    {selectedChannel.metadata?.topic && (
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">
                        {selectedChannel.metadata.topic}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                    <Phone className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                    <Video className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button
                    onClick={() => setShowMemberSidebar(!showMemberSidebar)}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded"
                  >
                    <Users className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                    <Search className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                    <Settings className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                  </button>
                </div>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-white dark:bg-slate-900">
              <div className="max-w-4xl mx-auto space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className="group hover:bg-gray-50 dark:hover:bg-slate-800 -mx-4 px-4 py-2 rounded transition-colors"
                  >
                    <div className="flex gap-3">
                      <img
                        src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${message.userId}`}
                        alt="User"
                        className="w-10 h-10 rounded flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="font-bold text-gray-900 dark:text-white">Kullanıcı {message.userId}</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatTime(message.timestamp)}
                          </span>
                          {message.metadata?.isEdited && (
                            <span className="text-xs text-gray-400 dark:text-gray-500">(düzenlendi)</span>
                          )}
                        </div>
                        <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap break-words">
                          {message.content}
                        </p>

                        {/* Reactions */}
                        {message.reactions.length > 0 && (
                          <div className="flex gap-1 mt-2">
                            {message.reactions.map((reaction, idx) => (
                              <button
                                key={idx}
                                className="px-2 py-0.5 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/30 border border-blue-200 dark:border-blue-800 rounded-full text-sm"
                              >
                                {reaction.emoji} 1
                              </button>
                            ))}
                            <button className="px-2 py-0.5 hover:bg-gray-100 dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-full text-sm">
                              <Smile className="w-3 h-3" />
                            </button>
                          </div>
                        )}

                        {/* Thread Reply */}
                        {message.threadRepliesCount && message.threadRepliesCount > 0 && (
                          <button className="flex items-center gap-2 mt-2 text-sm text-blue-600 dark:text-blue-400 hover:underline">
                            <Reply className="w-4 h-4" />
                            {message.threadRepliesCount} yanıt
                          </button>
                        )}
                      </div>

                      {/* Action Buttons (shown on hover) */}
                      <div className="hidden group-hover:flex items-start gap-1">
                        <button className="p-1.5 hover:bg-white dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded">
                          <Smile className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </button>
                        <button className="p-1.5 hover:bg-white dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded">
                          <Reply className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </button>
                        <button className="p-1.5 hover:bg-white dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded">
                          <Share2 className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </button>
                        <button className="p-1.5 hover:bg-white dark:hover:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded">
                          <MoreVertical className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* Message Input */}
            <div className="bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-slate-700 p-4">
              <div className="max-w-4xl mx-auto">
                <div className="bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-600 rounded-lg focus-within:border-blue-500 dark:focus-within:border-blue-400">
                  <div className="flex items-start gap-2 p-3">
                    <textarea
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder={`#${selectedChannel.name} kanalına mesaj gönder...`}
                      className="flex-1 bg-transparent text-gray-900 dark:text-white placeholder-gray-500 resize-none focus:outline-none min-h-[60px] max-h-[200px]"
                      rows={2}
                    />
                  </div>
                  <div className="flex items-center justify-between px-3 pb-2">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                        <Paperclip className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      </button>
                      <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                        <AtSign className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      </button>
                      <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                        <Smile className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      </button>
                      <button className="p-1.5 hover:bg-gray-100 dark:hover:bg-slate-700 rounded">
                        <FileText className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                      </button>
                    </div>
                    <button
                      onClick={handleSendMessage}
                      disabled={!messageInput.trim()}
                      className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded flex items-center gap-2 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                      Gönder
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">Bir kanal seçin veya yeni konuşma başlatın</p>
            </div>
          </div>
        )}
      </div>

      {/* Member Sidebar (Right) */}
      {showMemberSidebar && selectedChannel && (
        <div className="w-64 bg-white dark:bg-slate-800 border-l border-gray-200 dark:border-slate-700 overflow-y-auto">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900 dark:text-white">Üyeler</h3>
              <button
                onClick={() => setShowMemberSidebar(false)}
                className="p-1 hover:bg-gray-100 dark:hover:bg-slate-700 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mock members */}
            <div className="space-y-2">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center gap-2 p-2 hover:bg-gray-50 dark:hover:bg-slate-700 rounded">
                  <div className="relative">
                    <img
                      src={`https://api.dicebear.com/7.x/avataaars/svg?seed=user${i}`}
                      alt="User"
                      className="w-8 h-8 rounded"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-white dark:border-slate-800 rounded-full" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white truncate">Kullanıcı {i}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Aktif</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamChatPage;


