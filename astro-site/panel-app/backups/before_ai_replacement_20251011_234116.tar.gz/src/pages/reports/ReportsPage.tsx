import React, { useState } from 'react';
import {
  TrendingUp,
  Users,
  MessageCircle,
  Clock,
  Award,
  DollarSign,
  Activity,
  AlertCircle,
  Download,
  Calendar,
  Filter,
  BarChart3,
  PieChart,
  LineChart,
  X,
  CheckCircle,
  XCircle,
  ArrowRight,
  Zap,
  Target,
  TrendingDown,
  FileText
} from 'lucide-react';
import { exportToPDF, exportToExcel, exportToCSV } from '../../utils/exportHelpers';
import { formatNumber, formatCurrency } from '../../utils/formatters';

// Ana rapor kategorileri
type ReportCategory = 'ai' | 'channels' | 'satisfaction' | 'time' | 'team' | 'conversion' | 'financial' | 'trends' | 'sla';

interface QuickStat {
  label: string;
  value: string | number;
  change: number;
  icon: React.ReactNode;
  color: string;
}

const ReportsPage: React.FC = () => {
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');
  const [selectedCategory, setSelectedCategory] = useState<ReportCategory | 'all'>('all');
  const [detailModalOpen, setDetailModalOpen] = useState<ReportCategory | null>(null);

  // Tarih aralığına göre veri çarpanı
  const getDataMultiplier = () => {
    switch (dateRange) {
      case '7d': return 0.25;
      case '30d': return 1;
      case '90d': return 2.8;
      case '1y': return 11.5;
      default: return 1;
    }
  };

  const multiplier = getDataMultiplier();

  // Hızlı istatistikler (tarih aralığına göre dinamik)
  const baseConversations = 2744;
  const totalConversations = Math.round(baseConversations * multiplier);
  
  const quickStats: QuickStat[] = [
    {
      label: 'Toplam Konuşma',
      value: totalConversations.toLocaleString('tr-TR'),
      change: 12.5,
      icon: <MessageCircle className="w-6 h-6" />,
      color: 'bg-blue-500'
    },
    {
      label: 'AI Başarı Oranı',
      value: '%87',
      change: 5.2,
      icon: <Activity className="w-6 h-6" />,
      color: 'bg-purple-500'
    },
    {
      label: 'Dönüşüm Oranı',
      value: '%47.3',
      change: 8.4,
      icon: <TrendingUp className="w-6 h-6" />,
      color: 'bg-green-500'
    },
    {
      label: 'Müşteri Memnuniyeti',
      value: '4.6/5.0',
      change: 2.1,
      icon: <Award className="w-6 h-6" />,
      color: 'bg-orange-500'
    }
  ];

  const dateRangeLabels = {
    '7d': 'Son 7 Gün',
    '30d': 'Son 30 Gün',
    '90d': 'Son 90 Gün',
    '1y': 'Son 1 Yıl'
  };

  // PDF Export
  const handleExportPDF = () => {
    const exportData = {
      title: 'AsistanApp Performans Raporu',
      subtitle: selectedCategory === 'all' ? 'Tüm Kategoriler' : getCategoryLabel(selectedCategory),
      dateRange: `Rapor Dönemi: ${dateRangeLabels[dateRange]}`,
      stats: quickStats.map(stat => ({
        label: stat.label,
        value: stat.value
      })),
      tables: [
        {
          title: 'AI Performans Metrikleri',
          headers: ['Metrik', 'Değer', 'Değişim'],
          rows: [
            ['Toplam AI Yanıtı', formatNumber(Math.round(2134 * multiplier)), '+12%'],
            ['Başarılı Çözümler', formatNumber(Math.round(1876 * multiplier)), '+15%'],
            ['Ortalama Yanıt Süresi', '2.3 sn', '-8%'],
            ['AI Güven Skoru', '94.2%', '+3%']
          ]
        },
        {
          title: 'Kanal Performansı',
          headers: ['Kanal', 'Konuşma Sayısı', 'Dönüşüm Oranı'],
          rows: [
            ['WhatsApp', formatNumber(Math.round(980 * multiplier)), '52%'],
            ['Instagram', formatNumber(Math.round(756 * multiplier)), '48%'],
            ['Facebook', formatNumber(Math.round(612 * multiplier)), '45%'],
            ['Web Widget', formatNumber(Math.round(396 * multiplier)), '51%']
          ]
        },
        {
          title: 'Ekip Performansı',
          headers: ['Ekip Üyesi', 'Çözülen Konuşma', 'Memnuniyet'],
          rows: [
            ['Ahmet Yılmaz', formatNumber(Math.round(234 * multiplier)), '4.8/5'],
            ['Ayşe Demir', formatNumber(Math.round(198 * multiplier)), '4.7/5'],
            ['Mehmet Kaya', formatNumber(Math.round(167 * multiplier)), '4.6/5']
          ]
        }
      ]
    };

    exportToPDF(exportData);
  };

  // Excel Export
  const handleExportExcel = () => {
    const exportData = {
      title: 'AsistanApp Performans Raporu',
      subtitle: selectedCategory === 'all' ? 'Tüm Kategoriler' : getCategoryLabel(selectedCategory),
      dateRange: `Rapor Dönemi: ${dateRangeLabels[dateRange]}`,
      stats: quickStats.map(stat => ({
        label: stat.label,
        value: stat.value
      })),
      tables: [
        {
          title: 'AI Performans Metrikleri',
          headers: ['Metrik', 'Değer', 'Değişim'],
          rows: [
            ['Toplam AI Yanıtı', formatNumber(Math.round(2134 * multiplier)), '+12%'],
            ['Başarılı Çözümler', formatNumber(Math.round(1876 * multiplier)), '+15%'],
            ['Ortalama Yanıt Süresi', '2.3 sn', '-8%'],
            ['AI Güven Skoru', '94.2%', '+3%']
          ]
        },
        {
          title: 'Kanal Performansı',
          headers: ['Kanal', 'Konuşma Sayısı', 'Dönüşüm Oranı'],
          rows: [
            ['WhatsApp', formatNumber(Math.round(980 * multiplier)), '52%'],
            ['Instagram', formatNumber(Math.round(756 * multiplier)), '48%'],
            ['Facebook', formatNumber(Math.round(612 * multiplier)), '45%'],
            ['Web Widget', formatNumber(Math.round(396 * multiplier)), '51%']
          ]
        },
        {
          title: 'Ekip Performansı',
          headers: ['Ekip Üyesi', 'Çözülen Konuşma', 'Memnuniyet'],
          rows: [
            ['Ahmet Yılmaz', formatNumber(Math.round(234 * multiplier)), '4.8/5'],
            ['Ayşe Demir', formatNumber(Math.round(198 * multiplier)), '4.7/5'],
            ['Mehmet Kaya', formatNumber(Math.round(167 * multiplier)), '4.6/5']
          ]
        }
      ]
    };

    exportToExcel(exportData);
  };

  // CSV Export
  const handleExportCSV = () => {
    const exportData = {
      title: 'AsistanApp Performans Raporu',
      subtitle: selectedCategory === 'all' ? 'Tüm Kategoriler' : getCategoryLabel(selectedCategory),
      dateRange: `Rapor Dönemi: ${dateRangeLabels[dateRange]}`,
      stats: quickStats.map(stat => ({
        label: stat.label,
        value: stat.value
      })),
      tables: [
        {
          title: 'AI Performans Metrikleri',
          headers: ['Metrik', 'Değer', 'Değişim'],
          rows: [
            ['Toplam AI Yanıtı', formatNumber(Math.round(2134 * multiplier)), '+12%'],
            ['Başarılı Çözümler', formatNumber(Math.round(1876 * multiplier)), '+15%'],
            ['Ortalama Yanıt Süresi', '2.3 sn', '-8%'],
            ['AI Güven Skoru', '94.2%', '+3%']
          ]
        }
      ]
    };

    exportToCSV(exportData);
  };

  const getCategoryLabel = (category: ReportCategory | 'all'): string => {
    const labels: Record<ReportCategory | 'all', string> = {
      'all': 'Tüm Kategoriler',
      'ai': 'AI Performans',
      'channels': 'Kanal Performansı',
      'satisfaction': 'Müşteri Memnuniyeti',
      'time': 'Zaman Bazlı Analiz',
      'team': 'Ekip Performansı',
      'conversion': 'Randevu & Dönüşüm',
      'financial': 'Finansal Tahminler',
      'trends': 'Trend & Tahmin Analizi',
      'sla': 'Acil Durum & SLA'
    };
    return labels[category] || 'Rapor';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700">
        <div className="px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4 sm:mb-6">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">Raporlar & Analizler</h1>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">Detaylı performans metrikleri ve istatistikler</p>
            </div>

            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              {/* Tarih Filtresi */}
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors"
              >
                {Object.entries(dateRangeLabels).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>

              {/* Export Butonları */}
              <button 
                onClick={handleExportPDF}
                className="px-3 sm:px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors flex items-center gap-1 sm:gap-2"
              >
                <Download className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">PDF</span>
              </button>
              <button 
                onClick={handleExportExcel}
                className="px-3 sm:px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors flex items-center gap-1 sm:gap-2"
              >
                <Download className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Excel</span>
              </button>
              <button 
                onClick={handleExportCSV}
                className="px-3 sm:px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-xs sm:text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-600 transition-colors flex items-center gap-1 sm:gap-2"
              >
                <FileText className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">CSV</span>
              </button>
            </div>
          </div>

          {/* Hızlı İstatistikler */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickStats.map((stat, index) => (
              <div key={index} className="bg-gradient-to-br from-white to-gray-50 dark:from-slate-700 dark:to-slate-800 border border-gray-200 dark:border-slate-600 rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm text-gray-600 dark:text-gray-400 font-medium mb-1">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stat.value}</p>
                    <div className="flex items-center gap-1 mt-2">
                      <span className={`text-xs font-semibold ${stat.change >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                        {stat.change >= 0 ? '↗' : '↘'} {Math.abs(stat.change)}%
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-400">vs geçen ay</span>
                    </div>
                  </div>
                  <div className={`${stat.color} text-white p-3 rounded-xl`}>
                    {stat.icon}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Ana İçerik */}
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        {/* Kategori Filtreleri */}
        <div className="mb-4 sm:mb-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
                selectedCategory === 'all'
                  ? 'bg-blue-500 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600'
              }`}
            >
              Tüm Raporlar
            </button>
            <button
              onClick={() => setSelectedCategory('ai')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap flex items-center gap-1 sm:gap-2 ${
                selectedCategory === 'ai'
                  ? 'bg-purple-500 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600'
              }`}
            >
              <Activity className="w-3 h-3 sm:w-4 sm:h-4" />
              AI Performans
            </button>
            <button
              onClick={() => setSelectedCategory('channels')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap flex items-center gap-1 sm:gap-2 ${
                selectedCategory === 'channels'
                  ? 'bg-blue-500 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600'
              }`}
            >
              <BarChart3 className="w-3 h-3 sm:w-4 sm:h-4" />
              Kanallar
            </button>
            <button
              onClick={() => setSelectedCategory('satisfaction')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap flex items-center gap-1 sm:gap-2 ${
                selectedCategory === 'satisfaction'
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600'
              }`}
            >
              <Award className="w-3 h-3 sm:w-4 sm:h-4" />
              Memnuniyet
            </button>
            <button
              onClick={() => setSelectedCategory('team')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap flex items-center gap-1 sm:gap-2 ${
                selectedCategory === 'team'
                  ? 'bg-green-500 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600'
              }`}
            >
              <Users className="w-3 h-3 sm:w-4 sm:h-4" />
              Ekip
            </button>
            <button
              onClick={() => setSelectedCategory('conversion')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap flex items-center gap-1 sm:gap-2 ${
                selectedCategory === 'conversion'
                  ? 'bg-pink-500 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-slate-600 hover:bg-gray-50 dark:hover:bg-slate-600'
              }`}
            >
              <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4" />
              Dönüşüm
            </button>
          </div>
        </div>

        {/* Rapor Kartları Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AI Performans Raporu */}
          {(selectedCategory === 'all' || selectedCategory === 'ai') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-purple-100 text-purple-600 p-3 rounded-xl">
                    <Activity className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">AI Performans Raporu</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Yapay zeka başarı metrikleri</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-purple-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Başarı Oranı</p>
                    <p className="text-3xl font-bold text-purple-600">87%</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Tamamlanan</p>
                    <p className="text-3xl font-bold text-green-600">{Math.round(2344 * multiplier).toLocaleString('tr-TR')}</p>
                  </div>
                  <div className="bg-amber-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Devredilen</p>
                    <p className="text-3xl font-bold text-amber-600">{Math.round(352 * multiplier).toLocaleString('tr-TR')}</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">Ort. Yanıt</p>
                    <p className="text-3xl font-bold text-blue-600">12sn</p>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('ai')}
                  className="w-full py-2.5 bg-purple-500 text-white font-medium rounded-lg hover:bg-purple-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Kanal Performans Analizi */}
          {(selectedCategory === 'all' || selectedCategory === 'channels') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 text-blue-600 p-3 rounded-xl">
                    <BarChart3 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Kanal Performansı</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Kanal bazlı dağılım ve metrikler</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">WhatsApp</span>
                    <span className="font-semibold text-gray-900 dark:text-gray-100">45% ({Math.round(1234 * multiplier).toLocaleString('tr-TR')})</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '45%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Instagram</span>
                    <span className="font-semibold text-gray-900 dark:text-gray-100">30% ({Math.round(823 * multiplier).toLocaleString('tr-TR')})</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-pink-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Telefon</span>
                    <span className="font-semibold text-gray-900 dark:text-gray-100">15% ({Math.round(412 * multiplier).toLocaleString('tr-TR')})</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Web Widget</span>
                    <span className="font-semibold text-gray-900 dark:text-gray-100">8% ({Math.round(220 * multiplier).toLocaleString('tr-TR')})</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-orange-500 h-2 rounded-full" style={{ width: '8%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Facebook</span>
                    <span className="font-semibold text-gray-900 dark:text-gray-100">2% ({Math.round(55 * multiplier).toLocaleString('tr-TR')})</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '2%' }}></div>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('channels')}
                  className="w-full py-2.5 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors mt-4"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Müşteri Memnuniyeti */}
          {(selectedCategory === 'all' || selectedCategory === 'satisfaction') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-orange-100 text-orange-600 p-3 rounded-xl">
                    <Award className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Müşteri Memnuniyeti</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">NPS ve memnuniyet skorları</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="text-center bg-gradient-to-br from-orange-50 to-yellow-50 rounded-lg p-6">
                  <p className="text-sm text-gray-600 mb-2">Genel Memnuniyet</p>
                  <p className="text-5xl font-bold text-orange-600">4.6</p>
                  <p className="text-lg text-gray-500">/5.0</p>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span key={star} className={`text-2xl ${star <= 4.6 ? 'text-orange-400' : 'text-gray-300'}`}>★</span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-green-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-600 mb-1">Promoter</p>
                    <p className="text-xl font-bold text-green-600">78%</p>
                    <p className="text-xs text-gray-500 mt-1">{Math.round(2142 * multiplier).toLocaleString('tr-TR')} müşteri</p>
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-600 mb-1">Passive</p>
                    <p className="text-xl font-bold text-gray-600 dark:text-gray-400">16%</p>
                    <p className="text-xs text-gray-500 mt-1">{Math.round(439 * multiplier).toLocaleString('tr-TR')} müşteri</p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-3 text-center">
                    <p className="text-xs text-gray-600 mb-1">Detractor</p>
                    <p className="text-xl font-bold text-red-600">6%</p>
                    <p className="text-xs text-gray-500 mt-1">{Math.round(165 * multiplier).toLocaleString('tr-TR')} müşteri</p>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('satisfaction')}
                  className="w-full py-2.5 bg-orange-500 text-white font-medium rounded-lg hover:bg-orange-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Ekip Performansı */}
          {(selectedCategory === 'all' || selectedCategory === 'team') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 text-green-600 p-3 rounded-xl">
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Ekip Performansı</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Takım üyesi metrikleri</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded-r-lg">
                  <div className="flex items-center gap-3">
                    <div className="bg-yellow-100 text-yellow-700 rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      1
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-gray-100">Dr. Ayşe Yılmaz</p>
                      <p className="text-xs text-gray-500">234 çözüm</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-yellow-600">⭐ 4.9</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 border-l-4 border-gray-300 rounded-r-lg">
                  <div className="flex items-center gap-3">
                    <div className="bg-gray-200 text-gray-600 rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      2
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-gray-100">Resepsiyonist Elif</p>
                      <p className="text-xs text-gray-500">198 çözüm</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-600 dark:text-gray-400">⭐ 4.7</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-purple-50 border-l-4 border-purple-300 rounded-r-lg">
                  <div className="flex items-center gap-3">
                    <div className="bg-purple-200 text-purple-700 rounded-full w-8 h-8 flex items-center justify-center font-bold">
                      3
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-gray-100">AI Asistan</p>
                      <p className="text-xs text-gray-500">1,234 çözüm</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-purple-600">⭐ 4.6</p>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('team')}
                  className="w-full py-2.5 bg-green-500 text-white font-medium rounded-lg hover:bg-green-600 transition-colors mt-4"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Randevu & Dönüşüm */}
          {(selectedCategory === 'all' || selectedCategory === 'conversion') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-pink-100 text-pink-600 p-3 rounded-xl">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Dönüşüm Hunnel</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Randevu dönüşüm metrikleri</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Toplam Mesaj</span>
                    <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">2,744</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-blue-500 h-3 rounded-full" style={{ width: '100%' }}></div>
                  </div>
                </div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Randevu Talebi</span>
                    <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">1,876</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-green-500 h-3 rounded-full" style={{ width: '68%' }}></div>
                  </div>
                </div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Onaylanan</span>
                    <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">1,523</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-purple-500 h-3 rounded-full" style={{ width: '55%' }}></div>
                  </div>
                </div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Gerçekleşen</span>
                    <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">1,298</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-pink-500 h-3 rounded-full" style={{ width: '47%' }}></div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg p-4 mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Genel Dönüşüm Oranı</span>
                    <span className="text-2xl font-bold text-pink-600">47.3%</span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs font-semibold text-green-600">↗ +12%</span>
                    <span className="text-xs text-gray-500">{dateRange === '7d' ? 'geçen haftaya göre' : dateRange === '30d' ? 'geçen aya göre' : dateRange === '90d' ? 'geçen çeyreğe göre' : 'geçen yıla göre'}</span>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('conversion')}
                  className="w-full py-2.5 bg-pink-500 text-white font-medium rounded-lg hover:bg-pink-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Zaman Analizi */}
          {(selectedCategory === 'all' || selectedCategory === 'time') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-indigo-100 text-indigo-600 p-3 rounded-xl">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Zaman Analizi</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Gün ve saat bazlı yoğunluk</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-sm text-gray-500 dark:text-gray-400">En yoğun günler ve saatler</p>
                <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-lg p-4">
                  <p className="text-sm font-semibold text-indigo-900 mb-2">🏆 Peak Zaman</p>
                  <p className="text-2xl font-bold text-indigo-600">Pazartesi 09:00-11:00</p>
                  <p className="text-sm text-gray-600 mt-1">Ortalama 45 konuşma/saat</p>
                </div>
                
                <button 
                  onClick={() => setDetailModalOpen('time')}
                  className="w-full py-2.5 bg-indigo-500 text-white font-medium rounded-lg hover:bg-indigo-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Finansal Tahminler */}
          {(selectedCategory === 'all' || selectedCategory === 'financial') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-emerald-100 text-emerald-600 p-3 rounded-xl">
                    <DollarSign className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Finansal Tahminler</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Gelir ve ROI analizi</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-emerald-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">{dateRange === '7d' ? 'Son 7 Gün' : dateRange === '30d' ? 'Bu Ay' : dateRange === '90d' ? 'Son 3 Ay' : 'Bu Yıl'} Gelir</p>
                    <p className="text-2xl font-bold text-emerald-600">₺{Math.round(187400 * multiplier).toLocaleString('tr-TR')}</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="text-sm text-gray-600 mb-1">AI ROI</p>
                    <p className="text-2xl font-bold text-blue-600">+425%</p>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('financial')}
                  className="w-full py-2.5 bg-emerald-500 text-white font-medium rounded-lg hover:bg-emerald-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* Trend & Tahmin Analizi */}
          {(selectedCategory === 'all' || selectedCategory === 'trends') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-cyan-100 text-cyan-600 p-3 rounded-xl">
                    <LineChart className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">Trend Analizi</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Gelecek tahminleri</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">{dateRange === '7d' ? 'Gelecek Hafta' : dateRange === '30d' ? 'Gelecek Ay' : dateRange === '90d' ? 'Gelecek Çeyrek' : 'Gelecek Yıl'} Tahmini</p>
                  <p className="text-2xl font-bold text-cyan-600">+18% artış</p>
                  <p className="text-xs text-gray-500 mt-1">~{Math.round(totalConversations * 1.18).toLocaleString('tr-TR')} konuşma bekleniyor</p>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('trends')}
                  className="w-full py-2.5 bg-cyan-500 text-white font-medium rounded-lg hover:bg-cyan-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}

          {/* SLA & Acil Durum Raporları */}
          {(selectedCategory === 'all' || selectedCategory === 'sla') && (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-red-100 text-red-600 p-3 rounded-xl">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">SLA & Acil Durumlar</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Yanıt süreleri ve kritik konular</p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-green-50 rounded-lg p-3 border-l-4 border-green-500">
                    <p className="text-xs text-gray-600 mb-1">SLA Uyumu</p>
                    <p className="text-2xl font-bold text-green-600">94%</p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-3 border-l-4 border-red-500">
                    <p className="text-xs text-gray-600 mb-1">Acil Durumlar</p>
                    <p className="text-2xl font-bold text-red-600">{Math.round(12 * multiplier)}</p>
                  </div>
                </div>

                <button 
                  onClick={() => setDetailModalOpen('sla')}
                  className="w-full py-2.5 bg-red-500 text-white font-medium rounded-lg hover:bg-red-600 transition-colors"
                >
                  Detaylı Raporu Görüntüle
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Detay Modalleri */}
      {detailModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="sticky top-0 bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-600 px-6 py-4 flex items-center justify-between z-10">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {detailModalOpen === 'ai' && '🤖 AI Performans Detaylı Raporu'}
                {detailModalOpen === 'channels' && '📊 Kanal Performans Detaylı Raporu'}
                {detailModalOpen === 'satisfaction' && '⭐ Müşteri Memnuniyeti Detaylı Raporu'}
                {detailModalOpen === 'team' && '👥 Ekip Performansı Detaylı Raporu'}
                {detailModalOpen === 'conversion' && '📈 Dönüşüm Detaylı Raporu'}
                {detailModalOpen === 'time' && '⏰ Zaman Analizi Detaylı Raporu'}
                {detailModalOpen === 'financial' && '💰 Finansal Tahminler Detaylı Raporu'}
                {detailModalOpen === 'trends' && '📉 Trend Analizi Detaylı Raporu'}
                {detailModalOpen === 'sla' && '🚨 SLA & Acil Durumlar Detaylı Raporu'}
              </h2>
              <button
                onClick={() => setDetailModalOpen(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-gray-500" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {/* AI Performans Detay */}
              {detailModalOpen === 'ai' && (
                <div className="space-y-6">
                  {/* Özet Kartlar */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-4 border border-purple-200">
                      <div className="flex items-center justify-between mb-2">
                        <Activity className="w-8 h-8 text-purple-600" />
                        <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">+5.2%</span>
                      </div>
                      <p className="text-sm text-purple-700 font-medium">Başarı Oranı</p>
                      <p className="text-3xl font-bold text-purple-900">87%</p>
                    </div>
                    <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4 border border-green-200">
                      <div className="flex items-center justify-between mb-2">
                        <CheckCircle className="w-8 h-8 text-green-600" />
                      </div>
                      <p className="text-sm text-green-700 font-medium">Başarılı Çözüm</p>
                      <p className="text-3xl font-bold text-green-900">2,344</p>
                    </div>
                    <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl p-4 border border-amber-200">
                      <div className="flex items-center justify-between mb-2">
                        <Users className="w-8 h-8 text-amber-600" />
                      </div>
                      <p className="text-sm text-amber-700 font-medium">İnsana Devredilen</p>
                      <p className="text-3xl font-bold text-amber-900">352</p>
                    </div>
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 border border-blue-200">
                      <div className="flex items-center justify-between mb-2">
                        <Zap className="w-8 h-8 text-blue-600" />
                      </div>
                      <p className="text-sm text-blue-700 font-medium">Ort. Yanıt Süresi</p>
                      <p className="text-3xl font-bold text-blue-900">12sn</p>
                    </div>
                  </div>

                  {/* AI Tıkanma Nedenleri */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">🔍 AI Tıkanma Nedenleri (Top 5)</h3>
                    <div className="space-y-3">
                      {[
                        { reason: 'Kompleks implant tedavisi bilgileri', count: 89, percentage: 25 },
                        { reason: 'Özel fiyat teklifi ve taksit seçenekleri', count: 67, percentage: 19 },
                        { reason: 'Sigorta geri ödemesi için özel formlar', count: 54, percentage: 15 },
                        { reason: 'Tedavi sonrası komplikasyon şikayetleri', count: 48, percentage: 14 },
                        { reason: 'İptal randevular için iade talepleri', count: 42, percentage: 12 }
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4">
                          <div className="flex-shrink-0 w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center font-bold text-sm">
                            {idx + 1}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{item.reason}</p>
                              <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{item.count} kez</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className="bg-purple-500 h-2 rounded-full" style={{ width: `${item.percentage * 4}%` }}></div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Başarı Trendleri */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">📈 Haftalık Başarı Trendi</h3>
                    <div className="space-y-2">
                      {[
                        { week: '1. Hafta', success: 83, fail: 17 },
                        { week: '2. Hafta', success: 85, fail: 15 },
                        { week: '3. Hafta', success: 86, fail: 14 },
                        { week: '4. Hafta', success: 87, fail: 13 }
                      ].map((item, idx) => (
                        <div key={idx}>
                          <div className="flex items-center justify-between mb-1 text-sm">
                            <span className="font-medium text-gray-700 dark:text-gray-300">{item.week}</span>
                            <span className="text-gray-500">{item.success}% başarı</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-3 flex overflow-hidden">
                            <div className="bg-green-500 h-3" style={{ width: `${item.success}%` }}></div>
                            <div className="bg-red-400 h-3" style={{ width: `${item.fail}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Maliyet Tasarrufu */}
                  <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-green-900 mb-2">💰 AI Sayesinde Maliyet Tasarrufu</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                      <div>
                        <p className="text-sm text-green-700 mb-1">Tasarruf Edilen Saat</p>
                        <p className="text-3xl font-bold text-green-900">1,172 saat</p>
                        <p className="text-xs text-green-600 mt-1">(2,344 konuşma x 30 dk)</p>
                      </div>
                      <div>
                        <p className="text-sm text-green-700 mb-1">Finansal Tasarruf</p>
                        <p className="text-3xl font-bold text-green-900">~₺234,400</p>
                        <p className="text-xs text-green-600 mt-1">(1,172 saat x ₺200/saat)</p>
                      </div>
                      <div>
                        <p className="text-sm text-green-700 mb-1">Ekip Verimliliği</p>
                        <p className="text-3xl font-bold text-green-900">+340%</p>
                        <p className="text-xs text-green-600 mt-1">AI öncesine göre</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Kanal Performans Detay */}
              {detailModalOpen === 'channels' && (
                <div className="space-y-6">
                  {/* Kanal Karşılaştırma Tablosu */}
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-100 dark:bg-slate-700">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Kanal</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Toplam Mesaj</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Dönüşüm</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Ort. Yanıt</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Memnuniyet</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {[
                          { name: 'WhatsApp', count: 1234, conversion: 68, response: '2.3 dk', satisfaction: 4.7, color: 'green' },
                          { name: 'Instagram', count: 823, conversion: 52, response: '5.1 dk', satisfaction: 4.5, color: 'pink' },
                          { name: 'Telefon', count: 412, conversion: 78, response: '45 sn', satisfaction: 4.8, color: 'purple' },
                          { name: 'Web Widget', count: 220, conversion: 43, response: '8 sn', satisfaction: 4.4, color: 'orange' },
                          { name: 'Facebook', count: 55, conversion: 35, response: '8.2 dk', satisfaction: 4.2, color: 'blue' }
                        ].map((channel, idx) => (
                          <tr key={idx} className="hover:bg-gray-50">
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className={`w-3 h-3 rounded-full bg-${channel.color}-500`}></div>
                                <span className="font-medium text-gray-900">{channel.name}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-right font-semibold text-gray-900 dark:text-gray-100">{channel.count.toLocaleString()}</td>
                            <td className="px-4 py-3 text-right">
                              <span className="text-green-600 font-semibold">{channel.conversion}%</span>
                            </td>
                            <td className="px-4 py-3 text-right text-gray-700 dark:text-gray-300">{channel.response}</td>
                            <td className="px-4 py-3 text-right">
                              <span className="text-orange-500 font-semibold">⭐ {channel.satisfaction}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Peak Saatler */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">⏰ Kanal Bazlı Peak Saatler</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { channel: 'WhatsApp', peak: '14:00-16:00', volume: 234 },
                        { channel: 'Instagram', peak: '19:00-21:00', volume: 187 },
                        { channel: 'Telefon', peak: '09:00-11:00', volume: 98 },
                        { channel: 'Web Widget', peak: '10:00-12:00', volume: 56 }
                      ].map((item, idx) => (
                        <div key={idx} className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
                          <p className="font-semibold text-gray-900 mb-1">{item.channel}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Peak: <span className="font-semibold text-blue-600">{item.peak}</span></p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Ortalama: <span className="font-semibold">{item.volume} mesaj/gün</span></p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Müşteri Memnuniyeti Detay */}
              {detailModalOpen === 'satisfaction' && (
                <div className="space-y-6">
                  {/* NPS Breakdown */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-xl p-6">
                      <div className="text-center">
                        <p className="text-sm font-semibold text-green-700 mb-2">😊 Promoters</p>
                        <p className="text-5xl font-bold text-green-600 mb-2">78%</p>
                        <p className="text-sm text-green-600">2,142 müşteri</p>
                      </div>
                    </div>
                    <div className="bg-gradient-to-br from-gray-50 to-gray-100 border-2 border-gray-300 rounded-xl p-6">
                      <div className="text-center">
                        <p className="text-sm font-semibold text-gray-700 mb-2">😐 Passives</p>
                        <p className="text-5xl font-bold text-gray-600 mb-2">16%</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">439 müşteri</p>
                      </div>
                    </div>
                    <div className="bg-gradient-to-br from-red-50 to-rose-50 border-2 border-red-300 rounded-xl p-6">
                      <div className="text-center">
                        <p className="text-sm font-semibold text-red-700 mb-2">😞 Detractors</p>
                        <p className="text-5xl font-bold text-red-600 mb-2">6%</p>
                        <p className="text-sm text-red-600">165 müşteri</p>
                      </div>
                    </div>
                  </div>

                  {/* Son Yorumlar */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">💬 Son Müşteri Yorumları</h3>
                    <div className="space-y-4">
                      {[
                        { name: 'Ayşe Y.', rating: 5, comment: 'AI asistan çok hızlı ve yardımcı oldu. Randevumu kolayca aldım. Çok memnunum!', channel: 'WhatsApp' },
                        { name: 'Mehmet K.', rating: 5, comment: 'Gece geç saatte mesaj attım, anında cevap aldım. Harika bir hizmet.', channel: 'Instagram' },
                        { name: 'Zeynep D.', rating: 4, comment: 'Genel olarak iyiydi ama bazı sorularımı yanıtlayamadı, insan desteğe yönlendirdi.', channel: 'Web' },
                        { name: 'Ali S.', rating: 5, comment: 'Telefonda konuştum, çok profesyonel. Randevumu hemen ayarladılar.', channel: 'Telefon' }
                      ].map((review, idx) => (
                        <div key={idx} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="font-semibold text-gray-900 dark:text-gray-100">{review.name}</p>
                              <div className="flex items-center gap-1 mt-1">
                                {[...Array(5)].map((_, i) => (
                                  <span key={i} className={`text-sm ${i < review.rating ? 'text-orange-400' : 'text-gray-300'}`}>★</span>
                                ))}
                              </div>
                            </div>
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">{review.channel}</span>
                          </div>
                          <p className="text-sm text-gray-700 italic">"{review.comment}"</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Ekip Performansı Detay */}
              {detailModalOpen === 'team' && (
                <div className="space-y-6">
                  {/* Ekip Üyeleri Detaylı Tablo */}
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-100 dark:bg-slate-700">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">Ekip Üyesi</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Çözüm Sayısı</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Ort. Süre</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Memnuniyet</th>
                          <th className="px-4 py-3 text-right text-sm font-semibold text-gray-700 dark:text-gray-300">Başarı %</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {[
                          { name: 'Dr. Ayşe Yılmaz', count: 234, time: '4.2 dk', rating: 4.9, success: 96 },
                          { name: 'Resepsiyonist Elif', count: 198, time: '3.8 dk', rating: 4.7, success: 94 },
                          { name: 'Müşteri Temsilcisi', count: 145, time: '5.1 dk', rating: 4.5, success: 91 },
                          { name: 'AI Asistan', count: 1234, time: '12 sn', rating: 4.6, success: 87 }
                        ].map((member, idx) => (
                          <tr key={idx} className="hover:bg-gray-50">
                            <td className="px-4 py-3 font-medium text-gray-900">{member.name}</td>
                            <td className="px-4 py-3 text-right font-semibold text-gray-900 dark:text-gray-100">{member.count}</td>
                            <td className="px-4 py-3 text-right text-gray-700 dark:text-gray-300">{member.time}</td>
                            <td className="px-4 py-3 text-right text-orange-500 font-semibold">⭐ {member.rating}</td>
                            <td className="px-4 py-3 text-right">
                              <span className={`font-semibold ${member.success >= 95 ? 'text-green-600' : member.success >= 90 ? 'text-blue-600' : 'text-gray-600'}`}>
                                {member.success}%
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Performans Karşılaştırması */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">📊 AI vs İnsan Performans Karşılaştırması</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h4 className="font-semibold text-purple-900">🤖 AI Asistan</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Hız</span>
                            <span className="text-sm font-semibold text-green-600">Çok Hızlı (12 sn)</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Kapasite</span>
                            <span className="text-sm font-semibold text-green-600">Sınırsız</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Maliyet</span>
                            <span className="text-sm font-semibold text-green-600">Çok Düşük</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Kompleks Durumlar</span>
                            <span className="text-sm font-semibold text-amber-600">Orta</span>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <h4 className="font-semibold text-green-900">👤 İnsan Ekip</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Hız</span>
                            <span className="text-sm font-semibold text-amber-600">Orta (4.2 dk)</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Kapasite</span>
                            <span className="text-sm font-semibold text-amber-600">Sınırlı</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Maliyet</span>
                            <span className="text-sm font-semibold text-red-600">Yüksek</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Kompleks Durumlar</span>
                            <span className="text-sm font-semibold text-green-600">Mükemmel</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Dönüşüm Detay */}
              {detailModalOpen === 'conversion' && (
                <div className="space-y-6">
                  {/* Kanal Bazlı Dönüşüm */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">📊 Kanal Bazlı Dönüşüm Oranları</h3>
                    <div className="space-y-4">
                      {[
                        { channel: 'Telefon', conversion: 78, color: 'purple', total: 412, converted: 321 },
                        { channel: 'WhatsApp', conversion: 68, color: 'green', total: 1234, converted: 839 },
                        { channel: 'Instagram', conversion: 52, color: 'pink', total: 823, converted: 428 },
                        { channel: 'Web Widget', conversion: 43, color: 'orange', total: 220, converted: 95 },
                        { channel: 'Facebook', conversion: 35, color: 'blue', total: 55, converted: 19 }
                      ].map((item, idx) => (
                        <div key={idx}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-gray-900">{item.channel}</span>
                            <div className="text-right">
                              <span className="text-lg font-bold text-gray-900 dark:text-gray-100">{item.conversion}%</span>
                              <span className="text-sm text-gray-500 dark:text-gray-400 ml-2">({item.converted}/{item.total})</span>
                            </div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-3">
                            <div className={`bg-${item.color}-500 h-3 rounded-full`} style={{ width: `${item.conversion}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* İptal & No-Show Analizi */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                      <h4 className="font-bold text-red-900 mb-4">❌ İptal Edilen Randevular</h4>
                      <p className="text-4xl font-bold text-red-600 mb-2">225</p>
                      <p className="text-sm text-red-700">Toplam randevuların %14.8'i</p>
                      <div className="mt-4 space-y-2">
                        <p className="text-xs text-gray-600 dark:text-gray-400">En çok iptal nedenleri:</p>
                        <p className="text-xs">• Zaman uyumsuzluğu (45%)</p>
                        <p className="text-xs">• Fiyat endişesi (28%)</p>
                        <p className="text-xs">• Diğer (27%)</p>
                      </div>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
                      <h4 className="font-bold text-amber-900 mb-4">⏰ No-Show (Gelmedi)</h4>
                      <p className="text-4xl font-bold text-amber-600 mb-2">187</p>
                      <p className="text-sm text-amber-700">Toplam randevuların %12.3'ü</p>
                      <div className="mt-4">
                        <p className="text-xs text-gray-600 mb-2">Hatırlatma etkisi:</p>
                        <p className="text-xs text-green-600 font-semibold">SMS hatırlatması ile %40 azalma</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Zaman Analizi Detay */}
              {detailModalOpen === 'time' && (
                <div className="space-y-6">
                  {/* Günlük Yoğunluk */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">📅 Günlük Yoğunluk Dağılımı</h3>
                    <div className="space-y-3">
                      {[
                        { day: 'Pazartesi', count: 534, percentage: 22 },
                        { day: 'Salı', count: 487, percentage: 20 },
                        { day: 'Çarşamba', count: 445, percentage: 18 },
                        { day: 'Perşembe', count: 423, percentage: 17 },
                        { day: 'Cuma', count: 512, percentage: 21 },
                        { day: 'Cumartesi', count: 234, percentage: 10 },
                        { day: 'Pazar', count: 109, percentage: 4 }
                      ].map((item, idx) => (
                        <div key={idx}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-gray-900">{item.day}</span>
                            <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">{item.count} konuşma</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: `${item.percentage * 4.5}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Saatlik Isı Haritası */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">🔥 Saatlik Yoğunluk Isı Haritası</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Koyu renkler daha yoğun saatleri gösterir</p>
                    <div className="grid grid-cols-6 gap-2">
                      {[
                        { time: '09:00-11:00', intensity: 95 },
                        { time: '11:00-13:00', intensity: 78 },
                        { time: '13:00-15:00', intensity: 65 },
                        { time: '15:00-17:00', intensity: 82 },
                        { time: '17:00-19:00', intensity: 71 },
                        { time: '19:00-21:00', intensity: 58 }
                      ].map((slot, idx) => (
                        <div
                          key={idx}
                          className={`p-4 rounded-lg text-center ${
                            slot.intensity > 80 ? 'bg-red-500 text-white' :
                            slot.intensity > 65 ? 'bg-orange-400 text-white' :
                            'bg-yellow-300 text-gray-900'
                          }`}
                        >
                          <p className="text-xs font-semibold mb-1">{slot.time}</p>
                          <p className="text-lg font-bold">{slot.intensity}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Finansal Tahminler Detay */}
              {detailModalOpen === 'financial' && (
                <div className="space-y-6">
                  {/* Gelir Özeti */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gradient-to-br from-emerald-50 to-green-50 border border-emerald-200 rounded-xl p-6">
                      <p className="text-sm text-emerald-700 font-medium mb-2">Bu Ay Gelir</p>
                      <p className="text-4xl font-bold text-emerald-600 mb-1">₺187,400</p>
                      <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">↗ +23%</span>
                    </div>
                    <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-6">
                      <p className="text-sm text-blue-700 font-medium mb-2">Geçen Ay</p>
                      <p className="text-4xl font-bold text-blue-600 mb-1">₺152,300</p>
                      <span className="text-xs text-gray-500">Referans dönem</span>
                    </div>
                    <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-6">
                      <p className="text-sm text-purple-700 font-medium mb-2">Yıllık Toplam</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">₺1.8M</p>
                      <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">↗ +34%</span>
                    </div>
                  </div>

                  {/* AI ROI Analizi */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">🤖 AI Yatırım Getirisi (ROI)</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-gray-700 mb-3">Maliyetler</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">AI Sistem Aboneliği</span>
                            <span className="font-semibold text-red-600">₺12,000/ay</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">Eğitim & Entegrasyon</span>
                            <span className="font-semibold text-red-600">₺8,500 (tek seferlik)</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">API Kullanımı</span>
                            <span className="font-semibold text-red-600">₺3,200/ay</span>
                          </div>
                          <div className="border-t pt-2 mt-2 flex justify-between">
                            <span className="font-semibold text-gray-900 dark:text-gray-100">Toplam Maliyet</span>
                            <span className="font-bold text-red-600">₺15,200/ay</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-700 mb-3">Tasarruflar</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">İnsan Kaynağı</span>
                            <span className="font-semibold text-green-600">₺45,000/ay</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">Operasyonel Verimlilik</span>
                            <span className="font-semibold text-green-600">₺18,500/ay</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">Ek Gelir (Dönüşüm Artışı)</span>
                            <span className="font-semibold text-green-600">₺22,000/ay</span>
                          </div>
                          <div className="border-t pt-2 mt-2 flex justify-between">
                            <span className="font-semibold text-gray-900 dark:text-gray-100">Net Tasarruf</span>
                            <span className="font-bold text-green-600">₺70,300/ay</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300 rounded-xl p-4 text-center">
                      <p className="text-sm text-gray-700 mb-1">Net ROI (Return on Investment)</p>
                      <p className="text-5xl font-bold text-green-600">+425%</p>
                      <p className="text-xs text-gray-600 mt-2">Her ₺1 yatırım için ₺4.25 geri dönüş</p>
                    </div>
                  </div>

                  {/* Gelir Tahminleri */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">📈 3 Aylık Gelir Tahmini</h3>
                    <div className="space-y-3">
                      {[
                        { month: 'Gelecek Ay', estimated: 215000, growth: 15 },
                        { month: '2 Ay Sonra', estimated: 247000, growth: 15 },
                        { month: '3 Ay Sonra', estimated: 284000, growth: 15 }
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4">
                          <div>
                            <p className="font-semibold text-gray-900 dark:text-gray-100">{item.month}</p>
                            <p className="text-xs text-gray-500">Tahmini gelir</p>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-blue-600">₺{(item.estimated / 1000).toFixed(0)}K</p>
                            <span className="text-xs font-semibold text-green-600">↗ +{item.growth}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Trend Analizi Detay */}
              {detailModalOpen === 'trends' && (
                <div className="space-y-6">
                  {/* Büyüme Trendi */}
                  <div className="bg-gradient-to-br from-cyan-50 to-blue-50 border border-cyan-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">📊 Büyüme Trendi (Son 6 Ay)</h3>
                    <div className="space-y-3">
                      {[
                        { month: 'Ekim', conversations: 1823, growth: 0 },
                        { month: 'Kasım', conversations: 2045, growth: 12 },
                        { month: 'Aralık', conversations: 2312, growth: 13 },
                        { month: 'Ocak', conversations: 2487, growth: 8 },
                        { month: 'Şubat', conversations: 2698, growth: 8 },
                        { month: 'Mart', conversations: 2744, growth: 2 }
                      ].map((item, idx) => (
                        <div key={idx}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-gray-900">{item.month}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">{item.conversations} konuşma</span>
                              {item.growth > 0 && (
                                <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">
                                  +{item.growth}%
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-cyan-500 h-2 rounded-full transition-all" style={{ width: `${(item.conversations / 2744) * 100}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Tahminler */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">🔮 Gelecek Tahminleri</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-lg p-4">
                        <p className="text-sm text-gray-600 mb-2">Gelecek Ay</p>
                        <p className="text-3xl font-bold text-green-600 mb-1">3,240</p>
                        <p className="text-xs text-green-700">+18% artış bekleniyor</p>
                      </div>
                      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-lg p-4">
                        <p className="text-sm text-gray-600 mb-2">3 Ay Sonra</p>
                        <p className="text-3xl font-bold text-blue-600 mb-1">4,120</p>
                        <p className="text-xs text-blue-700">+50% artış (kümülatif)</p>
                      </div>
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-4">
                        <p className="text-sm text-gray-600 mb-2">Yıl Sonu</p>
                        <p className="text-3xl font-bold text-purple-600 mb-1">6,500</p>
                        <p className="text-xs text-purple-700">+137% artış (yıllık)</p>
                      </div>
                    </div>
                  </div>

                  {/* Popüler Konular Trendi */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">🔥 Yükselen Konular</h3>
                    <div className="space-y-3">
                      {[
                        { topic: 'İmplant tedavisi', trend: '+45%', count: 234 },
                        { topic: 'Ortodonti randevuları', trend: '+32%', count: 187 },
                        { topic: 'Diş beyazlatma', trend: '+28%', count: 156 },
                        { topic: 'Kanal tedavisi fiyatları', trend: '+18%', count: 98 }
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-gradient-to-r from-orange-50 to-red-50 rounded-lg p-3">
                          <div className="flex items-center gap-3">
                            <div className="bg-orange-500 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm">
                              {idx + 1}
                            </div>
                            <p className="font-medium text-gray-900">{item.topic}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-semibold text-orange-600">{item.trend}</p>
                            <p className="text-xs text-gray-500">{item.count} soru</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* SLA & Acil Durumlar Detay */}
              {detailModalOpen === 'sla' && (
                <div className="space-y-6">
                  {/* SLA Özeti */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4">
                      <p className="text-sm text-green-700 font-medium mb-2">SLA Uyumu</p>
                      <p className="text-4xl font-bold text-green-600">94%</p>
                      <p className="text-xs text-green-600 mt-1">2,580 / 2,744 konuşma</p>
                    </div>
                    <div className="bg-gradient-to-br from-yellow-50 to-amber-50 border border-yellow-200 rounded-xl p-4">
                      <p className="text-sm text-yellow-700 font-medium mb-2">Hedef: &lt;2 dk</p>
                      <p className="text-4xl font-bold text-yellow-600">1.8dk</p>
                      <p className="text-xs text-green-600 mt-1">✓ Hedefin altında</p>
                    </div>
                    <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-xl p-4">
                      <p className="text-sm text-blue-700 font-medium mb-2">Ort. Yanıt</p>
                      <p className="text-4xl font-bold text-blue-600">32sn</p>
                      <p className="text-xs text-blue-600 mt-1">İlk yanıt süresi</p>
                    </div>
                    <div className="bg-gradient-to-br from-red-50 to-rose-50 border border-red-200 rounded-xl p-4">
                      <p className="text-sm text-red-700 font-medium mb-2">SLA İhlali</p>
                      <p className="text-4xl font-bold text-red-600">164</p>
                      <p className="text-xs text-red-600 mt-1">%6 toplam</p>
                    </div>
                  </div>

                  {/* Acil Durumlar */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">🚨 Son Acil Durumlar</h3>
                    <div className="space-y-3">
                      {[
                        { time: '2 saat önce', issue: 'Şiddetli diş ağrısı - Acil randevu talebi', status: 'Çözüldü', severity: 'high' },
                        { time: '5 saat önce', issue: 'İmplant sonrası kanama şikayeti', status: 'Çözüldü', severity: 'high' },
                        { time: '1 gün önce', issue: 'Tedavi memnuniyetsizliği ve iade talebi', status: 'Devam Ediyor', severity: 'medium' },
                        { time: '2 gün önce', issue: 'Randevu saatinde doktor bulunmadı', status: 'Çözüldü', severity: 'high' }
                      ].map((item, idx) => (
                        <div key={idx} className={`flex items-start justify-between p-4 rounded-lg border-l-4 ${
                          item.severity === 'high' ? 'bg-red-50 border-red-500' : 'bg-yellow-50 border-yellow-500'
                        }`}>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <AlertCircle className={`w-4 h-4 ${item.severity === 'high' ? 'text-red-600' : 'text-yellow-600'}`} />
                              <p className="font-semibold text-gray-900 dark:text-gray-100">{item.issue}</p>
                            </div>
                            <p className="text-xs text-gray-500">{item.time}</p>
                          </div>
                          <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                            item.status === 'Çözüldü' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {item.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* SLA İhlal Nedenleri */}
                  <div className="bg-white dark:bg-slate-800 border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">⚠️ SLA İhlal Nedenleri</h3>
                    <div className="space-y-3">
                      {[
                        { reason: 'Ekip müsait değil / yoğunluk', percentage: 42, count: 69 },
                        { reason: 'Kompleks soru - uzun araştırma', percentage: 31, count: 51 },
                        { reason: 'Teknik sorun / sistem arızası', percentage: 18, count: 30 },
                        { reason: 'AI devir süreci gecikmesi', percentage: 9, count: 14 }
                      ].map((item, idx) => (
                        <div key={idx}>
                          <div className="flex items-center justify-between mb-1">
                            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{item.reason}</p>
                            <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{item.count} kez ({item.percentage}%)</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-red-500 h-2 rounded-full" style={{ width: `${item.percentage * 2}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-gray-50 dark:bg-slate-900 border-t border-gray-200 dark:border-slate-600 px-6 py-4 flex items-center justify-end gap-3">
              <button
                onClick={() => setDetailModalOpen(null)}
                className="px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-slate-800 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
              >
                Kapat
              </button>
              <button 
                onClick={handleExportPDF}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                PDF İndir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportsPage;

