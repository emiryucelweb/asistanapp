/**
 * 404 Not Found Page
 * Displayed when user navigates to non-existent route
 */
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileQuestion, Home, ArrowLeft, Search } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(-1);
  };

  const handleGoHome = () => {
    navigate('/dashboard');
  };

  const handleSearch = () => {
    navigate('/help');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Animated 404 Illustration */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 bg-blue-500 rounded-full opacity-20 animate-ping"></div>
              <div className="relative p-8 bg-white rounded-full shadow-xl">
                <FileQuestion className="w-24 h-24 text-blue-600" />
              </div>
            </div>
          </div>

          {/* 404 Text */}
          <h1 className="text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-4">
            404
          </h1>

          {/* Error Message */}
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Sayfa Bulunamadı
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-md mx-auto">
            Aradığınız sayfa taşınmış, silinmiş veya hiç var olmamış olabilir.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <button
            onClick={handleGoBack}
            className="px-6 py-4 bg-white border-2 border-gray-200 rounded-xl hover:border-blue-500 hover:shadow-lg transition-all group"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600 group-hover:text-blue-600 mx-auto mb-2 transition-colors" />
            <span className="block text-gray-900 font-semibold">Geri Dön</span>
            <span className="block text-sm text-gray-500">Önceki sayfa</span>
          </button>

          <button
            onClick={handleGoHome}
            className="px-6 py-4 bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-xl hover:shadow-xl hover:scale-105 transition-all"
          >
            <Home className="w-6 h-6 mx-auto mb-2" />
            <span className="block font-semibold">Ana Sayfa</span>
            <span className="block text-sm text-blue-100">Dashboard'a git</span>
          </button>

          <button
            onClick={handleSearch}
            className="px-6 py-4 bg-white border-2 border-gray-200 rounded-xl hover:border-purple-500 hover:shadow-lg transition-all group"
          >
            <Search className="w-6 h-6 text-gray-600 group-hover:text-purple-600 mx-auto mb-2 transition-colors" />
            <span className="block text-gray-900 font-semibold">Yardım</span>
            <span className="block text-sm text-gray-500">Destek al</span>
          </button>
        </div>

        {/* Popular Pages */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">Popüler Sayfalar:</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <button
              onClick={() => navigate('/dashboard')}
              className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors text-left"
            >
              Dashboard
            </button>
            <button
              onClick={() => navigate('/conversations')}
              className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors text-left"
            >
              Konuşmalar
            </button>
            <button
              onClick={() => navigate('/reports')}
              className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors text-left"
            >
              Raporlar
            </button>
            <button
              onClick={() => navigate('/settings')}
              className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors text-left"
            >
              Ayarlar
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            Sorun devam ederse{' '}
            <a href="/help" className="text-blue-600 hover:underline">
              destek ekibimizle
            </a>{' '}
            iletişime geçin.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;

