/**
 * Agent Conversations - Çalışan Konuşmalar Sayfası
 * Tüm konuşmaları görüntüleme, devralma ve yanıtlama
 */
import React, { useState } from 'react';
import {
  Search,
  Filter,
  MessageCircle,
  Clock,
  User,
  Send,
  Paperclip,
  Image as ImageIcon,
  Smile,
  AlertCircle,
  CheckCircle,
  Lock,
  Unlock,
  Zap,
  FileText,
  Tag,
} from 'lucide-react';
import QuickReplies from '../../../components/agent/conversations/QuickReplies';
import TagsPanel from '../../../components/agent/conversations/TagsPanel';
import AdvancedFilters, { FilterValues } from '../../../components/agent/conversations/AdvancedFilters';
import AssignmentModal from '../../../components/agent/conversations/AssignmentModal';

interface Message {
  id: string;
  sender: 'customer' | 'agent' | 'ai';
  text: string;
  timestamp: Date;
  agentName?: string;
}

interface Conversation {
  id: string;
  customerName: string;
  channel: 'whatsapp' | 'instagram' | 'web' | 'facebook';
  status: 'waiting' | 'assigned' | 'resolved';
  priority: 'high' | 'medium' | 'low';
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  assignedTo?: string;
  assignedToMe: boolean;
  isLocked: boolean;
  lockedBy?: string;
  messages: Message[];
  aiStuck: boolean;
}

const AgentConversations: React.FC = () => {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'waiting' | 'assigned' | 'my' | 'resolved'>('all');
  const [messageInput, setMessageInput] = useState('');
  const [showQuickReplies, setShowQuickReplies] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [notes, setNotes] = useState('');
  const [showTags, setShowTags] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState<FilterValues | null>(null);
  const [showAssignment, setShowAssignment] = useState(false);
  const [assignmentConversationId, setAssignmentConversationId] = useState<string | null>(null);

  // Mock current agent
  const currentAgent = 'Ayşe Yılmaz';

  // Mock conversations data
  const conversations: Conversation[] = [
    {
      id: '1',
      customerName: 'Ahmet Bey',
      channel: 'whatsapp',
      status: 'waiting',
      priority: 'high',
      lastMessage: 'Siparişim nerede? Acil durum!',
      lastMessageTime: '2 dk önce',
      unreadCount: 3,
      assignedToMe: false,
      isLocked: false,
      aiStuck: true,
      messages: [
        { id: 'm1', sender: 'customer', text: 'Merhaba', timestamp: new Date(Date.now() - 600000) },
        { id: 'm2', sender: 'ai', text: 'Merhaba! Size nasıl yardımcı olabilirim?', timestamp: new Date(Date.now() - 580000) },
        { id: 'm3', sender: 'customer', text: 'Siparişim nerede? Acil durum!', timestamp: new Date(Date.now() - 120000) },
      ],
    },
    {
      id: '2',
      customerName: 'Zeynep Hanım',
      channel: 'instagram',
      status: 'assigned',
      priority: 'medium',
      lastMessage: 'Ürün iadesi yapmak istiyorum',
      lastMessageTime: '5 dk önce',
      unreadCount: 1,
      assignedTo: currentAgent,
      assignedToMe: true,
      isLocked: true,
      lockedBy: currentAgent,
      aiStuck: false,
      messages: [
        { id: 'm1', sender: 'customer', text: 'Ürün iadesi yapmak istiyorum', timestamp: new Date(Date.now() - 300000) },
        { id: 'm2', sender: 'agent', text: 'Tabii, size yardımcı olabilirim. Hangi ürünü iade etmek istiyorsunuz?', timestamp: new Date(Date.now() - 280000), agentName: currentAgent },
      ],
    },
    {
      id: '3',
      customerName: 'Mehmet Bey',
      channel: 'web',
      status: 'assigned',
      priority: 'low',
      lastMessage: 'Teşekkürler, çok yardımcı oldunuz',
      lastMessageTime: '10 dk önce',
      unreadCount: 0,
      assignedTo: 'Can Demir',
      assignedToMe: false,
      isLocked: true,
      lockedBy: 'Can Demir',
      aiStuck: false,
      messages: [
        { id: 'm1', sender: 'customer', text: 'Merhaba, fiyat bilgisi alabilir miyim?', timestamp: new Date(Date.now() - 600000) },
        { id: 'm2', sender: 'agent', text: 'Merhaba! Elbette, hangi ürün için?', timestamp: new Date(Date.now() - 580000), agentName: 'Can Demir' },
        { id: 'm3', sender: 'customer', text: 'Teşekkürler, çok yardımcı oldunuz', timestamp: new Date(Date.now() - 600000) },
      ],
    },
    {
      id: '4',
      customerName: 'Fatma Hanım',
      channel: 'facebook',
      status: 'resolved',
      priority: 'low',
      lastMessage: 'Sorunum çözüldü, teşekkürler',
      lastMessageTime: '1 saat önce',
      unreadCount: 0,
      assignedTo: currentAgent,
      assignedToMe: true,
      isLocked: false,
      aiStuck: false,
      messages: [
        { id: 'm1', sender: 'customer', text: 'Hesabıma giriş yapamıyorum', timestamp: new Date(Date.now() - 3600000) },
        { id: 'm2', sender: 'agent', text: 'Şifrenizi sıfırlamanız gerekiyor. Size link gönderdim.', timestamp: new Date(Date.now() - 3580000), agentName: currentAgent },
        { id: 'm3', sender: 'customer', text: 'Sorunum çözüldü, teşekkürler', timestamp: new Date(Date.now() - 3600000) },
      ],
    },
  ];

  // Filter conversations
  const filteredConversations = conversations.filter((conv) => {
    const matchesSearch = conv.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         conv.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = 
      filterStatus === 'all' ? true :
      filterStatus === 'waiting' ? conv.status === 'waiting' :
      filterStatus === 'assigned' ? conv.status === 'assigned' :
      filterStatus === 'my' ? conv.assignedToMe :
      filterStatus === 'resolved' ? conv.status === 'resolved' :
      true;

    return matchesSearch && matchesFilter;
  });

  const channelIcons: Record<string, string> = {
    whatsapp: '💬',
    instagram: '📷',
    web: '🌐',
    facebook: '👥',
  };

  const channelColors: Record<string, string> = {
    whatsapp: 'bg-green-100 dark:bg-green-900/30',
    instagram: 'bg-pink-100 dark:bg-pink-900/30',
    web: 'bg-blue-100 dark:bg-blue-900/30',
    facebook: 'bg-indigo-100 dark:bg-indigo-900/30',
  };

  const priorityColors: Record<string, string> = {
    high: 'text-red-600 dark:text-red-400',
    medium: 'text-yellow-600 dark:text-yellow-400',
    low: 'text-green-600 dark:text-green-400',
  };

  const handleTakeOver = (conversation: Conversation) => {
    // TODO: Implement real takeover logic
    console.log('Taking over conversation:', conversation.id);
    alert(`Konuşmayı devraldınız: ${conversation.customerName}`);
    
    // Update conversation state
    const updatedConv = {
      ...conversation,
      isLocked: true,
      lockedBy: currentAgent,
      assignedTo: currentAgent,
      assignedToMe: true,
      status: 'assigned' as const,
    };
    setSelectedConversation(updatedConv);
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedConversation) return;

    // TODO: Implement real message sending
    console.log('Sending message:', messageInput);
    
    const newMessage: Message = {
      id: `m${Date.now()}`,
      sender: 'agent',
      text: messageInput,
      timestamp: new Date(),
      agentName: currentAgent,
    };

    setSelectedConversation({
      ...selectedConversation,
      messages: [...selectedConversation.messages, newMessage],
    });

    setMessageInput('');
  };

  const handleResolve = () => {
    if (!selectedConversation) return;
    
    // TODO: Implement real resolve logic
    console.log('Resolving conversation:', selectedConversation.id);
    alert('Konuşma kapatıldı!');
    
    setSelectedConversation({
      ...selectedConversation,
      status: 'resolved',
      isLocked: false,
    });
  };

  const canSendMessage = selectedConversation && 
    (selectedConversation.assignedToMe || !selectedConversation.isLocked);

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">
              Konuşmalar
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {filteredConversations.length} konuşma
            </p>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setShowAdvancedFilters(true)}
              className="px-3 py-1.5 text-sm font-medium rounded-lg transition-colors bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 hover:bg-purple-200 dark:hover:bg-purple-900/50 flex items-center gap-2"
            >
              <Filter className="w-4 h-4" />
              <span className="hidden sm:inline">Filtreler</span>
              {appliedFilters && (
                <span className="bg-purple-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                  {(appliedFilters.channels.length || 0) + 
                   (appliedFilters.tags.length || 0) + 
                   (appliedFilters.assignedTo.length || 0) + 
                   (appliedFilters.priority.length || 0) +
                   (appliedFilters.dateRange ? 1 : 0)}
                </span>
              )}
            </button>
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                filterStatus === 'all'
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600'
              }`}
            >
              Tümü
            </button>
            <button
              onClick={() => setFilterStatus('waiting')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                filterStatus === 'waiting'
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600'
              }`}
            >
              Bekleyenler ({conversations.filter(c => c.status === 'waiting').length})
            </button>
            <button
              onClick={() => setFilterStatus('my')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                filterStatus === 'my'
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600'
              }`}
            >
              Bana Atananlar ({conversations.filter(c => c.assignedToMe).length})
            </button>
            <button
              onClick={() => setFilterStatus('resolved')}
              className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                filterStatus === 'resolved'
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-slate-600'
              }`}
            >
              Çözülenler
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="mt-4 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Konuşmalarda ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-gray-900 dark:text-gray-100"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Conversations List */}
        <div className="w-full lg:w-96 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="p-8 text-center">
              <MessageCircle className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
              <p className="text-gray-500 dark:text-gray-400">Konuşma bulunamadı</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200 dark:divide-slate-700">
              {filteredConversations.map((conversation) => (
                <button
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation)}
                  className={`w-full p-4 text-left hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors ${
                    selectedConversation?.id === conversation.id
                      ? 'bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-500'
                      : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-12 h-12 rounded-full ${channelColors[conversation.channel]} flex items-center justify-center text-2xl flex-shrink-0`}>
                      {channelIcons[conversation.channel]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate">
                          {conversation.customerName}
                        </h3>
                        <span className="text-xs text-gray-500 dark:text-gray-400 flex-shrink-0 ml-2">
                          {conversation.lastMessageTime}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 truncate mb-2">
                        {conversation.lastMessage}
                      </p>
                      <div className="flex items-center gap-2 flex-wrap">
                        {conversation.aiStuck && (
                          <span className="text-xs px-2 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded-full flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" />
                            AI Tıkandı
                          </span>
                        )}
                        {conversation.isLocked && (
                          <span className="text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded-full flex items-center gap-1">
                            <Lock className="w-3 h-3" />
                            {conversation.lockedBy === currentAgent ? 'Sizde' : conversation.lockedBy}
                          </span>
                        )}
                        {conversation.unreadCount > 0 && (
                          <span className="text-xs px-2 py-0.5 bg-orange-500 text-white rounded-full font-bold">
                            {conversation.unreadCount}
                          </span>
                        )}
                        {!conversation.assignedToMe && conversation.status === 'waiting' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setAssignmentConversationId(conversation.id);
                              setShowAssignment(true);
                            }}
                            className="text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded-full hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors"
                          >
                            Ata
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Conversation Detail */}
        <div className="flex-1 flex flex-col bg-white dark:bg-slate-800">
          {selectedConversation ? (
            <>
              {/* Conversation Header */}
              <div className="p-4 border-b border-gray-200 dark:border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full ${channelColors[selectedConversation.channel]} flex items-center justify-center text-xl`}>
                    {channelIcons[selectedConversation.channel]}
                  </div>
                  <div>
                    <h2 className="font-bold text-gray-900 dark:text-gray-100">
                      {selectedConversation.customerName}
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                      {selectedConversation.channel}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowTags(true)}
                    className="px-3 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 dark:text-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors flex items-center gap-2"
                    title="Etiketler"
                  >
                    <Tag className="w-4 h-4" />
                    <span className="hidden sm:inline">Etiket</span>
                  </button>
                  {!selectedConversation.assignedToMe && !selectedConversation.isLocked && (
                    <button
                      onClick={() => handleTakeOver(selectedConversation)}
                      className="px-4 py-2 bg-orange-500 text-white text-sm font-medium rounded-lg hover:bg-orange-600 transition-colors flex items-center gap-2"
                    >
                      <Unlock className="w-4 h-4" />
                      Devral
                    </button>
                  )}
                  {selectedConversation.assignedToMe && selectedConversation.status !== 'resolved' && (
                    <button
                      onClick={handleResolve}
                      className="px-4 py-2 bg-green-500 text-white text-sm font-medium rounded-lg hover:bg-green-600 transition-colors flex items-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Çözüldü
                    </button>
                  )}
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {selectedConversation.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'customer' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-[70%] ${message.sender === 'customer' ? 'order-1' : 'order-2'}`}>
                      {message.sender !== 'customer' && message.agentName && (
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1 text-right">
                          {message.agentName}
                        </p>
                      )}
                      <div
                        className={`rounded-2xl px-4 py-2.5 ${
                          message.sender === 'customer'
                            ? 'bg-gray-100 dark:bg-slate-700 text-gray-900 dark:text-gray-100'
                            : message.sender === 'ai'
                            ? 'bg-purple-500 text-white'
                            : 'bg-orange-500 text-white'
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                      </div>
                      <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                        {message.timestamp.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Message Input */}
              <div className="p-4 border-t border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-900">
                {!canSendMessage ? (
                  <div className="text-center py-4">
                    <Lock className="w-8 h-8 text-gray-400 dark:text-gray-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Bu konuşma {selectedConversation.lockedBy} tarafından devralındı
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                      Mesaj gönderemezsiniz
                    </p>
                  </div>
                ) : (
                  <div className="flex items-end gap-2">
                    <button 
                      onClick={() => setShowQuickReplies(true)}
                      className="p-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors"
                      title="Hızlı Yanıtlar"
                    >
                      <Zap className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={() => setShowNotes(!showNotes)}
                      className="p-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors"
                      title="Notlar"
                    >
                      <FileText className="w-5 h-5" />
                    </button>
                    <button className="p-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors">
                      <Paperclip className="w-5 h-5" />
                    </button>
                    <button className="p-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors">
                      <ImageIcon className="w-5 h-5" />
                    </button>
                    <button className="p-2 text-gray-600 dark:text-gray-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors">
                      <Smile className="w-5 h-5" />
                    </button>
                    <input
                      type="text"
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder="Mesajınızı yazın... (/ ile hızlı yanıt)"
                      className="flex-1 px-4 py-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-gray-900 dark:text-gray-100"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!messageInput.trim()}
                      className="px-6 py-2.5 bg-orange-500 text-white font-medium rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Send className="w-4 h-4" />
                      Gönder
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MessageCircle className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
                  Konuşma Seçin
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Mesajlaşmaya başlamak için bir konuşma seçin
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quick Replies Modal */}
      {showQuickReplies && (
        <QuickReplies
          onSelect={(content) => setMessageInput(content)}
          onClose={() => setShowQuickReplies(false)}
        />
      )}

      {/* Notes Panel */}
      {showNotes && selectedConversation && (
        <div className="fixed right-4 bottom-24 w-80 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-200 dark:border-slate-700 overflow-hidden z-40">
          <div className="p-4 bg-gray-50 dark:bg-slate-900 border-b border-gray-200 dark:border-slate-700 flex items-center justify-between">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Notlar
            </h3>
            <button
              onClick={() => setShowNotes(false)}
              className="text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
            >
              ✕
            </button>
          </div>
          <div className="p-4">
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Bu konuşma hakkında notlar ekleyin..."
              className="w-full h-32 px-3 py-2 bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 text-gray-900 dark:text-gray-100 text-sm resize-none"
            />
            <button
              onClick={() => {
                console.log('Saving notes:', notes);
                alert('Not kaydedildi!');
              }}
              className="mt-2 w-full px-4 py-2 bg-orange-500 text-white text-sm font-medium rounded-lg hover:bg-orange-600 transition-colors"
            >
              Kaydet
            </button>
          </div>
        </div>
      )}

      {/* Tags Panel */}
      {showTags && selectedConversation && (
        <TagsPanel
          conversationId={selectedConversation.id}
          currentTags={[]}
          onClose={() => setShowTags(false)}
        />
      )}

      {/* Advanced Filters */}
      {showAdvancedFilters && (
        <AdvancedFilters
          onClose={() => setShowAdvancedFilters(false)}
          onApply={(filters) => {
            setAppliedFilters(filters);
            console.log('Applied filters:', filters);
          }}
        />
      )}

      {/* Assignment Modal */}
      {showAssignment && assignmentConversationId && (
        <AssignmentModal
          conversationId={assignmentConversationId}
          onClose={() => {
            setShowAssignment(false);
            setAssignmentConversationId(null);
          }}
          onAssign={(agentId, mode) => {
            console.log(`Assigning conversation ${assignmentConversationId} to agent ${agentId} (${mode})`);
            alert(`Konuşma başarıyla atandı! (${mode === 'auto' ? 'Otomatik' : 'Manuel'})`);
          }}
        />
      )}
    </div>
  );
};

export default AgentConversations;

