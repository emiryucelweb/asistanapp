/**
 * Agent Dashboard - Çalışan Ana Sayfa
 */
import React from 'react';
import { MessageCircle, Clock, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';

const AgentDashboard: React.FC = () => {
  // Mock data
  const stats = {
    today: {
      resolved: 12,
      pending: 3,
      avgResponseTime: '8 dk',
      satisfaction: '4.8/5',
    },
    week: {
      resolved: 67,
      avgResponseTime: '12 dk',
    },
  };

  const assignedConversations = [
    {
      id: '1',
      customerName: 'Ahmet Bey',
      channel: 'whatsapp',
      lastMessage: 'Siparişim nerede?',
      time: '2 dk önce',
      unread: 2,
      priority: 'high',
    },
    {
      id: '2',
      customerName: 'Zeynep Hanım',
      channel: 'instagram',
      lastMessage: 'Ürün iadesi yapmak istiyorum',
      time: '5 dk önce',
      unread: 1,
      priority: 'medium',
    },
    {
      id: '3',
      customerName: 'Mehmet Bey',
      channel: 'web',
      lastMessage: 'Teşekkürler',
      time: '10 dk önce',
      unread: 0,
      priority: 'low',
    },
  ];

  const channelIcons: Record<string, string> = {
    whatsapp: '💬',
    instagram: '📷',
    web: '🌐',
    facebook: '👥',
  };

  const priorityColors: Record<string, string> = {
    high: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
    medium: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
    low: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">
          Ana Sayfa
        </h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Bugünkü görevleriniz ve performansınız
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">Bugün</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stats.today.resolved}</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Çözülen Konuşma</p>
          <div className="mt-3 flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
            <TrendingUp className="w-3 h-3" />
            <span>+15% geçen haftaya göre</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-lg bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">Şu an</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stats.today.pending}</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Bekleyen Konuşma</p>
          <Link 
            to="/agent/conversations" 
            className="mt-3 text-xs text-orange-600 dark:text-orange-400 hover:underline"
          >
            Hemen yanıtla →
          </Link>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">Ortalama</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stats.today.avgResponseTime}</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Yanıt Süresi</p>
          <div className="mt-3 text-xs text-gray-500 dark:text-gray-400">
            Hedef: &lt;10 dk
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">Memnuniyet</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{stats.today.satisfaction}</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Müşteri Puanı</p>
          <div className="mt-3 text-xs text-green-600 dark:text-green-400">
            ⭐ Harika!
          </div>
        </div>
      </div>

      {/* Assigned Conversations */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700">
        <div className="p-6 border-b border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">
                Bekleyen Konuşmalar
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                {assignedConversations.filter(c => c.unread > 0).length} yeni mesaj
              </p>
            </div>
            <Link
              to="/agent/conversations"
              className="px-4 py-2 bg-orange-500 text-white text-sm font-medium rounded-lg hover:bg-orange-600 transition-colors"
            >
              Tümünü Gör
            </Link>
          </div>
        </div>

        <div className="divide-y divide-gray-200 dark:divide-slate-700">
          {assignedConversations.map((conversation) => (
            <Link
              key={conversation.id}
              to={`/agent/conversations/${conversation.id}`}
              className="block p-6 hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4 flex-1 min-w-0">
                  <div className="text-3xl flex-shrink-0">
                    {channelIcons[conversation.channel]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                        {conversation.customerName}
                      </h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${priorityColors[conversation.priority]}`}>
                        {conversation.priority === 'high' ? 'Acil' : conversation.priority === 'medium' ? 'Normal' : 'Düşük'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                      {conversation.lastMessage}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                      {conversation.time}
                    </p>
                  </div>
                </div>
                {conversation.unread > 0 && (
                  <div className="flex-shrink-0">
                    <span className="inline-flex items-center justify-center w-6 h-6 bg-orange-500 text-white text-xs font-bold rounded-full">
                      {conversation.unread}
                    </span>
                  </div>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AgentDashboard;

