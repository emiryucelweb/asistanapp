/**
 * Agent AI Chat Page - Çalışan AI Sohbet
 * Çalışanlar müşteri bilgileri ve firma içi durum hakkında AI'ya soru sorabilir
 */
import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, TrendingUp, Users, MessageSquare, Clock } from 'lucide-react';
import { useAuthStore } from '../../../stores/auth-store';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestions?: string[];
}

const AgentAIChatPage: React.FC = () => {
  const { user } = useAuthStore();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: `Merhaba ${user?.name || 'Agent'}! Ben senin AI asistanınım. 

Sana şunlarda yardımcı olabilirim:
• 📊 Müşteri bilgileri ve geçmiş konuşmalar
• 💬 Firma içi konuşma özetleri
• 📈 Günlük istatistikler ve performans
• 👥 Ekip üyeleri ve durumları
• 🎯 Müşteri davranış analizi

Nasıl yardımcı olabilirim?`,
      timestamp: new Date().toISOString(),
      suggestions: [
        'Bugün kaç müşteri ile konuştum?',
        'En çok sorulan sorular neler?',
        'Bekleyen müşteriler var mı?',
        'Ekip üyelerinin durumu nedir?',
      ],
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Simulate AI response - gerçek API'den gelecek
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: generateMockResponse(inputValue),
        timestamp: new Date().toISOString(),
        suggestions: generateSuggestions(inputValue),
      };
      setMessages((prev) => [...prev, aiResponse]);
      setIsLoading(false);
    }, 1500);
  };

  const generateMockResponse = (question: string): string => {
    const q = question.toLowerCase();

    if (q.includes('bugün') || q.includes('kaç müşteri')) {
      return `📊 Bugünkü İstatistikler:

• Toplam konuşma: 12
• Çözülen: 9 ✅
• Devam eden: 3 ⏳
• Ortalama çözüm süresi: 4.5 dakika
• Müşteri memnuniyeti: %92

En çok konuştuğun müşteriler:
1. Ahmet Yılmaz (3 konuşma) - Ürün soruları
2. Zeynep Demir (2 konuşma) - Sipariş takibi`;
    }

    if (q.includes('bekleyen') || q.includes('sırada')) {
      return `⏳ Bekleyen Müşteriler:

Şu anda 2 müşteri sırada bekliyor:

1. **Mehmet Kaya** (+90 532 123 4567)
   • Bekleme süresi: 3 dakika
   • Konu: Ürün iadesi
   • Öncelik: Yüksek 🔴

2. **Fatma Öz** (+90 532 987 6543)
   • Bekleme süresi: 1 dakika
   • Konu: Fiyat bilgisi
   • Öncelik: Normal 🟡

İsterseniz size bir tanesini atayabilirim.`;
    }

    if (q.includes('ekip') || q.includes('çalışan')) {
      return `👥 Ekip Durumu:

**Aktif (3):**
• Ayşe Yıldız - 2 aktif konuşma
• Ali Demir - 1 aktif konuşma  
• Sen - 0 aktif konuşma

**Molada (1):**
• Zeynep Kaya - 15 dakikadır molada

**Çevrimdışı (2):**
• Mehmet Yılmaz
• Fatma Öz

Ekip ortalaması: 1.3 konuşma/kişi`;
    }

    if (q.includes('performans') || q.includes('istatistik')) {
      return `📈 Bu Hafta Performansın:

**Konuşma Sayıları:**
• Pazartesi: 15
• Salı: 18
• Çarşamba: 12
• Perşembe: 16
• Cuma: 14
• Bugün: 12

**Ortalamalar:**
• Günlük: 14.5 konuşma
• Çözüm süresi: 4.5 dk
• Yanıt hızı: 45 saniye
• Memnuniyet: %92 ⭐

Harika iş çıkarıyorsun! Ekip ortalamasının üstündesin 🎉`;
    }

    if (q.includes('müşteri bilgi') || q.includes('kim') || q.includes('bilgi')) {
      return `👤 Müşteri Bilgisi Arama:

Hangi müşteri hakkında bilgi almak istiyorsun? 

Şunları söyleyebilirsin:
• "Ahmet Yılmaz hakkında bilgi"
• "+90 532 123 4567 numaralı müşteri"
• "Son konuştuğum müşteri"
• "VIP müşteriler"`;
    }

    // Default response
    return `Anladım. ${question}

Bu konuda sana yardımcı olmak için daha fazla bilgiye ihtiyacım var. Şunları sorabilirsin:

• Bugünkü konuşmalarım
• Bekleyen müşteriler
• Ekip durumu
• Performans istatistiklerim
• Spesifik bir müşteri hakkında bilgi`;
  };

  const generateSuggestions = (question: string): string[] => {
    const q = question.toLowerCase();

    if (q.includes('bugün')) {
      return ['Bu hafta nasıl gitti?', 'En çok kim konuştu?', 'Bekleyen var mı?'];
    }

    if (q.includes('bekleyen')) {
      return ['Birini bana ata', 'En acil olan hangisi?', 'Kaç dakikadır bekliyor?'];
    }

    if (q.includes('ekip')) {
      return ['Kim en yoğun?', 'Ekip performansı nasıl?', 'Molada kim var?'];
    }

    return [
      'Bugün kaç müşteri ile konuştum?',
      'Bekleyen müşteriler var mı?',
      'Performansım nasıl?',
    ];
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('tr-TR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">AI Asistan</h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Müşteri bilgileri ve firma içi durum hakkında sor
            </p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map((message) => (
            <div key={message.id} className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : ''}`}>
              {message.role === 'assistant' && (
                <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-white" />
                </div>
              )}

              <div className={`flex-1 max-w-2xl ${message.role === 'user' ? 'flex justify-end' : ''}`}>
                <div
                  className={`rounded-2xl p-4 ${
                    message.role === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700'
                  }`}
                >
                  <p className={`whitespace-pre-wrap ${message.role === 'assistant' ? 'text-gray-900 dark:text-white' : ''}`}>
                    {message.content}
                  </p>
                  <p className={`text-xs mt-2 ${message.role === 'user' ? 'text-blue-100' : 'text-gray-500 dark:text-gray-400'}`}>
                    {formatTime(message.timestamp)}
                  </p>

                  {/* Suggestions */}
                  {message.suggestions && message.suggestions.length > 0 && (
                    <div className="mt-4 space-y-2">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şunları da sorabilirsin:
                      </p>
                      {message.suggestions.map((suggestion, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="block w-full text-left px-3 py-2 bg-purple-50 dark:bg-purple-900/20 hover:bg-purple-100 dark:hover:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-lg text-sm transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {message.role === 'user' && (
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                  <User className="w-5 h-5 text-white" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 max-w-2xl">
                <div className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-2xl p-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" />
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-slate-700 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end gap-3">
            <div className="flex-1 bg-gray-50 dark:bg-slate-900 border border-gray-300 dark:border-slate-600 rounded-xl focus-within:border-purple-500 dark:focus-within:border-purple-400 transition-colors">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="AI asistanına sor... (örn: Bugün kaç müşteri ile konuştum?)"
                rows={2}
                className="w-full px-4 py-3 bg-transparent text-gray-900 dark:text-white placeholder-gray-500 resize-none focus:outline-none"
              />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-medium rounded-xl transition-all flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              Gönder
            </button>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
            AI yalnızca müşteri bilgileri ve firma içi durum hakkında bilgi verir
          </p>
        </div>
      </div>
    </div>
  );
};

export default AgentAIChatPage;

