/**
 * Agent Profile - Çalışan Profil Sayfası
 */
import React, { useState } from 'react';
import { User, Mail, Phone, Clock, Calendar, Award, TrendingUp } from 'lucide-react';

const AgentProfile: React.FC = () => {
  const [status, setStatus] = useState<'online' | 'busy' | 'offline'>('online');

  const statusConfig = {
    online: { label: 'Çevrimiçi', color: 'bg-green-500', textColor: 'text-green-700 dark:text-green-400' },
    busy: { label: 'Meşgul', color: 'bg-yellow-500', textColor: 'text-yellow-700 dark:text-yellow-400' },
    offline: { label: 'Çevrimdışı', color: 'bg-gray-500', textColor: 'text-gray-700 dark:text-gray-400' },
  };

  const stats = {
    today: { resolved: 12, avgTime: '8 dk', satisfaction: 4.8 },
    week: { resolved: 67, avgTime: '12 dk', satisfaction: 4.7 },
    month: { resolved: 234, avgTime: '15 dk', satisfaction: 4.6 },
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">
          Profil
        </h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Profil bilgileriniz ve performansınız
        </p>
      </div>

      {/* Profile Card */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold">
            AY
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              Ayşe Yılmaz
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Destek Ekibi
            </p>
            <div className="mt-3 flex items-center gap-2 justify-center sm:justify-start">
              <div className={`w-3 h-3 rounded-full ${statusConfig[status].color}`} />
              <span className={`text-sm font-medium ${statusConfig[status].textColor}`}>
                {statusConfig[status].label}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
            <Mail className="w-5 h-5 text-gray-400" />
            <span>ayse.yilmaz@asistanapp.com</span>
          </div>
          <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
            <Phone className="w-5 h-5 text-gray-400" />
            <span>+90 555 123 4567</span>
          </div>
          <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
            <Calendar className="w-5 h-5 text-gray-400" />
            <span>Başlangıç: 15 Ocak 2024</span>
          </div>
          <div className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
            <Clock className="w-5 h-5 text-gray-400" />
            <span>Çalışma Saati: 09:00 - 18:00</span>
          </div>
        </div>
      </div>

      {/* Performance Stats */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4">
          Performans İstatistikleri
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Today */}
          <div>
            <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-3">
              Bugün
            </h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Çözülen</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.today.resolved}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Ort. Süre</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.today.avgTime}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Memnuniyet</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.today.satisfaction}/5
                </span>
              </div>
            </div>
          </div>

          {/* Week */}
          <div>
            <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-3">
              Bu Hafta
            </h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Çözülen</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.week.resolved}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Ort. Süre</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.week.avgTime}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Memnuniyet</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.week.satisfaction}/5
                </span>
              </div>
            </div>
          </div>

          {/* Month */}
          <div>
            <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-3">
              Bu Ay
            </h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Çözülen</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.month.resolved}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Ort. Süre</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.month.avgTime}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300">Memnuniyet</span>
                <span className="text-lg font-bold text-gray-900 dark:text-gray-100">
                  {stats.month.satisfaction}/5
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
          <Award className="w-5 h-5 text-orange-500" />
          Başarılar
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="p-4 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
            <div className="text-3xl mb-2">🏆</div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100">En Hızlı Yanıt</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Bu hafta ortalama 8 dk
            </p>
          </div>
          <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg border border-green-200 dark:border-green-800">
            <div className="text-3xl mb-2">⭐</div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100">Yüksek Memnuniyet</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              4.8/5 müşteri puanı
            </p>
          </div>
          <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <div className="text-3xl mb-2">📈</div>
            <h4 className="font-semibold text-gray-900 dark:text-gray-100">Sürekli Gelişim</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              +15% performans artışı
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentProfile;

