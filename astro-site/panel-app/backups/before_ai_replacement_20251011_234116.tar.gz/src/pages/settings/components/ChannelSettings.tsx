import React, { useState } from 'react';
import { MessageSquare, Instagram, Facebook, Globe, Phone, CheckCircle, Save } from 'lucide-react';

const ChannelSettings: React.FC = () => {
  const [isSaving, setIsSaving] = useState(false);
  const [channels, setChannels] = useState({
    whatsapp: { enabled: true, phone: '+90 555 123 4567', apiToken: 'wa_token_xxxxx', verified: true },
    instagram: { enabled: true, username: '@asistanapp', connected: true },
    facebook: { enabled: false, pageId: '', connected: false },
    web: { enabled: true, color: '#3B82F6', position: 'bottom-right' },
    phone: { enabled: true, number: '+90 212 555 1234', recordCalls: true }
  });

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    alert('✅ Kanal ayarları başarıyla kaydedildi!');
    console.log('Channels saved:', channels);
  };

  const handleConnect = (channel: string) => {
    alert(`${channel} için OAuth bağlantısı açılıyor...`);
    // Simulated connection
    if (channel === 'instagram') {
      setTimeout(() => {
        setChannels({ ...channels, instagram: { ...channels.instagram, connected: true } });
        alert('✅ Instagram başarıyla bağlandı!');
      }, 1000);
    } else if (channel === 'facebook') {
      setTimeout(() => {
        setChannels({ ...channels, facebook: { ...channels.facebook, connected: true, pageId: 'page_12345' } });
        alert('✅ Facebook başarıyla bağlandı!');
      }, 1000);
    }
  };

  const handleDisconnect = (channel: string) => {
    if (confirm(`${channel} bağlantısını kesmek istediğinizden emin misiniz?`)) {
      if (channel === 'instagram') {
        setChannels({ ...channels, instagram: { ...channels.instagram, connected: false } });
      } else if (channel === 'facebook') {
        setChannels({ ...channels, facebook: { ...channels.facebook, connected: false } });
      }
      alert(`✅ ${channel} bağlantısı kesildi!`);
    }
  };

  const copyEmbedCode = () => {
    const code = `<script src="https://asistanapp.com/widget.js" data-id="your-id"></script>`;
    navigator.clipboard.writeText(code);
    alert('✅ Embed kodu kopyalandı!');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Kanal Entegrasyonları</h2>
        <p className="text-sm text-gray-500 mt-1">İletişim kanallarınızı yönetin ve yapılandırın</p>
      </div>

      {/* WhatsApp */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">WhatsApp Business</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Resmi WhatsApp Business API</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {channels.whatsapp.verified && (
              <span className="flex items-center gap-1 text-sm text-green-600 font-medium">
                <CheckCircle className="w-4 h-4" />
                Doğrulandı
              </span>
            )}
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={channels.whatsapp.enabled}
                onChange={(e) => setChannels({ ...channels, whatsapp: { ...channels.whatsapp, enabled: e.target.checked } })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
            </label>
          </div>
        </div>
        {channels.whatsapp.enabled && (
          <div className="space-y-3 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Telefon Numarası</label>
                <input
                  type="tel"
                  value={channels.whatsapp.phone}
                  onChange={(e) => setChannels({ ...channels, whatsapp: { ...channels.whatsapp, phone: e.target.value } })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">API Token</label>
                <input
                  type="password"
                  value={channels.whatsapp.apiToken}
                  onChange={(e) => setChannels({ ...channels, whatsapp: { ...channels.whatsapp, apiToken: e.target.value } })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Instagram */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center">
              <Instagram className="w-6 h-6 text-pink-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Instagram Business</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Instagram DM entegrasyonu</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={channels.instagram.enabled}
              onChange={(e) => setChannels({ ...channels, instagram: { ...channels.instagram, enabled: e.target.checked } })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-pink-600"></div>
          </label>
        </div>
        {channels.instagram.enabled && (
          <div className="mt-4">
            {channels.instagram.connected ? (
              <div className="flex items-center justify-between p-4 bg-pink-50 rounded-lg border border-pink-200">
                <div>
                  <p className="font-medium text-gray-900 dark:text-gray-100">{channels.instagram.username}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Bağlı hesap</p>
                </div>
                <button 
                  onClick={() => handleDisconnect('Instagram')}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors text-sm"
                >
                  Bağlantıyı Kes
                </button>
              </div>
            ) : (
              <button 
                onClick={() => handleConnect('instagram')}
                className="w-full px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:opacity-90 transition-opacity font-medium"
              >
                Instagram ile Bağlan
              </button>
            )}
          </div>
        )}
      </div>

      {/* Web Widget */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Globe className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Web Widget</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Web siteniz için chat widget'ı</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={channels.web.enabled}
              onChange={(e) => setChannels({ ...channels, web: { ...channels.web, enabled: e.target.checked } })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
        {channels.web.enabled && (
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Widget Rengi</label>
                <input
                  type="color"
                  value={channels.web.color}
                  onChange={(e) => setChannels({ ...channels, web: { ...channels.web, color: e.target.value } })}
                  className="w-full h-10 rounded-lg border border-gray-300 dark:border-slate-600"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Konum</label>
                <select
                  value={channels.web.position}
                  onChange={(e) => setChannels({ ...channels, web: { ...channels.web, position: e.target.value } })}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="bottom-right">Sağ Alt</option>
                  <option value="bottom-left">Sol Alt</option>
                </select>
              </div>
            </div>
            <div className="bg-gray-50 dark:bg-slate-900 p-4 rounded-lg border border-gray-200 dark:border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-gray-700">Embed Code:</p>
                <button 
                  onClick={copyEmbedCode}
                  className="text-xs bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 transition-colors"
                >
                  Kopyala
                </button>
              </div>
              <code className="text-xs bg-gray-900 text-green-400 p-3 rounded block overflow-x-auto">
                {`<script src="https://asistanapp.com/widget.js" data-id="your-id"></script>`}
              </code>
            </div>
          </div>
        )}
      </div>

      {/* Phone */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <Phone className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Telefon</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Sesli görüşme entegrasyonu</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={channels.phone.enabled}
              onChange={(e) => setChannels({ ...channels, phone: { ...channels.phone, enabled: e.target.checked } })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>
        {channels.phone.enabled && (
          <div className="space-y-3 mt-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Santral Numarası</label>
              <input
                type="tel"
                value={channels.phone.number}
                onChange={(e) => setChannels({ ...channels, phone: { ...channels.phone, number: e.target.value } })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-purple-500"
              />
            </div>
            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
              <div>
                <p className="font-medium text-gray-900 dark:text-gray-100">Çağrı Kaydı</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Telefon görüşmeleri kayıt edilsin</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={channels.phone.recordCalls}
                  onChange={(e) => setChannels({ ...channels, phone: { ...channels.phone, recordCalls: e.target.checked } })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        )}
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <button 
          onClick={() => window.location.reload()}
          className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
        >
          İptal
        </button>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Değişiklikleri Kaydet
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default ChannelSettings;
