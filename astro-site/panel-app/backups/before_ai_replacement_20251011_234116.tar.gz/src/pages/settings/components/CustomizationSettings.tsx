import React, { useState } from 'react';
import { Palette, Sun, Moon, Globe, DollarSign, Save } from 'lucide-react';

const CustomizationSettings: React.FC = () => {
  const [customization, setCustomization] = useState({
    theme: 'light',
    accentColor: '#3B82F6',
    language: 'tr',
    currency: 'TRY',
    numberFormat: 'tr',
    defaultPage: '/dashboard'
  });

  const themes = [
    { value: 'light', label: 'Açık Tema', icon: <Sun className="w-5 h-5" /> },
    { value: 'dark', label: 'Koyu Tema', icon: <Moon className="w-5 h-5" /> }
  ];

  const accentColors = [
    { value: '#3B82F6', label: 'Mavi', color: 'bg-blue-500' },
    { value: '#8B5CF6', label: 'Mor', color: 'bg-purple-500' },
    { value: '#10B981', label: 'Yeşil', color: 'bg-green-500' },
    { value: '#F59E0B', label: 'Turuncu', color: 'bg-orange-500' },
    { value: '#EF4444', label: 'Kırmızı', color: 'bg-red-500' }
  ];

  const handleSave = () => {
    alert('✅ Özelleştirme ayarları kaydedildi!');
    console.log('Customization saved:', customization);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Özelleştirme & Tema</h2>
        <p className="text-sm text-gray-500 mt-1">Arayüz görünümünü ve tercihlerinizi ayarlayın</p>
      </div>

      {/* Theme */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Palette className="w-5 h-5 inline mr-2" />
          Görünüm Teması
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {themes.map((theme) => (
            <button
              key={theme.value}
              onClick={() => setCustomization({ ...customization, theme: theme.value })}
              className={`p-4 rounded-lg border-2 transition-all ${
                customization.theme === theme.value
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 dark:border-blue-600'
                  : 'border-gray-200 dark:border-slate-700 hover:border-gray-300 dark:hover:border-slate-600'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${customization.theme === theme.value ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'}`}>
                  {theme.icon}
                </div>
                <p className="font-medium text-gray-900 dark:text-gray-100">{theme.label}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Accent Color */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Vurgu Rengi</h3>
        <div className="grid grid-cols-5 gap-3">
          {accentColors.map((color) => (
            <button
              key={color.value}
              onClick={() => setCustomization({ ...customization, accentColor: color.value })}
              className={`p-4 rounded-lg border-2 transition-all ${
                customization.accentColor === color.value
                  ? 'border-gray-900 scale-110'
                  : 'border-gray-200 dark:border-slate-700 hover:scale-105'
              }`}
            >
              <div className={`w-full h-12 ${color.color} rounded-lg mb-2`}></div>
              <p className="text-xs font-medium text-gray-900 dark:text-gray-100">{color.label}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Localization */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Globe className="w-5 h-5 inline mr-2" />
          Bölgeselleştirme
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Dil</label>
            <select
              value={customization.language}
              onChange={(e) => setCustomization({ ...customization, language: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="tr">Türkçe</option>
              <option value="en">English</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="w-4 h-4 inline mr-1" />
              Para Birimi
            </label>
            <select
              value={customization.currency}
              onChange={(e) => setCustomization({ ...customization, currency: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="TRY">₺ Türk Lirası (TRY)</option>
              <option value="USD">$ Dolar (USD)</option>
              <option value="EUR">€ Euro (EUR)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Sayı Formatı</label>
            <select
              value={customization.numberFormat}
              onChange={(e) => setCustomization({ ...customization, numberFormat: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="tr">1.000,00 (TR)</option>
              <option value="en">1,000.00 (EN)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Dashboard Layout */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Dashboard Düzeni</h3>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Varsayılan Sayfa (Giriş Sonrası)</label>
          <select
            value={customization.defaultPage}
            onChange={(e) => setCustomization({ ...customization, defaultPage: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="/dashboard">Dashboard</option>
            <option value="/conversations">Konuşmalar</option>
            <option value="/appointments">Randevular</option>
            <option value="/reports">Raporlar</option>
          </select>
        </div>
      </div>

      {/* Preview */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Önizleme</h3>
        <div className={`p-6 rounded-lg ${customization.theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50 dark:bg-slate-900'}`}>
          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-12 h-12 rounded-lg"
              style={{ backgroundColor: customization.accentColor }}
            ></div>
            <div>
              <p className={`font-semibold ${customization.theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                Örnek Başlık
              </p>
              <p className={`text-sm ${customization.theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                Bu bir önizleme metnidir
              </p>
            </div>
          </div>
          <button
            className="px-4 py-2 text-white rounded-lg"
            style={{ backgroundColor: customization.accentColor }}
          >
            Örnek Buton
          </button>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <button className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium">
          İptal
        </button>
        <button
          onClick={handleSave}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          Değişiklikleri Kaydet
        </button>
      </div>
    </div>
  );
};

export default CustomizationSettings;



