import React, { useState, useRef } from 'react';
import { Camera, Mail, Phone, Lock, Globe, Clock, Save, Shield, LogOut, Check } from 'lucide-react';

const ProfileSettings: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [is2FAEnabled, setIs2FAEnabled] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: 'Admin',
    lastName: 'User',
    email: 'admin@asistanapp.com',
    phone: '+90 555 123 4567',
    avatar: '',
    locale: 'tr',
    timezone: 'Europe/Istanbul',
    dateFormat: 'DD/MM/YYYY'
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [sessions, setSessions] = useState([
    { id: 1, device: 'Chrome on Windows', ip: '192.168.1.100', location: 'Istanbul, TR', lastActive: '2 dakika önce', current: true },
    { id: 2, device: 'Safari on iPhone', ip: '78.186.45.12', location: 'Ankara, TR', lastActive: '3 saat önce', current: false },
    { id: 3, device: 'Firefox on Mac', ip: '85.34.78.90', location: 'Izmir, TR', lastActive: '1 gün önce', current: false }
  ]);

  const handleUploadPhoto = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('❌ Dosya boyutu 2MB\'dan küçük olmalıdır!');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, avatar: reader.result as string });
        alert('✅ Fotoğraf yüklendi! Değişiklikleri kaydetmeyi unutmayın.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    if (confirm('Profil fotoğrafınızı kaldırmak istediğinizden emin misiniz?')) {
      setFormData({ ...formData, avatar: '' });
      alert('✅ Profil fotoğrafı kaldırıldı!');
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    alert('✅ Profil bilgileri başarıyla kaydedildi!');
    console.log('Profile data saved:', formData);
  };

  const handlePasswordChange = () => {
    if (!passwordData.currentPassword) {
      alert('❌ Mevcut şifrenizi giriniz!');
      return;
    }
    if (passwordData.newPassword.length < 8) {
      alert('❌ Yeni şifre en az 8 karakter olmalıdır!');
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert('❌ Yeni şifreler eşleşmiyor!');
      return;
    }
    alert('✅ Şifre başarıyla değiştirildi!');
    console.log('Password changed');
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const handleTerminateSession = (sessionId: number) => {
    if (confirm('Bu oturumu sonlandırmak istediğinizden emin misiniz?')) {
      setSessions(sessions.filter(s => s.id !== sessionId));
      alert(`🔒 Oturum sonlandırıldı!`);
    }
  };

  const handleToggle2FA = () => {
    if (!is2FAEnabled) {
      if (confirm('İki faktörlü doğrulamayı etkinleştirmek istediğinizden emin misiniz?')) {
        setIs2FAEnabled(true);
        alert('✅ 2FA etkinleştirildi! QR kodu email adresinize gönderildi.');
      }
    } else {
      if (confirm('İki faktörlü doğrulamayı devre dışı bırakmak istediğinizden emin misiniz?')) {
        setIs2FAEnabled(false);
        alert('✅ 2FA devre dışı bırakıldı!');
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Profil & Hesap Ayarları</h2>
        <p className="text-sm text-gray-500 mt-1">Kişisel bilgilerinizi ve hesap tercihlerinizi yönetin</p>
      </div>

      {/* Profile Picture */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Profil Fotoğrafı</h3>
        <div className="flex items-center gap-6">
          <div className="relative">
            {formData.avatar ? (
              <img src={formData.avatar} alt="Avatar" className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg" />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                {formData.firstName[0]}{formData.lastName[0]}
              </div>
            )}
            <button 
              onClick={handleUploadPhoto}
              className="absolute bottom-0 right-0 bg-white dark:bg-slate-800 rounded-full p-2 shadow-lg border border-gray-200 dark:border-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
            >
              <Camera className="w-4 h-4 text-gray-700 dark:text-gray-300" />
            </button>
          </div>
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <button 
              onClick={handleUploadPhoto}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium"
            >
              Fotoğraf Yükle
            </button>
            <button 
              onClick={handleRemovePhoto}
              disabled={!formData.avatar}
              className="ml-2 px-4 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Kaldır
            </button>
            <p className="text-xs text-gray-500 mt-2">JPG, PNG veya GIF. Maksimum 2MB.</p>
          </div>
        </div>
      </div>

      {/* Personal Information */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Kişisel Bilgiler</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Ad</label>
            <input
              type="text"
              value={formData.firstName}
              onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Soyad</label>
            <input
              type="text"
              value={formData.lastName}
              onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Mail className="w-4 h-4 inline mr-1" />
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Phone className="w-4 h-4 inline mr-1" />
              Telefon
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Preferences */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Tercihler</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Globe className="w-4 h-4 inline mr-1" />
              Dil
            </label>
            <select
              value={formData.locale}
              onChange={(e) => setFormData({ ...formData, locale: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="tr">Türkçe</option>
              <option value="en">English</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Clock className="w-4 h-4 inline mr-1" />
              Zaman Dilimi
            </label>
            <select
              value={formData.timezone}
              onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="Europe/Istanbul">Istanbul (GMT+3)</option>
              <option value="Europe/London">London (GMT+0)</option>
              <option value="America/New_York">New York (GMT-5)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tarih Formatı</label>
            <select
              value={formData.dateFormat}
              onChange={(e) => setFormData({ ...formData, dateFormat: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="DD/MM/YYYY">DD/MM/YYYY</option>
              <option value="MM/DD/YYYY">MM/DD/YYYY</option>
              <option value="YYYY-MM-DD">YYYY-MM-DD</option>
            </select>
          </div>
        </div>
      </div>

      {/* Password Change */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Lock className="w-5 h-5 inline mr-2" />
          Şifre Değiştir
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Mevcut Şifre</label>
            <input
              type="password"
              value={passwordData.currentPassword}
              onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="••••••••"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Yeni Şifre</label>
              <input
                type="password"
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="••••••••"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Yeni Şifre (Tekrar)</label>
              <input
                type="password"
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="••••••••"
              />
            </div>
          </div>
          <button
            onClick={handlePasswordChange}
            className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors text-sm font-medium"
          >
            Şifreyi Güncelle
          </button>
        </div>
      </div>

      {/* Two-Factor Authentication */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              <Shield className="w-5 h-5 inline mr-2" />
              İki Faktörlü Doğrulama (2FA)
            </h3>
            <p className="text-sm text-gray-500 mt-1">Hesabınızı ekstra bir güvenlik katmanı ile koruyun</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              checked={is2FAEnabled}
              onChange={handleToggle2FA}
              className="sr-only peer" 
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
        {is2FAEnabled ? (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-2">
            <Check className="w-5 h-5 text-green-600" />
            <p className="text-sm text-green-800">
              <strong>Aktif:</strong> Hesabınız 2FA ile korunuyor.
            </p>
          </div>
        ) : (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-sm text-amber-800">
              <strong>Önerilen:</strong> 2FA'yı etkinleştirerek hesabınızı yetkisiz erişime karşı koruyun.
            </p>
          </div>
        )}
      </div>

      {/* Active Sessions */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Aktif Oturumlar</h3>
        <div className="space-y-3">
          {sessions.map((session) => (
            <div key={session.id} className={`flex items-center justify-between p-4 rounded-lg border ${session.current ? 'bg-green-50 border-green-200' : 'bg-gray-50 dark:bg-slate-900 border-gray-200 dark:border-slate-700'}`}>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-gray-900 dark:text-gray-100">{session.device}</p>
                  {session.current && (
                    <span className="text-xs bg-green-500 text-white px-2 py-1 rounded-full">Aktif</span>
                  )}
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{session.ip} • {session.location}</p>
                <p className="text-xs text-gray-500 mt-1">Son aktivite: {session.lastActive}</p>
              </div>
              {!session.current && (
                <button
                  onClick={() => handleTerminateSession(session.id)}
                  className="px-3 py-1.5 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-1"
                >
                  <LogOut className="w-4 h-4" />
                  Sonlandır
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <button 
          onClick={() => window.location.reload()}
          className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
        >
          İptal
        </button>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Değişiklikleri Kaydet
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default ProfileSettings;

