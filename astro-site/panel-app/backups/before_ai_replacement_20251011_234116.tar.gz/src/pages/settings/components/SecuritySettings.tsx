import React, { useState } from 'react';
import { Shield, Lock, Eye, Download, Trash2, Save } from 'lucide-react';

const SecuritySettings: React.FC = () => {
  const [security, setSecuritySettings] = useState({
    encryption: true,
    sessionTimeout: 30,
    ipRestriction: false,
    allowedIPs: '',
    dataRetention: 365,
    autoBackup: true,
    backupFrequency: 'daily'
  });

  const [activityLogs] = useState([
    { id: 1, action: 'Giriş', user: 'admin@asistanapp.com', ip: '192.168.1.100', time: '5 dakika önce', status: 'success' },
    { id: 2, action: 'Ayar değişikliği', user: 'admin@asistanapp.com', ip: '192.168.1.100', time: '1 saat önce', status: 'success' },
    { id: 3, action: 'Giriş denemesi', user: 'unknown@example.com', ip: '185.45.78.90', time: '2 saat önce', status: 'failed' }
  ]);

  const handleSave = () => {
    alert('✅ Güvenlik ayarları kaydedildi!');
  };

  const handleExportData = () => {
    alert('📦 Verileriniz hazırlanıyor ve email adresinize gönderilecek!');
  };

  const handleDeleteAccount = () => {
    if (confirm('⚠️ UYARI: Bu işlem geri alınamaz! Tüm verileriniz kalıcı olarak silinecek. Emin misiniz?')) {
      alert('Hesap silme işlemi iptal edildi. (Demo)');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Güvenlik & Gizlilik</h2>
        <p className="text-sm text-gray-500 mt-1">Güvenlik ayarlarınızı yönetin</p>
      </div>

      {/* Data Security */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Lock className="w-5 h-5 inline mr-2 text-blue-500" />
          Veri Güvenliği
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Veri Şifreleme</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Tüm veriler AES-256 ile şifrelenir</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={security.encryption}
                onChange={(e) => setSecuritySettings({ ...security, encryption: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Oturum Zaman Aşımı (dakika)</label>
            <select
              value={security.sessionTimeout}
              onChange={(e) => setSecuritySettings({ ...security, sessionTimeout: parseInt(e.target.value) })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value={15}>15 dakika</option>
              <option value={30}>30 dakika</option>
              <option value={60}>1 saat</option>
              <option value={120}>2 saat</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">IP Kısıtlaması</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Sadece belirli IP adreslerinden erişime izin ver</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={security.ipRestriction}
                onChange={(e) => setSecuritySettings({ ...security, ipRestriction: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
          {security.ipRestriction && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">İzin Verilen IP Adresleri</label>
              <textarea
                value={security.allowedIPs}
                onChange={(e) => setSecuritySettings({ ...security, allowedIPs: e.target.value })}
                placeholder="192.168.1.1&#10;10.0.0.1"
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Her satıra bir IP adresi</p>
            </div>
          )}
        </div>
      </div>

      {/* Activity Logs */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Eye className="w-5 h-5 inline mr-2" />
          Aktivite Logları
        </h3>
        <div className="space-y-2">
          {activityLogs.map((log) => (
            <div key={log.id} className={`p-3 rounded-lg border ${log.status === 'success' ? 'bg-gray-50 dark:bg-slate-900 border-gray-200 dark:border-slate-700' : 'bg-red-50 border-red-200'}`}>
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900 dark:text-gray-100">{log.action}</p>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${log.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {log.status === 'success' ? 'Başarılı' : 'Başarısız'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{log.user} • {log.ip} • {log.time}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* KVKK/GDPR */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Shield className="w-5 h-5 inline mr-2 text-green-500" />
          KVKK / GDPR Uyum
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Veri Saklama Süresi (gün)</label>
            <select
              value={security.dataRetention}
              onChange={(e) => setSecuritySettings({ ...security, dataRetention: parseInt(e.target.value) })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value={90}>90 gün</option>
              <option value={180}>6 ay</option>
              <option value={365}>1 yıl</option>
              <option value={730}>2 yıl</option>
            </select>
          </div>
          <button
            onClick={handleExportData}
            className="w-full px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            Tüm Verilerimi İndir
          </button>
        </div>
      </div>

      {/* Backup */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Otomatik Yedekleme</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">Otomatik Yedekleme</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Verileriniz otomatik olarak yedeklenir</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={security.autoBackup}
                onChange={(e) => setSecuritySettings({ ...security, autoBackup: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
            </label>
          </div>
          {security.autoBackup && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Yedekleme Sıklığı</label>
              <select
                value={security.backupFrequency}
                onChange={(e) => setSecuritySettings({ ...security, backupFrequency: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="daily">Günlük</option>
                <option value="weekly">Haftalık</option>
                <option value="monthly">Aylık</option>
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-red-50 rounded-xl border-2 border-red-200 p-6">
        <h3 className="text-lg font-semibold text-red-900 mb-4">⚠️ Tehlikeli Alan</h3>
        <p className="text-sm text-red-700 mb-4">Bu işlemler geri alınamaz. Dikkatli olun!</p>
        <button
          onClick={handleDeleteAccount}
          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium flex items-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          Hesabımı Kalıcı Olarak Sil
        </button>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <button className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium">
          İptal
        </button>
        <button
          onClick={handleSave}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          Değişiklikleri Kaydet
        </button>
      </div>
    </div>
  );
};

export default SecuritySettings;



