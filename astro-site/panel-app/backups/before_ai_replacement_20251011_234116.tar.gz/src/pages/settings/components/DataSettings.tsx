import React from 'react';
import { Database, Download, Upload, Trash2, RefreshCw } from 'lucide-react';

const DataSettings: React.FC = () => {
  const handleExportCustomers = () => {
    const link = document.createElement('a');
    link.href = '#';
    link.download = `musteriler_${new Date().toISOString().split('T')[0]}.xlsx`;
    alert('✅ Müşteri listesi indiriliyor...\n\nDosya adı: ' + link.download);
    console.log('Exporting customers to Excel...');
  };

  const handleExportAppointments = () => {
    const link = document.createElement('a');
    link.href = '#';
    link.download = `randevular_${new Date().toISOString().split('T')[0]}.xlsx`;
    alert('✅ Randevu geçmişi indiriliyor...\n\nDosya adı: ' + link.download);
    console.log('Exporting appointments to Excel...');
  };

  const handleExportMessages = () => {
    const link = document.createElement('a');
    link.href = '#';
    link.download = `mesajlar_${new Date().toISOString().split('T')[0]}.csv`;
    alert('✅ Mesaj geçmişi indiriliyor...\n\nDosya adı: ' + link.download);
    console.log('Exporting messages to CSV...');
  };

  const handleExportReports = () => {
    const link = document.createElement('a');
    link.href = '#';
    link.download = `raporlar_${new Date().toISOString().split('T')[0]}.pdf`;
    alert('✅ Raporlar PDF formatında indiriliyor...\n\nDosya adı: ' + link.download);
    console.log('Exporting reports to PDF...');
  };

  const handleImportCustomers = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx,.xls,.csv';
    input.onchange = (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        alert(`✅ "${file.name}" dosyası yükleniyor...\n\nBoyut: ${(file.size / 1024).toFixed(2)} KB\n\nİşlem tamamlandığında bildirim alacaksınız.`);
        console.log('Importing customers from:', file.name);
      }
    };
    input.click();
  };

  const handleImportAppointments = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx,.xls,.csv';
    input.onchange = (e: Event) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        alert(`✅ "${file.name}" dosyası yükleniyor...\n\nToplu randevu ekleme başlatıldı.`);
        console.log('Importing appointments from:', file.name);
      }
    };
    input.click();
  };

  const handleManualBackup = async () => {
    const confirmed = confirm('Tüm verilerinizin yedeği alınacak. Bu işlem birkaç dakika sürebilir. Devam etmek istiyor musunuz?');
    if (confirmed) {
      alert('💾 Manuel yedekleme başlatıldı!\n\n• Müşteri verileri\n• Konuşma geçmişi\n• Randevular\n• Ayarlar\n\nYedek tamamlandığında email adresinize gönderilecek.');
      console.log('Manual backup started at:', new Date().toISOString());
    }
  };

  const handleDownloadLastBackup = () => {
    const link = document.createElement('a');
    link.href = '#';
    link.download = `yedek_15_01_2025_03_00.zip`;
    alert('✅ Son yedek indiriliyor...\n\nDosya: ' + link.download + '\nTarih: 15 Ocak 2025, 03:00\nBoyut: ~2.4 GB');
  };

  const handleBulkDelete = () => {
    if (confirm('⚠️ TEHLİKE!\n\nBu işlem geri alınamaz!\n\nBelirttiğiniz tarih aralığındaki TÜM veriler kalıcı olarak silinecek:\n• Müşteriler\n• Konuşmalar\n• Randevular\n• Mesajlar\n\nEmin misiniz?')) {
      const doubleConfirm = confirm('Son kez soruyoruz: Bu işlem GERİ ALINAMAZ!\n\n"Evet, verileri sil" yazmanız gerekiyor.');
      if (doubleConfirm) {
        alert('🛡️ Güvenlik nedeniyle bu işlem iptal edildi.\n\nGerçek ortamda bu işlem için ek doğrulama gerekir.');
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Veri Yönetimi</h2>
        <p className="text-sm text-gray-500 mt-1">Veri içe/dışa aktarma ve yedekleme işlemleri</p>
      </div>

      {/* Export Data */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Download className="w-5 h-5 inline mr-2 text-blue-500" />
          Veri Dışa Aktarma
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Verilerinizi Excel veya CSV formatında indirin</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={handleExportCustomers}
            className="p-4 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-medium text-gray-900 dark:text-gray-100">Müşteri Listesi</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Excel (.xlsx)</p>
              </div>
            </div>
          </button>

          <button
            onClick={handleExportAppointments}
            className="p-4 bg-green-50 hover:bg-green-100 border border-green-200 rounded-lg transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-medium text-gray-900 dark:text-gray-100">Randevu Geçmişi</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Excel (.xlsx)</p>
              </div>
            </div>
          </button>

          <button
            onClick={handleExportMessages}
            className="p-4 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-medium text-gray-900 dark:text-gray-100">Mesaj Geçmişi</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">CSV (.csv)</p>
              </div>
            </div>
          </button>

          <button 
            onClick={handleExportReports}
            className="p-4 bg-orange-50 hover:bg-orange-100 border border-orange-200 rounded-lg transition-colors text-left"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-medium text-gray-900 dark:text-gray-100">Tüm Raporlar</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">PDF (.pdf)</p>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Import Data */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Upload className="w-5 h-5 inline mr-2 text-green-500" />
          Veri İçe Aktarma
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Excel veya CSV dosyalarından veri yükleyin</p>
        <div className="space-y-3">
          <button
            onClick={handleImportCustomers}
            className="w-full p-4 bg-green-50 hover:bg-green-100 border border-green-200 rounded-lg transition-colors flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                <Upload className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className="font-medium text-gray-900 dark:text-gray-100">Müşteri Listesi Yükle</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Excel veya CSV formatında</p>
              </div>
            </div>
            <span className="text-sm text-green-600 font-medium">Seç</span>
          </button>

          <button 
            onClick={handleImportAppointments}
            className="w-full p-4 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Upload className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className="font-medium text-gray-900 dark:text-gray-100">Toplu Randevu Ekleme</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Excel formatında</p>
              </div>
            </div>
            <span className="text-sm text-blue-600 font-medium">Seç</span>
          </button>
        </div>

        <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-sm text-amber-800">
            <strong>Not:</strong> İçe aktarma şablonları için lütfen destek ekibimizle iletişime geçin.
          </p>
        </div>
      </div>

      {/* Manual Backup */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Database className="w-5 h-5 inline mr-2 text-purple-500" />
          Manuel Yedekleme
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Tüm verilerinizin yedeğini hemen alın</p>
        <button
          onClick={handleManualBackup}
          className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors font-medium flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          Şimdi Yedekle
        </button>
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-slate-900 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Son Yedekleme</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">15 Ocak 2025, 03:00 • 2.4 GB</p>
            </div>
            <button 
              onClick={handleDownloadLastBackup}
              className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
            >
              <Download className="w-4 h-4" />
              İndir
            </button>
          </div>
        </div>
      </div>

      {/* Bulk Delete */}
      <div className="bg-red-50 rounded-xl border-2 border-red-200 p-6">
        <h3 className="text-lg font-semibold text-red-900 mb-4">
          <Trash2 className="w-5 h-5 inline mr-2" />
          ⚠️ Toplu Veri Silme
        </h3>
        <p className="text-sm text-red-700 mb-4">
          Belirli tarih aralığındaki verileri toplu olarak silin. <strong>Bu işlem geri alınamaz!</strong>
        </p>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-sm font-medium text-red-900 mb-2">Başlangıç Tarihi</label>
            <input
              type="date"
              className="w-full px-4 py-2 border border-red-300 rounded-lg focus:ring-2 focus:ring-red-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-red-900 mb-2">Bitiş Tarihi</label>
            <input
              type="date"
              className="w-full px-4 py-2 border border-red-300 rounded-lg focus:ring-2 focus:ring-red-500"
            />
          </div>
        </div>
        <button
          onClick={handleBulkDelete}
          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium flex items-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          Toplu Sil
        </button>
      </div>
    </div>
  );
};

export default DataSettings;

