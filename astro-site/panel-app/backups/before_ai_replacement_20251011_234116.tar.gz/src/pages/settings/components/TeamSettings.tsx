import React, { useState } from 'react';
import { Users, UserPlus, Shield, Mail, Save, Trash2 } from 'lucide-react';

interface TeamMember {
  id: number;
  name: string;
  email: string;
  role: string;
  status: 'active' | 'inactive';
  lastLogin: string;
}

const TeamSettings: React.FC = () => {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { id: 1, name: 'Admin User', email: 'admin@asistanapp.com', role: 'owner', status: 'active', lastLogin: '2 dakika önce' },
    { id: 2, name: 'Dr. Ayşe Yılmaz', email: 'ayse@asistanapp.com', role: 'manager', status: 'active', lastLogin: '1 saat önce' },
    { id: 3, name: 'Resepsiyonist Elif', email: 'elif@asistanapp.com', role: 'agent', status: 'active', lastLogin: '5 dakika önce' }
  ]);

  const [newMember, setNewMember] = useState({ email: '', role: 'agent' });

  const roles = [
    { value: 'owner', label: 'Firma Sahibi', description: 'Tam yetki' },
    { value: 'admin', label: 'Admin', description: 'Sistem yönetimi' },
    { value: 'manager', label: 'Müdür', description: 'Ekip yönetimi' },
    { value: 'agent', label: 'Temsilci', description: 'Müşteri hizmetleri' },
    { value: 'readonly', label: 'İzleyici', description: 'Sadece görüntüleme' }
  ];

  const handleInvite = () => {
    if (newMember.email) {
      alert(`✉️ ${newMember.email} adresine davet gönderildi!`);
      setNewMember({ email: '', role: 'agent' });
    }
  };

  const handleRemove = (id: number) => {
    if (confirm('Bu kullanıcıyı kaldırmak istediğinizden emin misiniz?')) {
      setTeamMembers(teamMembers.filter(m => m.id !== id));
      alert('✅ Kullanıcı kaldırıldı!');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Ekip Yönetimi</h2>
        <p className="text-sm text-gray-500 mt-1">Kullanıcıları yönetin ve yetkilendirin</p>
      </div>

      {/* Invite New Member */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <UserPlus className="w-5 h-5 inline mr-2 text-blue-500" />
          Yeni Ekip Üyesi Davet Et
        </h3>
        <div className="flex gap-3">
          <input
            type="email"
            value={newMember.email}
            onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
            placeholder="email@example.com"
            className="flex-1 px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <select
            value={newMember.role}
            onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
            className="px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {roles.map((role) => (
              <option key={role.value} value={role.value}>{role.label}</option>
            ))}
          </select>
          <button
            onClick={handleInvite}
            className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2"
          >
            <Mail className="w-4 h-4" />
            Davet Gönder
          </button>
        </div>
      </div>

      {/* Team Members List */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Users className="w-5 h-5 inline mr-2" />
          Ekip Üyeleri ({teamMembers.length})
        </h3>
        <div className="space-y-3">
          {teamMembers.map((member) => (
            <div key={member.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-900 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <div className="flex items-center gap-4 flex-1">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                  {member.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900 dark:text-gray-100">{member.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{member.email}</p>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                    <Shield className="w-3 h-3" />
                    {roles.find(r => r.value === member.role)?.label}
                  </span>
                  <p className="text-xs text-gray-500 mt-1">Son giriş: {member.lastLogin}</p>
                </div>
              </div>
              {member.role !== 'owner' && (
                <button
                  onClick={() => handleRemove(member.id)}
                  className="ml-4 p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Roles & Permissions */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Rol İzinleri</h3>
        <div className="space-y-3">
          {roles.map((role) => (
            <div key={role.value} className="p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900 dark:text-gray-100">{role.label}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{role.description}</p>
                </div>
                <button className="px-3 py-1 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                  Düzenle
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TeamSettings;



