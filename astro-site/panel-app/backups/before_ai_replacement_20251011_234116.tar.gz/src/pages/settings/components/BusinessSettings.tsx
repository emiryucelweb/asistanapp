import React, { useState, useRef } from 'react';
import { Building2, MapPin, Phone, Mail, Globe, Clock, Save, Upload } from 'lucide-react';

const BusinessSettings: React.FC = () => {
  const logoInputRef = useRef<HTMLInputElement>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [logoPreview, setLogoPreview] = useState('');
  
  const [formData, setFormData] = useState({
    name: 'AsistanApp Diş Kliniği',
    businessType: 'dental_clinic',
    description: 'Modern diş sağlığı ve estetik tedaviler',
    taxNumber: '1234567890',
    tradeRegister: 'Istanbul-123456',
    phone: '+90 212 555 1234',
    email: 'info@asistanapp.com',
    website: 'https://asistanapp.com',
    instagram: '@asistanapp',
    facebook: 'asistanapp',
    linkedin: 'asistanapp',
    address: 'Levent Mahallesi, Cevizli Sokak No:15',
    city: 'Istanbul',
    district: 'Beşiktaş',
    postalCode: '34330'
  });

  const [workingHours, setWorkingHours] = useState([
    { day: 'Pazartesi', enabled: true, start: '09:00', end: '18:00' },
    { day: 'Salı', enabled: true, start: '09:00', end: '18:00' },
    { day: 'Çarşamba', enabled: true, start: '09:00', end: '18:00' },
    { day: 'Perşembe', enabled: true, start: '09:00', end: '18:00' },
    { day: 'Cuma', enabled: true, start: '09:00', end: '18:00' },
    { day: 'Cumartesi', enabled: true, start: '10:00', end: '16:00' },
    { day: 'Pazar', enabled: false, start: '10:00', end: '16:00' }
  ]);

  const businessTypes = [
    { value: 'dental_clinic', label: '🦷 Diş Kliniği' },
    { value: 'hospital', label: '🏥 Hastane & Poliklinik' },
    { value: 'aesthetic_center', label: '💆 Estetik Merkezi' },
    { value: 'hair_salon', label: '💇 Kuaför Salonu' },
    { value: 'beauty_salon', label: '💅 Güzellik Salonu' },
    { value: 'cafe', label: '☕ Kafe' },
    { value: 'restaurant', label: '🍽️ Restoran' },
    { value: 'hotel', label: '🏨 Otel' },
    { value: 'fitness_center', label: '💪 Fitness Center' },
    { value: 'other', label: '🏢 Diğer' }
  ];

  const handleUploadLogo = () => {
    logoInputRef.current?.click();
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1 * 1024 * 1024) {
        alert('❌ Logo boyutu 1MB\'dan küçük olmalıdır!');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
        alert('✅ Logo yüklendi! Değişiklikleri kaydetmeyi unutmayın.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    alert('✅ İşletme bilgileri başarıyla kaydedildi!');
    console.log('Business data saved:', formData, workingHours, logoPreview);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">İşletme Bilgileri</h2>
        <p className="text-sm text-gray-500 mt-1">Firma bilgilerinizi ve çalışma saatlerinizi yönetin</p>
      </div>

      {/* Logo */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Logo & Marka</h3>
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-pink-500 rounded-xl flex items-center justify-center overflow-hidden">
            {logoPreview ? (
              <img src={logoPreview} alt="Logo" className="w-full h-full object-cover" />
            ) : (
              <Building2 className="w-12 h-12 text-white" />
            )}
          </div>
          <div>
            <input
              ref={logoInputRef}
              type="file"
              accept="image/png,image/svg+xml"
              onChange={handleLogoChange}
              className="hidden"
            />
            <button 
              onClick={handleUploadLogo}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm font-medium flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Logo Yükle
            </button>
            <p className="text-xs text-gray-500 mt-2">PNG veya SVG. Maksimum 1MB. Önerilen boyut: 256x256px</p>
          </div>
        </div>
      </div>

      {/* Basic Information */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Temel Bilgiler</h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Firma Adı</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Sektör</label>
              <select
                value={formData.businessType}
                onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {businessTypes.map((type) => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Vergi Numarası</label>
              <input
                type="text"
                value={formData.taxNumber}
                onChange={(e) => setFormData({ ...formData, taxNumber: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Açıklama/Slogan</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={2}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Contact Information */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">İletişim Bilgileri</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Phone className="w-4 h-4 inline mr-1" />
              Telefon
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Mail className="w-4 h-4 inline mr-1" />
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Globe className="w-4 h-4 inline mr-1" />
              Website
            </label>
            <input
              type="url"
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Instagram</label>
            <input
              type="text"
              value={formData.instagram}
              onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="@username"
            />
          </div>
        </div>
      </div>

      {/* Address */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <MapPin className="w-5 h-5 inline mr-2" />
          Adres Bilgileri
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tam Adres</label>
            <textarea
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              rows={2}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">İl</label>
              <select
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="Istanbul">Istanbul</option>
                <option value="Ankara">Ankara</option>
                <option value="Izmir">Izmir</option>
                <option value="Bursa">Bursa</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">İlçe</label>
              <input
                type="text"
                value={formData.district}
                onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Posta Kodu</label>
              <input
                type="text"
                value={formData.postalCode}
                onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Working Hours */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Clock className="w-5 h-5 inline mr-2" />
          Çalışma Saatleri
        </h3>
        <div className="space-y-3">
          {workingHours.map((day, index) => (
            <div key={day.day} className="flex items-center gap-4">
              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={day.enabled}
                  onChange={(e) => {
                    const newHours = [...workingHours];
                    newHours[index].enabled = e.target.checked;
                    setWorkingHours(newHours);
                  }}
                  className="w-4 h-4 text-blue-600 border-gray-300 dark:border-slate-600 rounded focus:ring-blue-500"
                />
                <span className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-100 w-24">{day.day}</span>
              </label>
              {day.enabled ? (
                <>
                  <input
                    type="time"
                    value={day.start}
                    onChange={(e) => {
                      const newHours = [...workingHours];
                      newHours[index].start = e.target.value;
                      setWorkingHours(newHours);
                    }}
                    className="px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                  <span className="text-gray-500 dark:text-gray-400">-</span>
                  <input
                    type="time"
                    value={day.end}
                    onChange={(e) => {
                      const newHours = [...workingHours];
                      newHours[index].end = e.target.value;
                      setWorkingHours(newHours);
                    }}
                    className="px-3 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                </>
              ) : (
                <span className="text-sm text-gray-400">Kapalı</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <button 
          onClick={() => window.location.reload()}
          className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
        >
          İptal
        </button>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Değişiklikleri Kaydet
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default BusinessSettings;

