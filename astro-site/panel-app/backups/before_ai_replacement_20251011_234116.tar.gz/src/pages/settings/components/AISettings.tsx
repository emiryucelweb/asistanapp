import React, { useState, useRef } from 'react';
import { Bot, Sparkles, MessageCircle, AlertCircle, FileText, Save, Upload, X } from 'lucide-react';

interface KnowledgeFile {
  id: number;
  name: string;
  size: string;
  uploadedAt: string;
}

const AISettings: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSaving, setIsSaving] = useState(false);
  
  const [aiConfig, setAiConfig] = useState({
    personality: 'professional',
    tone: 'friendly',
    useEmoji: 'sometimes',
    responseLength: 'medium',
    handoffThreshold: 3,
    enableAutoHandoff: true,
    workingHoursOnly: false
  });

  const [messages, setMessages] = useState({
    greeting: 'Merhaba! 👋 Size nasıl yardımcı olabilirim?',
    goodbye: 'İyi günler dilerim! Başka bir konuda yardıma ihtiyacınız olursa her zaman buradayım. 😊',
    busy: 'Şu anda yoğunuz, en kısa sürede size dönüş yapacağız.',
    holiday: 'Bugün kapalıyız. Hafta içi 09:00-18:00 saatleri arasında hizmet veriyoruz.'
  });

  const [urgentKeywords, setUrgentKeywords] = useState([
    'acil', 'şikayet', 'iptal', 'sorun', 'iade', 'ağrı', 'kanama', 'acı'
  ]);

  const [newKeyword, setNewKeyword] = useState('');
  
  const [knowledgeFiles, setKnowledgeFiles] = useState<KnowledgeFile[]>([
    { id: 1, name: 'tedavi-bilgileri.pdf', size: '1.2 MB', uploadedAt: '2 gün önce' },
    { id: 2, name: 'fiyat-listesi.xlsx', size: '450 KB', uploadedAt: '1 hafta önce' }
  ]);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    alert('✅ AI ayarları başarıyla kaydedildi!');
    console.log('AI config saved:', aiConfig, messages, urgentKeywords, knowledgeFiles);
  };

  const addKeyword = () => {
    if (!newKeyword.trim()) {
      alert('❌ Lütfen bir kelime girin!');
      return;
    }
    if (urgentKeywords.includes(newKeyword.toLowerCase().trim())) {
      alert('❌ Bu kelime zaten ekli!');
      return;
    }
    setUrgentKeywords([...urgentKeywords, newKeyword.toLowerCase().trim()]);
    setNewKeyword('');
    alert('✅ Anahtar kelime eklendi!');
  };

  const removeKeyword = (keyword: string) => {
    if (confirm(`"${keyword}" kelimesini kaldırmak istediğinizden emin misiniz?`)) {
      setUrgentKeywords(urgentKeywords.filter(k => k !== keyword));
      alert('✅ Anahtar kelime kaldırıldı!');
    }
  };

  const handleUploadFile = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        alert('❌ Dosya boyutu 10MB\'dan küçük olmalıdır!');
        return;
      }
      const newFile: KnowledgeFile = {
        id: Date.now(),
        name: file.name,
        size: (file.size / 1024 / 1024).toFixed(2) + ' MB',
        uploadedAt: 'Az önce'
      };
      setKnowledgeFiles([...knowledgeFiles, newFile]);
      alert('✅ Dosya başarıyla yüklendi!');
    }
  };

  const handleDeleteFile = (fileId: number) => {
    const file = knowledgeFiles.find(f => f.id === fileId);
    if (file && confirm(`"${file.name}" dosyasını silmek istediğinizden emin misiniz?`)) {
      setKnowledgeFiles(knowledgeFiles.filter(f => f.id !== fileId));
      alert('✅ Dosya silindi!');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">AI Asistan Ayarları</h2>
        <p className="text-sm text-gray-500 mt-1">Yapay zeka asistanınızın davranışını ve yanıtlarını özelleştirin</p>
      </div>

      {/* AI Personality */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <Sparkles className="w-5 h-5 inline mr-2 text-purple-500" />
          Kişilik & Ton
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">AI Kişiliği</label>
            <select
              value={aiConfig.personality}
              onChange={(e) => setAiConfig({ ...aiConfig, personality: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="professional">Profesyonel</option>
              <option value="friendly">Samimi</option>
              <option value="energetic">Enerjik</option>
              <option value="formal">Resmi</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">AI'nın genel davranış tarzı</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Yanıt Tonu</label>
            <select
              value={aiConfig.tone}
              onChange={(e) => setAiConfig({ ...aiConfig, tone: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="formal">Resmi</option>
              <option value="friendly">Arkadaşça</option>
              <option value="technical">Teknik</option>
              <option value="casual">Gündelik</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">Yanıtların üslup tarzı</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Emoji Kullanımı</label>
            <select
              value={aiConfig.useEmoji}
              onChange={(e) => setAiConfig({ ...aiConfig, useEmoji: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="never">Hiç Kullanma</option>
              <option value="sometimes">Ara Sıra</option>
              <option value="frequently">Sık Sık</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Yanıt Uzunluğu</label>
            <select
              value={aiConfig.responseLength}
              onChange={(e) => setAiConfig({ ...aiConfig, responseLength: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="short">Kısa (1-2 cümle)</option>
              <option value="medium">Orta (3-4 cümle)</option>
              <option value="long">Detaylı (5+ cümle)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Handoff Settings */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <AlertCircle className="w-5 h-5 inline mr-2 text-amber-500" />
          Akıllı Devir Ayarları
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border border-amber-200">
            <div className="flex-1">
              <p className="font-medium text-gray-900 dark:text-gray-100">Otomatik İnsan Devri</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">AI çözemediği durumlarda otomatik olarak insana devretsin</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={aiConfig.enableAutoHandoff}
                onChange={(e) => setAiConfig({ ...aiConfig, enableAutoHandoff: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Devir Eşiği (Mesaj Sayısı)</label>
            <div className="flex items-center gap-4">
              <input
                type="range"
                min="1"
                max="10"
                value={aiConfig.handoffThreshold}
                onChange={(e) => setAiConfig({ ...aiConfig, handoffThreshold: parseInt(e.target.value) })}
                className="flex-1"
              />
              <span className="text-lg font-bold text-blue-600 w-12 text-center">{aiConfig.handoffThreshold}</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">AI bu kadar mesajdan sonra yanıt veremezse insana devredilir</p>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
            <div className="flex-1">
              <p className="font-medium text-gray-900 dark:text-gray-100">Sadece Çalışma Saatlerinde AI</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Mesai dışında AI pasif olsun, sadece mesaj toplansın</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={aiConfig.workingHoursOnly}
                onChange={(e) => setAiConfig({ ...aiConfig, workingHoursOnly: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white dark:bg-slate-800 after:border-gray-300 dark:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Urgent Keywords */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Acil Durum Anahtar Kelimeleri</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">Bu kelimeleri içeren mesajlar anında insana devredilir</p>
        
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newKeyword}
            onChange={(e) => setNewKeyword(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addKeyword()}
            placeholder="Yeni kelime ekle..."
            className="flex-1 px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            onClick={addKeyword}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Ekle
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          {urgentKeywords.map((keyword) => (
            <span
              key={keyword}
              className="inline-flex items-center gap-1 px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium"
            >
              {keyword}
              <button
                onClick={() => removeKeyword(keyword)}
                className="ml-1 hover:text-red-900"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Custom Messages */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <MessageCircle className="w-5 h-5 inline mr-2 text-blue-500" />
          Özel Mesajlar
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Selamlama Mesajı</label>
            <textarea
              value={messages.greeting}
              onChange={(e) => setMessages({ ...messages, greeting: e.target.value })}
              rows={2}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Veda Mesajı</label>
            <textarea
              value={messages.goodbye}
              onChange={(e) => setMessages({ ...messages, goodbye: e.target.value })}
              rows={2}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Meşguliyet Mesajı</label>
            <textarea
              value={messages.busy}
              onChange={(e) => setMessages({ ...messages, busy: e.target.value })}
              rows={2}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tatil Mesajı</label>
            <textarea
              value={messages.holiday}
              onChange={(e) => setMessages({ ...messages, holiday: e.target.value })}
              rows={2}
              className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Knowledge Base */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <FileText className="w-5 h-5 inline mr-2 text-green-500" />
          Bilgi Bankası
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">AI'nıza öğretmek istediğiniz dökümanları yükleyin (FAQ, fiyat listesi, tedavi bilgileri vb.)</p>
        
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.txt,.doc,.docx,.xlsx,.xls"
          onChange={handleFileChange}
          className="hidden"
        />
        <div 
          onClick={handleUploadFile}
          className="border-2 border-dashed border-gray-300 dark:border-slate-600 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer"
        >
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Döküman Yükle</p>
          <p className="text-xs text-gray-500 mt-1">PDF, TXT, DOC veya XLSX. Maksimum 10MB.</p>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              handleUploadFile();
            }}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm"
          >
            Dosya Seç
          </button>
        </div>

        <div className="mt-4 space-y-2">
          {knowledgeFiles.map((file) => (
            <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-slate-900 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <div className="flex items-center gap-3">
                <FileText className={`w-5 h-5 ${file.name.endsWith('.pdf') ? 'text-blue-500' : 'text-green-500'}`} />
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{file.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{file.size} • {file.uploadedAt} yüklendi</p>
                </div>
              </div>
              <button 
                onClick={() => handleDeleteFile(file.id)}
                className="text-red-600 hover:text-red-700 text-sm font-medium flex items-center gap-1"
              >
                <X className="w-4 h-4" />
                Sil
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <button 
          onClick={() => window.location.reload()}
          className="px-6 py-2 border border-gray-300 dark:border-slate-600 text-gray-700 rounded-lg hover:bg-gray-50 dark:bg-slate-900 transition-colors font-medium"
        >
          İptal
        </button>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSaving ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Değişiklikleri Kaydet
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default AISettings;

