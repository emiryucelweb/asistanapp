import React, { useState } from 'react';
import { CreditCard, TrendingUp, FileText, Download } from 'lucide-react';

const BillingSettings: React.FC = () => {
  const [plan] = useState({
    name: 'Pro',
    price: 499,
    period: 'aylık',
    features: ['Sınırsız AI mesaj', '10,000 SMS/ay', '50 GB depolama', '10 ekip üyesi']
  });

  const [usage] = useState({
    sms: { used: 3245, total: 10000 },
    ai: { used: 8432, total: -1 },
    storage: { used: 23.5, total: 50 },
    team: { used: 3, total: 10 }
  });

  const [invoices] = useState([
    { id: 1, date: '01 Oca 2025', amount: 499, status: 'paid', invoice: 'INV-2025-001' },
    { id: 2, date: '01 Ara 2024', amount: 499, status: 'paid', invoice: 'INV-2024-012' },
    { id: 3, date: '01 Kas 2024', amount: 499, status: 'paid', invoice: 'INV-2024-011' }
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Ödeme & Faturalama</h2>
        <p className="text-sm text-gray-500 mt-1">Abonelik planınız ve ödeme bilgileriniz</p>
      </div>

      {/* Current Plan */}
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border-2 border-blue-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{plan.name} Plan</h3>
            <p className="text-3xl font-bold text-blue-600 mt-2">₺{plan.price}<span className="text-lg font-normal text-gray-600 dark:text-gray-400">/{plan.period}</span></p>
          </div>
          <button className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors font-medium flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Plan Yükselt
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2 mt-4">
          {plan.features.map((feature, idx) => (
            <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
              <span className="text-blue-600">✓</span>
              {feature}
            </div>
          ))}
        </div>
      </div>

      {/* Usage */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Kullanım İstatistikleri</h3>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">SMS</span>
              <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{usage.sms.used.toLocaleString('tr-TR')} / {usage.sms.total.toLocaleString('tr-TR')}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${(usage.sms.used / usage.sms.total) * 100}%` }}></div>
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">AI Mesaj</span>
              <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{usage.ai.used.toLocaleString('tr-TR')} / Sınırsız</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-green-500 h-2 rounded-full" style={{ width: '45%' }}></div>
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Depolama</span>
              <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">{usage.storage.used} GB / {usage.storage.total} GB</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-purple-500 h-2 rounded-full" style={{ width: `${(usage.storage.used / usage.storage.total) * 100}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Method */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <CreditCard className="w-5 h-5 inline mr-2" />
          Ödeme Yöntemi
        </h3>
        <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
          <div className="flex items-center gap-4">
            <div className="w-12 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded flex items-center justify-center text-white text-xs font-bold">
              VISA
            </div>
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">•••• •••• •••• 4242</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Geçerlilik: 12/2026</p>
            </div>
          </div>
          <button className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
            Değiştir
          </button>
        </div>
        <div className="mt-3">
          <label className="flex items-center">
            <input type="checkbox" checked className="w-4 h-4 text-blue-600 border-gray-300 dark:border-slate-600 rounded focus:ring-blue-500" />
            <span className="ml-2 text-sm text-gray-700">Otomatik ödeme aktif</span>
          </label>
        </div>
      </div>

      {/* Invoices */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
          <FileText className="w-5 h-5 inline mr-2" />
          Fatura Geçmişi
        </h3>
        <div className="space-y-2">
          {invoices.map((invoice) => (
            <div key={invoice.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-slate-900 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 dark:text-gray-100">{invoice.invoice}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{invoice.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <p className="font-bold text-gray-900 dark:text-gray-100">₺{invoice.amount}</p>
                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">Ödendi</span>
                <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BillingSettings;



