import React, { useState } from 'react';
import {
  User,
  Building2,
  Bot,
  MessageSquare,
  Users,
  Calendar,
  Bell,
  CreditCard,
  Plug,
  Shield,
  Palette,
  Database,
  Key,
  ChevronRight
} from 'lucide-react';

// Import settings components
import ProfileSettings from './components/ProfileSettings';
import BusinessSettings from './components/BusinessSettings';
import AISettings from './components/AISettings';
import ChannelSettings from './components/ChannelSettings';
import TeamSettings from './components/TeamSettings';
import AppointmentSettings from './components/AppointmentSettings';
import NotificationSettings from './components/NotificationSettings';
import BillingSettings from './components/BillingSettings';
import IntegrationSettings from './components/IntegrationSettings';
import SecuritySettings from './components/SecuritySettings';
import CustomizationSettings from './components/CustomizationSettings';
import DataSettings from './components/DataSettings';
import TenantAPISettings from './TenantAPISettings';

type SettingsCategory = 
  | 'profile'
  | 'business'
  | 'ai'
  | 'channels'
  | 'team'
  | 'appointments'
  | 'notifications'
  | 'billing'
  | 'integrations'
  | 'security'
  | 'customization'
  | 'data'
  | 'api';

interface SettingsMenuItem {
  id: SettingsCategory;
  label: string;
  icon: React.ReactNode;
  description: string;
}

const SettingsPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<SettingsCategory>('profile');

  const menuItems: SettingsMenuItem[] = [
    {
      id: 'profile',
      label: 'Profil & Hesap',
      icon: <User className="w-5 h-5" />,
      description: 'Kişisel bilgiler ve hesap ayarları'
    },
    {
      id: 'business',
      label: 'İşletme Bilgileri',
      icon: <Building2 className="w-5 h-5" />,
      description: 'Firma bilgileri ve çalışma saatleri'
    },
    {
      id: 'ai',
      label: 'AI Asistan',
      icon: <Bot className="w-5 h-5" />,
      description: 'Yapay zeka davranış ve ayarları'
    },
    {
      id: 'channels',
      label: 'Kanal Entegrasyonları',
      icon: <MessageSquare className="w-5 h-5" />,
      description: 'WhatsApp, Instagram, Facebook, Web'
    },
    {
      id: 'team',
      label: 'Ekip Yönetimi',
      icon: <Users className="w-5 h-5" />,
      description: 'Kullanıcılar, roller ve yetkiler'
    },
    {
      id: 'appointments',
      label: 'Randevu Ayarları',
      icon: <Calendar className="w-5 h-5" />,
      description: 'Randevu kuralları ve hatırlatmalar'
    },
    {
      id: 'notifications',
      label: 'Bildirimler',
      icon: <Bell className="w-5 h-5" />,
      description: 'Email, SMS ve push bildirimleri'
    },
    {
      id: 'billing',
      label: 'Ödeme & Faturalama',
      icon: <CreditCard className="w-5 h-5" />,
      description: 'Abonelik planı ve ödeme yöntemleri'
    },
    {
      id: 'integrations',
      label: 'Entegrasyonlar',
      icon: <Plug className="w-5 h-5" />,
      description: 'API ve 3. parti entegrasyonlar'
    },
    {
      id: 'security',
      label: 'Güvenlik & Gizlilik',
      icon: <Shield className="w-5 h-5" />,
      description: 'Güvenlik ayarları ve KVKK'
    },
    {
      id: 'customization',
      label: 'Özelleştirme',
      icon: <Palette className="w-5 h-5" />,
      description: 'Tema, dil ve görünüm'
    },
    {
      id: 'data',
      label: 'Veri Yönetimi',
      icon: <Database className="w-5 h-5" />,
      description: 'İçe/Dışa aktarma ve yedekleme'
    },
    {
      id: 'api',
      label: 'API Ayarları',
      icon: <Key className="w-5 h-5" />,
      description: 'API anahtarları ve kullanım limitleri'
    }
  ];

  const renderContent = () => {
    switch (activeCategory) {
      case 'profile':
        return <ProfileSettings />;
      case 'business':
        return <BusinessSettings />;
      case 'ai':
        return <AISettings />;
      case 'channels':
        return <ChannelSettings />;
      case 'team':
        return <TeamSettings />;
      case 'appointments':
        return <AppointmentSettings />;
      case 'notifications':
        return <NotificationSettings />;
      case 'billing':
        return <BillingSettings />;
      case 'integrations':
        return <IntegrationSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'customization':
        return <CustomizationSettings />;
      case 'data':
        return <DataSettings />;
      case 'api':
        return <TenantAPISettings />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors">
      {/* Header */}
      <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700">
        <div className="px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-gray-100">Ayarlar</h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">Hesabınızı ve sisteminizi yönetin</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col lg:flex-row">
        {/* Sidebar - Responsive */}
        <div className="w-full lg:w-80 bg-white dark:bg-slate-800 border-b lg:border-b-0 lg:border-r border-gray-200 dark:border-slate-700 lg:min-h-[calc(100vh-89px)] flex-shrink-0">
          <nav className="p-2 sm:p-4">
            <div className="space-y-1">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveCategory(item.id)}
                  className={`w-full flex items-center justify-between px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg text-left transition-all group ${
                    activeCategory === item.id
                      ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-l-4 border-blue-500 dark:border-blue-400'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 border-l-4 border-transparent'
                  }`}
                  aria-current={activeCategory === item.id ? 'page' : undefined}
                >
                  <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
                    <div className={activeCategory === item.id ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300'}>
                      {item.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs sm:text-sm font-medium ${activeCategory === item.id ? 'text-blue-700 dark:text-blue-400' : 'text-gray-900 dark:text-gray-100'}`}>
                        {item.label}
                      </p>
                      <p className="hidden sm:block text-xs text-gray-500 dark:text-gray-400 truncate mt-0.5">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  {activeCategory === item.id && (
                    <ChevronRight className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </nav>
        </div>

        {/* Content Area */}
        <div className="flex-1 min-w-0 bg-gray-50 dark:bg-slate-900">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;



