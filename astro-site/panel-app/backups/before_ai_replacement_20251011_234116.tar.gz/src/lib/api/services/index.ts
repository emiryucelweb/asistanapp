/**
 * API Services Index
 * Central export for all API services
 */
export { conversationsService } from './conversations.service';
export { dashboardService } from './dashboard.service';

// Export types
export type { Conversation, Message, CreateMessageDto } from './conversations.service';
export type { DashboardKPI, ChartData, ChannelDistribution, TeamPerformance } from './dashboard.service';

