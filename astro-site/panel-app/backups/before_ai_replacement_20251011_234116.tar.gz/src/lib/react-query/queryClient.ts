/**
 * React Query Configuration
 * QueryClient setup with default options
 */
import { QueryClient } from 'react-query';
import toast from 'react-hot-toast';

/**
 * Default Query Client Configuration
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Stale time - 5 minutes
      staleTime: 5 * 60 * 1000,
      
      // Cache time - 10 minutes
      cacheTime: 10 * 60 * 1000,
      
      // Refetch on window focus
      refetchOnWindowFocus: false,
      
      // Refetch on mount if stale
      refetchOnMount: true,
      
      // Refetch on reconnect
      refetchOnReconnect: true,
      
      // Retry failed requests
      retry: 1,
      
      // Retry delay
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      
      // Error handler
      onError: (error: any) => {
        console.error('Query Error:', error);
        
        // Show toast notification for errors
        if (error.response?.data?.message) {
          toast.error(error.response.data.message);
        } else if (error.message) {
          toast.error(error.message);
        } else {
          toast.error('Bir hata oluştu. Lütfen tekrar deneyin.');
        }
      },
    },
    mutations: {
      // Retry failed mutations
      retry: 0,
      
      // Error handler
      onError: (error: any) => {
        console.error('Mutation Error:', error);
        
        // Show toast notification for errors
        if (error.response?.data?.message) {
          toast.error(error.response.data.message);
        } else if (error.message) {
          toast.error(error.message);
        } else {
          toast.error('İşlem başarısız oldu. Lütfen tekrar deneyin.');
        }
      },
    },
  },
});

/**
 * Query Keys Factory
 * Centralized query key management
 */
export const queryKeys = {
  // Dashboard
  dashboard: {
    kpis: (range: string) => ['dashboard', 'kpis', range] as const,
    revenueTrend: (range: string) => ['dashboard', 'revenue-trend', range] as const,
    conversationTrend: (range: string) => ['dashboard', 'conversation-trend', range] as const,
    aiPerformance: (range: string) => ['dashboard', 'ai-performance', range] as const,
    channelDistribution: (range: string) => ['dashboard', 'channel-distribution', range] as const,
    teamPerformance: (range: string) => ['dashboard', 'team-performance', range] as const,
    alerts: () => ['dashboard', 'alerts'] as const,
  },
  
  // Conversations
  conversations: {
    all: () => ['conversations'] as const,
    list: (params?: any) => ['conversations', 'list', params] as const,
    detail: (id: string) => ['conversations', 'detail', id] as const,
    messages: (conversationId: string, params?: any) => ['conversations', 'messages', conversationId, params] as const,
    search: (query: string) => ['conversations', 'search', query] as const,
  },
  
  // Reports
  reports: {
    all: () => ['reports'] as const,
    category: (category: string, range: string) => ['reports', category, range] as const,
  },
  
  // Team
  team: {
    all: () => ['team'] as const,
    list: (params?: any) => ['team', 'list', params] as const,
    detail: (id: string) => ['team', 'detail', id] as const,
  },
  
  // Settings
  settings: {
    all: () => ['settings'] as const,
    profile: () => ['settings', 'profile'] as const,
    business: () => ['settings', 'business'] as const,
    ai: () => ['settings', 'ai'] as const,
  },
};

export default queryClient;

