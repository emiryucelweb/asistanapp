/**
 * i18n Configuration
 * Multi-language support setup
 */
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Translation resources
const resources = {
  tr: {
    translation: {
      common: {
        welcome: 'Hoş Geldiniz',
        loading: 'Yükleniyor...',
        error: 'Hata',
        success: 'Başarılı',
        save: 'Kaydet',
        cancel: 'İptal',
        delete: 'Sil',
        edit: 'Düzenle',
        search: 'Ara...',
      },
      navigation: {
        dashboard: 'Ana Sayfa',
        conversations: 'Konuşmalar',
        reports: 'Raporlar',
        settings: 'Ayarlar',
        team: 'Ekip',
        help: 'Yardım',
      },
      dashboard: {
        title: 'Ana Sayfa',
        activeConversations: 'Aktif Konuşmalar',
        aiResolutionRate: 'AI Çözüm Oranı',
        customerSatisfaction: 'Müşteri Memnuniyeti',
        revenue: 'Gelir',
      },
    },
  },
  en: {
    translation: {
      common: {
        welcome: 'Welcome',
        loading: 'Loading...',
        error: 'Error',
        success: 'Success',
        save: 'Save',
        cancel: 'Cancel',
        delete: 'Delete',
        edit: 'Edit',
        search: 'Search...',
      },
      navigation: {
        dashboard: 'Dashboard',
        conversations: 'Conversations',
        reports: 'Reports',
        settings: 'Settings',
        team: 'Team',
        help: 'Help',
      },
      dashboard: {
        title: 'Dashboard',
        activeConversations: 'Active Conversations',
        aiResolutionRate: 'AI Resolution Rate',
        customerSatisfaction: 'Customer Satisfaction',
        revenue: 'Revenue',
      },
    },
  },
};

i18n
  .use(LanguageDetector) // Detect browser language
  .use(initReactI18next) // React bindings
  .init({
    resources,
    fallbackLng: 'tr',
    debug: false,
    interpolation: {
      escapeValue: false, // React already escapes
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },
  });

export default i18n;


