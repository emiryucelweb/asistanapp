import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { getPanelI18nResources } from '@asistan/i18n';

// Get standardized resources from shared package
const resources = getPanelI18nResources();

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'tr', // default language
    fallbackLng: 'en',
    
    interpolation: {
      escapeValue: false, // react already does escaping
    },
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
    },
  });

export default i18n;