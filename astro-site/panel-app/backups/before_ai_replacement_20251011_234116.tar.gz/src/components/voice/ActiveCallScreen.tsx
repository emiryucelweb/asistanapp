/**
 * Active Call Screen - Aktif Görüşme Ekranı
 * Sol: Arama kontrolleri, Sağ: Mesaj geçmişi
 */
import React, { useState, useEffect } from 'react';
import {
  Phone,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  PhoneOff,
  Pause,
  Play,
  Users,
  MessageSquare,
  FileText,
  Signal,
  X,
  Send,
} from 'lucide-react';
import type { VoiceCall, CallMediaState, Message } from '../../types';

interface ActiveCallScreenProps {
  call: VoiceCall;
  mediaState: CallMediaState;
  onToggleMute: () => void;
  onToggleSpeaker: () => void;
  onHold: () => void;
  onResume?: () => void;
  onTransfer: () => void;
  onEndCall: () => void;
  onOpenNotes?: () => void;
  onOpenChat?: () => void;
  onToggleRecording?: () => void;
}

// Mock mesaj geçmişi
const mockMessages: Message[] = [
  {
    id: 'm1',
    tenantId: 'tenant-123',
    conversationId: 'conv-123',
    sender: 'user',
    content: 'Merhaba, ürün iadesi yapmak istiyorum',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    channel: 'whatsapp',
    messageType: 'text',
    metadata: {},
    isRead: true,
    isPartOfSequence: false,
  },
  {
    id: 'm2',
    tenantId: 'tenant-123',
    conversationId: 'conv-123',
    sender: 'agent',
    content: 'Merhaba, size yardımcı olmaktan mutluluk duyarım. Sipariş numaranızı alabilir miyim?',
    timestamp: new Date(Date.now() - 3540000).toISOString(),
    channel: 'whatsapp',
    messageType: 'text',
    metadata: {},
    isRead: true,
    isPartOfSequence: false,
  },
  {
    id: 'm3',
    tenantId: 'tenant-123',
    conversationId: 'conv-123',
    sender: 'user',
    content: 'SIP-2024-12345',
    timestamp: new Date(Date.now() - 3480000).toISOString(),
    channel: 'whatsapp',
    messageType: 'text',
    metadata: {},
    isRead: true,
    isPartOfSequence: false,
  },
  {
    id: 'm4',
    tenantId: 'tenant-123',
    conversationId: 'conv-123',
    sender: 'agent',
    content: 'Teşekkür ederim. Ürünle ilgili sorun nedir?',
    timestamp: new Date(Date.now() - 3420000).toISOString(),
    channel: 'whatsapp',
    messageType: 'text',
    metadata: {},
    isRead: true,
    isPartOfSequence: false,
  },
  {
    id: 'm5',
    tenantId: 'tenant-123',
    conversationId: 'conv-123',
    sender: 'user',
    content: 'Ürün bozuk geldi, çalışmıyor',
    timestamp: new Date(Date.now() - 3360000).toISOString(),
    channel: 'whatsapp',
    messageType: 'text',
    metadata: {},
    isRead: true,
    isPartOfSequence: false,
  },
];

const ActiveCallScreen: React.FC<ActiveCallScreenProps> = ({
  call,
  mediaState,
  onToggleMute,
  onToggleSpeaker,
  onHold,
  onResume,
  onTransfer,
  onEndCall,
}) => {
  const [callDuration, setCallDuration] = useState(0);
  const [newMessage, setNewMessage] = useState('');
  const [messages] = useState<Message[]>(mockMessages);

  useEffect(() => {
    if (call.status === 'connected' && call.startedAt) {
      const startTime = new Date(call.startedAt).getTime();
      const interval = setInterval(() => {
        const now = Date.now();
        const duration = Math.floor((now - startTime) / 1000);
        setCallDuration(duration);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [call.status, call.startedAt]);

  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  };

  const getQualityColor = () => {
    switch (mediaState.connection.quality) {
      case 'excellent':
        return 'text-green-600 dark:text-green-400';
      case 'good':
        return 'text-blue-600 dark:text-blue-400';
      case 'fair':
        return 'text-yellow-600 dark:text-yellow-400';
      case 'poor':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  const isOnHold = call.status === 'on_hold';

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // TODO: Mesaj gönderme işlemi
      setNewMessage('');
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-6xl h-[90vh] flex overflow-hidden">
        {/* Sol Taraf - Arama Kontrolleri */}
        <div className="w-1/2 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8 flex flex-col items-center justify-between relative">
          {/* Background Animation */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.2),transparent_70%)] animate-pulse" />
          </div>

          <div className="relative z-10 w-full flex flex-col items-center">
            {/* Connection Quality */}
            <div className="flex items-center gap-2 mb-6">
              <Signal className={`w-5 h-5 ${getQualityColor()}`} />
              <span className="text-sm text-gray-400">
                {mediaState.connection.quality === 'excellent'
                  ? 'Mükemmel'
                  : mediaState.connection.quality === 'good'
                  ? 'İyi'
                  : mediaState.connection.quality === 'fair'
                  ? 'Orta'
                  : 'Zayıf'}{' '}
                ({mediaState.connection.latency}ms)
              </span>
            </div>

            {/* Caller Info */}
            <div className="text-center mb-6">
              {call.caller.avatar ? (
                <img
                  src={call.caller.avatar}
                  alt={call.caller.name}
                  className="w-24 h-24 rounded-full border-4 border-white/20 shadow-xl mx-auto mb-4"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mx-auto mb-4 border-4 border-white/20 shadow-xl">
                  <span className="text-3xl font-bold text-white">
                    {call.caller.name.charAt(0).toUpperCase()}
                  </span>
                </div>
              )}

              <h2 className="text-2xl font-bold text-white mb-1">{call.caller.name}</h2>
              {call.caller.phoneNumber && (
                <p className="text-lg text-gray-400">{call.caller.phoneNumber}</p>
              )}

              {/* Call Status */}
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/10 backdrop-blur-sm rounded-full mt-3">
                {isOnHold ? (
                  <>
                    <Pause className="w-4 h-4 text-yellow-400 animate-pulse" />
                    <span className="text-yellow-400 text-sm font-medium">Beklemede</span>
                  </>
                ) : (
                  <>
                    <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-white text-sm font-medium">Bağlı</span>
                  </>
                )}
              </div>
            </div>

            {/* Call Duration */}
            <div className="text-center mb-8">
              <p className="text-4xl font-mono font-bold text-white">{formatDuration(callDuration)}</p>
            </div>

            {/* Recording Status */}
            {mediaState.recording.isRecording && (
              <div className="flex items-center gap-2 mb-4 px-3 py-2 bg-red-500/20 backdrop-blur-sm rounded-lg border border-red-500/50">
                <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm text-red-300 font-medium">Kayıt Ediliyor</span>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="relative z-10 w-full">
            {/* Main Controls */}
            <div className="grid grid-cols-3 gap-3 mb-4">
              {/* Mute */}
              <button
                onClick={onToggleMute}
                className={`p-5 rounded-xl transition-all flex flex-col items-center gap-1.5 ${
                  mediaState.audio.muted
                    ? 'bg-red-500 hover:bg-red-600 text-white'
                    : 'bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm'
                }`}
              >
                {mediaState.audio.muted ? <MicOff className="w-7 h-7" /> : <Mic className="w-7 h-7" />}
                <span className="text-xs font-medium">{mediaState.audio.muted ? 'Kapalı' : 'Mikrofon'}</span>
              </button>

              {/* Hold/Resume */}
              <button
                onClick={isOnHold ? onResume : onHold}
                className="p-5 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl transition-all flex flex-col items-center gap-1.5 text-white"
              >
                {isOnHold ? <Play className="w-7 h-7" /> : <Pause className="w-7 h-7" />}
                <span className="text-xs font-medium">{isOnHold ? 'Devam' : 'Beklet'}</span>
              </button>

              {/* Speaker */}
              <button
                onClick={onToggleSpeaker}
                className={`p-5 rounded-xl transition-all flex flex-col items-center gap-1.5 ${
                  mediaState.audio.volume > 0
                    ? 'bg-blue-500 hover:bg-blue-600 text-white'
                    : 'bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm'
                }`}
              >
                {mediaState.audio.volume > 0 ? (
                  <Volume2 className="w-7 h-7" />
                ) : (
                  <VolumeX className="w-7 h-7" />
                )}
                <span className="text-xs font-medium">Hoparlör</span>
              </button>
            </div>

            {/* Secondary Controls */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              {/* Transfer */}
              <button
                onClick={onTransfer}
                className="p-3 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl transition-all flex items-center justify-center gap-2 text-white"
              >
                <Users className="w-5 h-5" />
                <span className="text-sm">Transfer</span>
              </button>

              {/* Notes */}
              <button className="p-3 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl transition-all flex items-center justify-center gap-2 text-white">
                <FileText className="w-5 h-5" />
                <span className="text-sm">Not Ekle</span>
              </button>
            </div>

            {/* End Call Button */}
            <button
              onClick={onEndCall}
              className="w-full py-4 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-xl"
            >
              <PhoneOff className="w-6 h-6" />
              <span>Aramayı Sonlandır</span>
            </button>
          </div>
        </div>

        {/* Sağ Taraf - Mesaj Geçmişi */}
        <div className="w-1/2 flex flex-col bg-gray-50 dark:bg-slate-900">
          {/* Header */}
          <div className="p-4 border-b border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">Konuşma Geçmişi</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Müşteriyle önceki mesajlar
                  </p>
                </div>
              </div>
              <button
                onClick={onEndCall}
                className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${
                    message.sender === 'user'
                      ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-gray-100'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  <p
                    className={`text-xs mt-1 ${
                      message.sender === 'user'
                        ? 'text-gray-500 dark:text-gray-400'
                        : 'text-blue-200'
                    }`}
                  >
                    {formatMessageTime(message.timestamp)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Message Input */}
          <div className="p-4 border-t border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800">
            <div className="flex gap-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Mesaj yazın..."
                className="flex-1 px-4 py-2.5 bg-gray-100 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100 text-sm"
              />
              <button
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 dark:disabled:bg-slate-600 text-white rounded-xl transition-colors disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActiveCallScreen;
