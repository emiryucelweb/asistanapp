/**
 * Quick Reply Templates Component
 * Predefined message templates for quick responses
 */
import React, { useState } from 'react';
import { MessageSquare, Plus, Edit2, Trash2, Search, X, Check } from 'lucide-react';

interface Template {
  id: string;
  title: string;
  content: string;
  category: 'greeting' | 'appointment' | 'product' | 'support' | 'closing' | 'custom';
  shortcut?: string;
}

interface QuickReplyTemplatesProps {
  onSelectTemplate: (content: string) => void;
}

const QuickReplyTemplates: React.FC<QuickReplyTemplatesProps> = ({ onSelectTemplate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const defaultTemplates: Template[] = [
    {
      id: '1',
      title: 'Karşılama Mesajı',
      content: 'Merhaba! Size nasıl yardımcı olabilirim?',
      category: 'greeting',
      shortcut: '/hi',
    },
    {
      id: '2',
      title: 'Randevu Teklifi',
      content: 'Randevu oluşturmak ister misiniz? Size uygun tarih ve saati bildirebilir misiniz?',
      category: 'appointment',
      shortcut: '/appointment',
    },
    {
      id: '3',
      title: 'Ürün Bilgisi',
      content: 'Bu ürün hakkında detaylı bilgi almak için lütfen ürün kodunu paylaşın.',
      category: 'product',
      shortcut: '/product',
    },
    {
      id: '4',
      title: 'Destek Talebi',
      content: 'Talebinizi aldık. Ekibimiz en kısa sürede sizinle iletişime geçecek.',
      category: 'support',
      shortcut: '/support',
    },
    {
      id: '5',
      title: 'Teşekkür & Kapanış',
      content: 'Bize ulaştığınız için teşekkür ederiz. İyi günler dileriz!',
      category: 'closing',
      shortcut: '/bye',
    },
    {
      id: '6',
      title: 'Fiyat Bilgisi',
      content: 'Fiyat bilgisi için lütfen bize ürün kodunu iletin. En güncel fiyatları size ileteceğiz.',
      category: 'product',
      shortcut: '/price',
    },
    {
      id: '7',
      title: 'Çalışma Saatleri',
      content: 'Çalışma saatlerimiz: Pazartesi-Cuma 09:00-18:00, Cumartesi 10:00-16:00',
      category: 'support',
      shortcut: '/hours',
    },
    {
      id: '8',
      title: 'Adres Bilgisi',
      content: 'Mağaza adresimiz: İstanbul, Türkiye. Detaylı adres için web sitemizi ziyaret edebilirsiniz.',
      category: 'support',
      shortcut: '/address',
    },
  ];

  const categories = [
    { value: 'all', label: 'Tümü', icon: MessageSquare },
    { value: 'greeting', label: 'Karşılama' },
    { value: 'appointment', label: 'Randevu' },
    { value: 'product', label: 'Ürün' },
    { value: 'support', label: 'Destek' },
    { value: 'closing', label: 'Kapanış' },
  ];

  const filteredTemplates = defaultTemplates.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.shortcut?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handleSelectTemplate = (template: Template) => {
    onSelectTemplate(template.content);
    setIsOpen(false);
    setSearchQuery('');
  };

  const getCategoryColor = (category: Template['category']) => {
    const colors = {
      greeting: 'bg-green-100 text-green-700',
      appointment: 'bg-blue-100 text-blue-700',
      product: 'bg-purple-100 text-purple-700',
      support: 'bg-orange-100 text-orange-700',
      closing: 'bg-gray-100 text-gray-700',
      custom: 'bg-pink-100 text-pink-700',
    };
    return colors[category];
  };

  return (
    <div className="relative">
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2.5 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
        title="Hızlı Yanıt Şablonları"
      >
        <MessageSquare className="w-5 h-5" />
      </button>

      {/* Templates Dropdown */}
      {isOpen && (
        <>
          <div className="absolute bottom-full right-0 mb-2 w-96 bg-white border border-gray-200 rounded-xl shadow-lg z-50 flex flex-col max-h-[500px]">
            {/* Header */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-orange-500" />
                  Hızlı Yanıt Şablonları
                </h3>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Şablon ara..."
                  className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-colors"
                />
              </div>
            </div>

            {/* Categories */}
            <div className="px-4 py-3 border-b border-gray-200 flex gap-2 overflow-x-auto">
              {categories.map(cat => (
                <button
                  key={cat.value}
                  onClick={() => setSelectedCategory(cat.value)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === cat.value
                      ? 'bg-orange-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Templates List */}
            <div className="flex-1 overflow-y-auto">
              {filteredTemplates.length > 0 ? (
                <div className="p-2">
                  {filteredTemplates.map(template => (
                    <button
                      key={template.id}
                      onClick={() => handleSelectTemplate(template)}
                      className="w-full text-left p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h4 className="font-semibold text-gray-900 text-sm">
                          {template.title}
                        </h4>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(template.category)}`}>
                          {categories.find(c => c.value === template.category)?.label}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                        {template.content}
                      </p>
                      {template.shortcut && (
                        <div className="flex items-center gap-1">
                          <kbd className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded border border-gray-300 font-mono">
                            {template.shortcut}
                          </kbd>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600">Şablon bulunamadı</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Farklı bir arama yapın
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-gray-200 bg-gray-50">
              <button
                onClick={() => {
                  alert('Yeni şablon ekleme özelliği yakında!');
                }}
                className="w-full px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Yeni Şablon Ekle
              </button>
            </div>
          </div>

          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
        </>
      )}
    </div>
  );
};

export default QuickReplyTemplates;

