/**
 * Templates Components Index
 */
export { default as QuickReplyTemplates } from './QuickReplyTemplates';

