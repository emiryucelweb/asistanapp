import React, { useState } from 'react';
import { X, Building2, Mail, Globe, CreditCard, MapPin, User } from 'lucide-react';
import { TenantSubscription } from '../../types';

interface CreateTenantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: TenantFormData) => void;
}

export interface TenantFormData {
  // Company Info
  companyName: string;
  companyEmail: string;
  companyPhone: string;
  website?: string;
  
  // Contact Person
  contactFirstName: string;
  contactLastName: string;
  contactEmail: string;
  contactPhone: string;
  
  // Billing Address
  billingCompany: string;
  billingStreet: string;
  billingCity: string;
  billingState: string;
  billingPostalCode: string;
  billingCountry: string;
  taxId?: string;
  
  // Subscription
  plan: TenantSubscription['plan'];
  dataResidency: 'eu' | 'us' | 'tr';
  
  // Features
  voiceEnabled: boolean;
  multiChannel: boolean;
  analytics: boolean;
  customIntegrations: boolean;
}

const CreateTenantModal: React.FC<CreateTenantModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<TenantFormData>({
    companyName: '',
    companyEmail: '',
    companyPhone: '',
    website: '',
    contactFirstName: '',
    contactLastName: '',
    contactEmail: '',
    contactPhone: '',
    billingCompany: '',
    billingStreet: '',
    billingCity: '',
    billingState: '',
    billingPostalCode: '',
    billingCountry: 'TR',
    taxId: '',
    plan: 'professional',
    dataResidency: 'tr',
    voiceEnabled: true,
    multiChannel: true,
    analytics: true,
    customIntegrations: false,
  });

  const [errors, setErrors] = useState<Partial<Record<keyof TenantFormData, string>>>({});

  if (!isOpen) return null;

  const validateStep = (currentStep: number): boolean => {
    const newErrors: Partial<Record<keyof TenantFormData, string>> = {};

    if (currentStep === 1) {
      if (!formData.companyName.trim()) newErrors.companyName = 'Şirket adı gerekli';
      if (!formData.companyEmail.trim()) newErrors.companyEmail = 'E-posta gerekli';
      if (!formData.companyPhone.trim()) newErrors.companyPhone = 'Telefon gerekli';
    }

    if (currentStep === 2) {
      if (!formData.contactFirstName.trim()) newErrors.contactFirstName = 'Ad gerekli';
      if (!formData.contactLastName.trim()) newErrors.contactLastName = 'Soyad gerekli';
      if (!formData.contactEmail.trim()) newErrors.contactEmail = 'E-posta gerekli';
    }

    if (currentStep === 3) {
      if (!formData.billingCompany.trim()) newErrors.billingCompany = 'Şirket adı gerekli';
      if (!formData.billingStreet.trim()) newErrors.billingStreet = 'Adres gerekli';
      if (!formData.billingCity.trim()) newErrors.billingCity = 'Şehir gerekli';
      if (!formData.billingPostalCode.trim()) newErrors.billingPostalCode = 'Posta kodu gerekli';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    setStep(step - 1);
    setErrors({});
  };

  const handleSubmit = () => {
    if (validateStep(step)) {
      onSubmit(formData);
      onClose();
    }
  };

  const handleChange = (field: keyof TenantFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-800 rounded-lg max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-slate-700">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              Yeni Firma Ekle
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Adım {step} / 4
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="px-6 pt-4">
          <div className="flex items-center gap-2">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`flex-1 h-2 rounded-full transition-colors ${
                  s <= step ? 'bg-blue-600' : 'bg-gray-200 dark:bg-slate-700'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Step 1: Company Information */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Building2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Şirket Bilgileri
                </h3>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Şirket Adı *
                </label>
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => handleChange('companyName', e.target.value)}
                  className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                    errors.companyName ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                  }`}
                  placeholder="Acme E-commerce"
                />
                {errors.companyName && (
                  <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.companyName}</p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    E-posta *
                  </label>
                  <input
                    type="email"
                    value={formData.companyEmail}
                    onChange={(e) => handleChange('companyEmail', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.companyEmail ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="info@acme.com"
                  />
                  {errors.companyEmail && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.companyEmail}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Telefon *
                  </label>
                  <input
                    type="tel"
                    value={formData.companyPhone}
                    onChange={(e) => handleChange('companyPhone', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.companyPhone ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="+90 555 123 4567"
                  />
                  {errors.companyPhone && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.companyPhone}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Website
                </label>
                <input
                  type="url"
                  value={formData.website}
                  onChange={(e) => handleChange('website', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                  placeholder="https://acme.com"
                />
              </div>
            </div>
          )}

          {/* Step 2: Contact Person */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <User className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  İletişim Kişisi
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Ad *
                  </label>
                  <input
                    type="text"
                    value={formData.contactFirstName}
                    onChange={(e) => handleChange('contactFirstName', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.contactFirstName ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="Ahmet"
                  />
                  {errors.contactFirstName && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.contactFirstName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Soyad *
                  </label>
                  <input
                    type="text"
                    value={formData.contactLastName}
                    onChange={(e) => handleChange('contactLastName', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.contactLastName ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="Yılmaz"
                  />
                  {errors.contactLastName && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.contactLastName}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    E-posta *
                  </label>
                  <input
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => handleChange('contactEmail', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.contactEmail ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="ahmet@acme.com"
                  />
                  {errors.contactEmail && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.contactEmail}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Telefon
                  </label>
                  <input
                    type="tel"
                    value={formData.contactPhone}
                    onChange={(e) => handleChange('contactPhone', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                    placeholder="+90 555 123 4567"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Billing Address */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Fatura Adresi
                </h3>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Şirket Ünvanı *
                </label>
                <input
                  type="text"
                  value={formData.billingCompany}
                  onChange={(e) => handleChange('billingCompany', e.target.value)}
                  className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                    errors.billingCompany ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                  }`}
                  placeholder="Acme E-commerce A.Ş."
                />
                {errors.billingCompany && (
                  <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.billingCompany}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Adres *
                </label>
                <input
                  type="text"
                  value={formData.billingStreet}
                  onChange={(e) => handleChange('billingStreet', e.target.value)}
                  className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                    errors.billingStreet ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                  }`}
                  placeholder="Atatürk Cad. No:123"
                />
                {errors.billingStreet && (
                  <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.billingStreet}</p>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Şehir *
                  </label>
                  <input
                    type="text"
                    value={formData.billingCity}
                    onChange={(e) => handleChange('billingCity', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.billingCity ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="İstanbul"
                  />
                  {errors.billingCity && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.billingCity}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    İlçe/Bölge
                  </label>
                  <input
                    type="text"
                    value={formData.billingState}
                    onChange={(e) => handleChange('billingState', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                    placeholder="Kadıköy"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Posta Kodu *
                  </label>
                  <input
                    type="text"
                    value={formData.billingPostalCode}
                    onChange={(e) => handleChange('billingPostalCode', e.target.value)}
                    className={`w-full px-4 py-2 border rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent ${
                      errors.billingPostalCode ? 'border-red-500' : 'border-gray-300 dark:border-slate-600'
                    }`}
                    placeholder="34000"
                  />
                  {errors.billingPostalCode && (
                    <p className="text-xs text-red-600 dark:text-red-400 mt-1">{errors.billingPostalCode}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Ülke
                  </label>
                  <select
                    value={formData.billingCountry}
                    onChange={(e) => handleChange('billingCountry', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                  >
                    <option value="TR">Türkiye</option>
                    <option value="US">Amerika Birleşik Devletleri</option>
                    <option value="GB">Birleşik Krallık</option>
                    <option value="DE">Almanya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Vergi Numarası
                </label>
                <input
                  type="text"
                  value={formData.taxId}
                  onChange={(e) => handleChange('taxId', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                  placeholder="1234567890"
                />
              </div>
            </div>
          )}

          {/* Step 4: Subscription & Features */}
          {step === 4 && (
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-4">
                <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  Abonelik ve Özellikler
                </h3>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Plan Seçimi
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { value: 'starter', label: 'Başlangıç', price: '$499/ay' },
                    { value: 'professional', label: 'Profesyonel', price: '$999/ay' },
                    { value: 'enterprise', label: 'Kurumsal', price: '$2,499/ay' },
                    { value: 'free', label: 'Deneme', price: '14 gün ücretsiz' },
                  ].map((plan) => (
                    <button
                      key={plan.value}
                      onClick={() => handleChange('plan', plan.value)}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        formData.plan === plan.value
                          ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20'
                          : 'border-gray-300 dark:border-slate-600 hover:border-blue-400'
                      }`}
                    >
                      <div className="font-semibold text-gray-900 dark:text-gray-100">{plan.label}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">{plan.price}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Veri Konumu
                </label>
                <select
                  value={formData.dataResidency}
                  onChange={(e) => handleChange('dataResidency', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                >
                  <option value="tr">Türkiye</option>
                  <option value="eu">Avrupa (EU)</option>
                  <option value="us">Amerika (US)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Özellikler
                </label>
                <div className="space-y-3">
                  {[
                    { key: 'voiceEnabled', label: 'Sesli Asistan', description: 'Telefon ve sesli mesaj desteği' },
                    { key: 'multiChannel', label: 'Çoklu Kanal', description: 'WhatsApp, Instagram, Facebook, vb.' },
                    { key: 'analytics', label: 'Gelişmiş Analitik', description: 'Detaylı raporlar ve dashboard' },
                    { key: 'customIntegrations', label: 'Özel Entegrasyonlar', description: 'API ve webhook desteği' },
                  ].map((feature) => (
                    <label
                      key={feature.key}
                      className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700/50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={formData[feature.key as keyof TenantFormData] as boolean}
                        onChange={(e) => handleChange(feature.key as keyof TenantFormData, e.target.checked)}
                        className="mt-1 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                          {feature.label}
                        </div>
                        <div className="text-xs text-gray-600 dark:text-gray-400">
                          {feature.description}
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-slate-700">
          <button
            onClick={step === 1 ? onClose : handleBack}
            className="px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-700 text-gray-700 dark:text-gray-300 transition-colors"
          >
            {step === 1 ? 'İptal' : 'Geri'}
          </button>
          <button
            onClick={step === 4 ? handleSubmit : handleNext}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            {step === 4 ? 'Firma Oluştur' : 'Devam'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateTenantModal;



