/**
 * Form Components Index
 */
export { default as ValidatedProfileForm } from './ValidatedProfileForm';

