/**
 * Validated Profile Form Example
 * Shows how to use Zod + React Hook Form
 */
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Save } from 'lucide-react';
import toast from 'react-hot-toast';
import { profileSchema, type ProfileFormData } from '../../lib/validations/settings.schemas';

interface ValidatedProfileFormProps {
  initialData?: Partial<ProfileFormData>;
  onSubmit: (data: ProfileFormData) => Promise<void>;
}

const ValidatedProfileForm: React.FC<ValidatedProfileFormProps> = ({
  initialData,
  onSubmit,
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: initialData || {
      name: '',
      email: '',
      phone: '',
      title: '',
    },
  });

  const onSubmitHandler = async (data: ProfileFormData) => {
    try {
      await onSubmit(data);
      toast.success('Profil başarıyla güncellendi!');
    } catch (error) {
      toast.error('Bir hata oluştu. Lütfen tekrar deneyin.');
      console.error('Form submit error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmitHandler)} className="space-y-6">
      {/* Name Field */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Ad Soyad <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          {...register('name')}
          className={`w-full px-4 py-2.5 border ${
            errors.name ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors`}
          placeholder="Adınız Soyadınız"
        />
        {errors.name && (
          <p className="mt-1.5 text-sm text-red-600 flex items-center gap-1">
            <span>⚠️</span> {errors.name.message}
          </p>
        )}
      </div>

      {/* Email Field */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          E-posta <span className="text-red-500">*</span>
        </label>
        <input
          type="email"
          {...register('email')}
          className={`w-full px-4 py-2.5 border ${
            errors.email ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors`}
          placeholder="ornek@asistanapp.com"
        />
        {errors.email && (
          <p className="mt-1.5 text-sm text-red-600 flex items-center gap-1">
            <span>⚠️</span> {errors.email.message}
          </p>
        )}
      </div>

      {/* Phone Field (Optional) */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Telefon (Opsiyonel)
        </label>
        <input
          type="tel"
          {...register('phone')}
          className={`w-full px-4 py-2.5 border ${
            errors.phone ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors`}
          placeholder="5551234567"
        />
        {errors.phone && (
          <p className="mt-1.5 text-sm text-red-600 flex items-center gap-1">
            <span>⚠️</span> {errors.phone.message}
          </p>
        )}
      </div>

      {/* Title Field (Optional) */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Unvan (Opsiyonel)
        </label>
        <input
          type="text"
          {...register('title')}
          className={`w-full px-4 py-2.5 border ${
            errors.title ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors`}
          placeholder="Örn: CEO, Müdür, vb."
        />
        {errors.title && (
          <p className="mt-1.5 text-sm text-red-600 flex items-center gap-1">
            <span>⚠️</span> {errors.title.message}
          </p>
        )}
      </div>

      {/* Submit Button */}
      <div className="flex gap-3 pt-4">
        <button
          type="submit"
          disabled={isSubmitting}
          className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Kaydediliyor...
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Kaydet
            </>
          )}
        </button>
      </div>
    </form>
  );
};

export default ValidatedProfileForm;

