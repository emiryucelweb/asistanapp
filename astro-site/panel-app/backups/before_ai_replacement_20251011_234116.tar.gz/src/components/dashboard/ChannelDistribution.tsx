/**
 * Channel Distribution - Horizontal Bar Chart
 * Now using Recharts for dynamic visualization
 */
import React, { useMemo } from 'react';
import BarChartComponent from '../charts/BarChartComponent';

interface ChannelDistributionProps {
  dateRange?: '24h' | '7d' | '30d' | '1y' | 'custom';
}

const ChannelDistribution: React.FC<ChannelDistributionProps> = ({ dateRange = '7d' }) => {
  const chartData = useMemo(() => {
    const multiplier = dateRange === '24h' ? 0.15 : dateRange === '7d' ? 1 : dateRange === '30d' ? 4 : 12;
    
    return [
      { name: 'WhatsApp', value: Math.round(450 * multiplier), color: '#10b981' },
      { name: 'Instagram', value: Math.round(380 * multiplier), color: '#ec4899' },
      { name: 'Facebook', value: Math.round(320 * multiplier), color: '#3b82f6' },
      { name: 'Web Widget', value: Math.round(280 * multiplier), color: '#8b5cf6' },
      { name: 'Telefon', value: Math.round(220 * multiplier), color: '#f59e0b' },
    ];
  }, [dateRange]);

  const total = chartData.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="flex min-w-72 flex-1 flex-col gap-2 rounded-xl border border-[#d0d9e7] dark:border-slate-700 p-6 hover:shadow-md transition-shadow bg-white dark:bg-slate-800">
      <p className="text-[#0e131b] dark:text-gray-100 text-base font-medium leading-normal">Kanal Dağılımı</p>
      <p className="text-[#0e131b] dark:text-gray-100 tracking-light text-[32px] font-bold leading-tight truncate">
        {total.toLocaleString('tr-TR')}
      </p>
      <div className="flex gap-1">
        <p className="text-[#4d6a99] dark:text-gray-400 text-base font-normal leading-normal">Toplam Konuşma</p>
        <p className="text-[#07883b] dark:text-green-400 text-base font-medium leading-normal">+12%</p>
      </div>
      
      <BarChartComponent
        data={chartData}
        title=""
        layout="horizontal"
        showGrid={true}
        height={250}
      />
    </div>
  );
};

export default ChannelDistribution;
