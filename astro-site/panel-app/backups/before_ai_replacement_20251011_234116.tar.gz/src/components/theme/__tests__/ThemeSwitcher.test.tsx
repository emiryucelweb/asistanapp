/**
 * ThemeSwitcher Component Tests
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import ThemeSwitcher from '../ThemeSwitcher';
import { useThemeStore } from '../../../stores/theme-store';

describe('ThemeSwitcher', () => {
  beforeEach(() => {
    // Reset theme store before each test
    useThemeStore.setState({ theme: 'light' });
  });

  it('renders correctly', () => {
    render(<ThemeSwitcher />);
    const button = screen.getByRole('switch');
    expect(button).toBeInTheDocument();
  });

  it('shows correct icon for light theme', () => {
    render(<ThemeSwitcher />);
    const button = screen.getByLabelText('Koyu Temaya Geç');
    expect(button).toBeInTheDocument();
  });

  it('toggles theme on click', () => {
    render(<ThemeSwitcher />);
    const button = screen.getByRole('switch');
    
    // Initial state: light
    expect(useThemeStore.getState().theme).toBe('light');
    
    // Click to toggle
    fireEvent.click(button);
    
    // Should be dark now
    expect(useThemeStore.getState().theme).toBe('dark');
  });

  it('has correct ARIA attributes', () => {
    render(<ThemeSwitcher />);
    const button = screen.getByRole('switch');
    
    expect(button).toHaveAttribute('aria-label');
    expect(button).toHaveAttribute('aria-pressed');
  });
});


