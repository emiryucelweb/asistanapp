/**
 * Agent AI Chat Modal - Çalışanlar için AI Asistan Popup
 */
import React, { useState } from 'react';
import { X, Send, Bot, TrendingUp, Users, MessageSquare, Clock, AlertCircle } from 'lucide-react';

interface AgentAIChatModalProps {
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const AgentAIChatModal: React.FC<AgentAIChatModalProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Merhaba! Size nasıl yardımcı olabilirim? Müşteri durumları, takım aktiviteleri veya performans metrikleri hakkında bilgi alabilirim.',
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const suggestions = [
    { icon: Users, label: 'Bekleyen müşteriler', query: 'Şu anda bekleyen müşteriler kimler?' },
    { icon: TrendingUp, label: 'Günlük performans', query: 'Bugünkü performansım nasıl?' },
    { icon: MessageSquare, label: 'Aktif konuşmalar', query: 'Kaç aktif konuşmam var?' },
    { icon: Clock, label: 'Ortalama yanıt süresi', query: 'Ortalama yanıt sürem ne kadar?' },
  ];

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Simüle edilmiş AI yanıtı
    setTimeout(() => {
      const aiResponse = getAIResponse(inputValue);
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1000);
  };

  const handleSuggestionClick = (query: string) => {
    setInputValue(query);
  };

  const getAIResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes('bekleyen') || lowerQuery.includes('kuyruk')) {
      return '📊 **Bekleyen Müşteriler:**\n\n• Ahmet Yılmaz - 5 dakikadır bekliyor\n• Ayşe Demir - 3 dakikadır bekliyor\n• Mehmet Kaya - 1 dakikadır bekliyor\n\nToplam 3 müşteri beklemede.';
    }

    if (lowerQuery.includes('performans') || lowerQuery.includes('bugün')) {
      return '📈 **Bugünkü Performansınız:**\n\n• Toplam Görüşme: 12\n• Çözülen: 9 (75%)\n• Ortalama Yanıt: 2.5 dk\n• Müşteri Memnuniyeti: 4.5/5\n\nHarika gidiyorsunuz! 💪';
    }

    if (lowerQuery.includes('aktif') || lowerQuery.includes('konuşma')) {
      return '💬 **Aktif Konuşmalarınız:**\n\n• 2 konuşma devam ediyor\n• 1 konuşma yanıt bekliyor\n• 0 askıdaki konuşma\n\nToplam 3 aktif görüşme.';
    }

    if (lowerQuery.includes('yanıt') || lowerQuery.includes('süre')) {
      return '⏱️ **Yanıt Süre Metrikleri:**\n\n• Ortalama İlk Yanıt: 1.8 dk\n• Ortalama Çözüm: 12 dk\n• En Hızlı: 30 sn\n• En Yavaş: 5 dk\n\nHedef sürenin altındasınız! ✅';
    }

    if (lowerQuery.includes('takım') || lowerQuery.includes('ekip')) {
      return '👥 **Takım Durumu:**\n\n• Aktif Ajanlar: 5/8\n• Mola: 2/8\n• Çevrimdışı: 1/8\n• Toplam Aktif Konuşma: 18\n\nTakım yükü: Orta';
    }

    if (lowerQuery.includes('müşteri') && lowerQuery.includes('detay')) {
      return '👤 **Müşteri Bilgileri:**\n\nLütfen müşteri adı veya ID\'sini belirtin. Örnek: "Ahmet Yılmaz müşterisinin durumu nedir?"';
    }

    return '🤔 **Anladım!**\n\nŞu konularda size yardımcı olabilirim:\n\n• Bekleyen ve aktif müşteriler\n• Günlük performans metrikleri\n• Takım durumu ve yoğunluk\n• Ortalama yanıt süreleri\n• Müşteri bilgileri\n\nBaşka ne öğrenmek istersiniz?';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl h-[600px] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-slate-700 bg-gradient-to-r from-blue-500 to-purple-600">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white dark:bg-slate-700 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">AI Asistan</h2>
              <p className="text-xs text-blue-100">Operasyonel Destek</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 p-3 m-4">
          <div className="flex gap-2">
            <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
            <div>
              <p className="text-sm text-blue-800 dark:text-blue-300 font-medium">
                Operasyonel Bilgi Asistanı
              </p>
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                Bu asistan müşteri durumları, takım aktiviteleri ve performans metrikleri hakkında bilgi sağlar.
              </p>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 dark:bg-slate-700 text-gray-900 dark:text-gray-100'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                <p
                  className={`text-xs mt-2 ${
                    message.role === 'user' ? 'text-blue-200' : 'text-gray-500 dark:text-gray-400'
                  }`}
                >
                  {message.timestamp.toLocaleTimeString('tr-TR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 dark:bg-slate-700 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick Suggestions */}
        {messages.length === 1 && (
          <div className="px-4 pb-2">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Hızlı Sorular:</p>
            <div className="grid grid-cols-2 gap-2">
              {suggestions.map((suggestion, index) => {
                const Icon = suggestion.icon;
                return (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion.query)}
                    className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-slate-700 hover:bg-gray-100 dark:hover:bg-slate-600 rounded-lg transition-colors text-left"
                  >
                    <Icon className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                    <span className="text-xs text-gray-700 dark:text-gray-300">
                      {suggestion.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-gray-200 dark:border-slate-700">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Bir şey sorun..."
              className="flex-1 px-4 py-3 bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100 text-sm"
              disabled={isLoading}
            />
            <button
              onClick={handleSend}
              disabled={!inputValue.trim() || isLoading}
              className="px-4 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 dark:disabled:bg-slate-600 text-white rounded-xl transition-colors disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentAIChatModal;

