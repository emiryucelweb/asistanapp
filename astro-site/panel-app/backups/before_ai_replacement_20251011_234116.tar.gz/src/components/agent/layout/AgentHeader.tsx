/**
 * Agent Header - Çalışan Paneli Header
 */
import React, { useState } from 'react';
import { Bell, ChevronDown } from 'lucide-react';
import ThemeSwitcher from '../../theme/ThemeSwitcher';
import NotificationCenter from '../notifications/NotificationCenter';

const AgentHeader: React.FC = () => {
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [status, setStatus] = useState<'online' | 'busy' | 'offline'>('online');
  const [showNotifications, setShowNotifications] = useState(false);

  const statusConfig = {
    online: { label: 'Çevrimiçi', color: 'bg-green-500', textColor: 'text-green-700 dark:text-green-400' },
    busy: { label: 'Meşgul', color: 'bg-yellow-500', textColor: 'text-yellow-700 dark:text-yellow-400' },
    offline: { label: 'Çevrimdışı', color: 'bg-gray-500', textColor: 'text-gray-700 dark:text-gray-400' },
  };

  const currentStatus = statusConfig[status];

  return (
    <header className="flex h-18 shrink-0 items-center justify-between border-b border-solid border-b-[#e7ecf3] dark:border-b-slate-700 bg-white dark:bg-slate-800 px-10 py-3 transition-colors">
      <div className="flex items-center gap-4">
        <h2 className="text-[#0e131b] dark:text-gray-100 text-lg font-bold leading-tight tracking-[-0.015em]">
          Hoş Geldin! 👋
        </h2>
      </div>

      <div className="flex items-center gap-4">
        {/* Status Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowStatusMenu(!showStatusMenu)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
          >
            <div className={`w-2 h-2 rounded-full ${currentStatus.color}`} />
            <span className={`text-sm font-medium ${currentStatus.textColor}`}>
              {currentStatus.label}
            </span>
            <ChevronDown className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>

          {showStatusMenu && (
            <>
              <div 
                className="fixed inset-0 z-10" 
                onClick={() => setShowStatusMenu(false)}
              />
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg overflow-hidden z-20">
                {Object.entries(statusConfig).map(([key, config]) => (
                  <button
                    key={key}
                    onClick={() => {
                      setStatus(key as typeof status);
                      setShowStatusMenu(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left"
                  >
                    <div className={`w-2 h-2 rounded-full ${config.color}`} />
                    <span className={`text-sm font-medium ${config.textColor}`}>
                      {config.label}
                    </span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Notifications */}
        <button 
          onClick={() => setShowNotifications(true)}
          className="relative p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
        >
          <Bell className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
        </button>

        {/* Theme Switcher */}
        <ThemeSwitcher />

        {/* User Profile */}
        <div className="flex items-center gap-3 pl-3 border-l border-gray-200 dark:border-slate-700">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
            AY
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-medium text-gray-900 dark:text-gray-100">Ayşe Yılmaz</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">Destek Ekibi</p>
          </div>
        </div>
      </div>

      {/* Notification Center Modal */}
      {showNotifications && (
        <NotificationCenter onClose={() => setShowNotifications(false)} />
      )}
    </header>
  );
};

export default AgentHeader;

