/**
 * Agent Layout - Çalışan Paneli Ana Layout
 */
import React, { useState } from 'react';
import AgentSidebar from './AgentSidebar';
import AgentHeader from './AgentHeader';
import { Menu, X, Bell, ChevronDown } from 'lucide-react';
import ThemeSwitcher from '../../theme/ThemeSwitcher';
import NotificationCenter from '../notifications/NotificationCenter';
import AgentAIChatModal from '../ai/AgentAIChatModal';
import AgentIncomingCallAlert from '../../voice/AgentIncomingCallAlert';
import ActiveCallScreen from '../../voice/ActiveCallScreen';
import { VoiceCall, CallMediaState } from '../../../types';

interface AgentLayoutProps {
  children: React.ReactNode;
}

const AgentLayout: React.FC<AgentLayoutProps> = ({ children }) => {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [status, setStatus] = useState<'online' | 'busy' | 'offline'>('online');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [incomingCall, setIncomingCall] = useState<VoiceCall | null>(null);
  const [activeCall, setActiveCall] = useState<VoiceCall | null>(null);
  const [mediaState, setMediaState] = useState<CallMediaState>({
    audio: { muted: false, volume: 80 },
    recording: { isRecording: false },
    connection: { quality: 'excellent', latency: 45, packetLoss: 0.1 },
  });

  const statusConfig = {
    online: { label: 'Çevrimiçi', color: 'bg-green-500', textColor: 'text-green-700 dark:text-green-400' },
    busy: { label: 'Meşgul', color: 'bg-yellow-500', textColor: 'text-yellow-700 dark:text-yellow-400' },
    offline: { label: 'Çevrimdışı', color: 'bg-gray-500', textColor: 'text-gray-700 dark:text-gray-400' },
  };

  const currentStatus = statusConfig[status];

  return (
    <div 
      className="relative flex h-auto min-h-screen w-full flex-col bg-slate-50 dark:bg-slate-900 transition-colors duration-200" 
      style={{ fontFamily: 'Inter, "Noto Sans", sans-serif' }}
    >
      {/* Mobile Sidebar Overlay */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
      )}

      {/* Mobile Sidebar Drawer */}
      <div className={`
        fixed top-0 left-0 h-full w-72 z-50 transform transition-transform duration-300 lg:hidden
        ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="bg-white dark:bg-slate-800 h-full shadow-2xl overflow-y-auto">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-slate-700">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Menü</h2>
            <button
              onClick={() => setIsMobileSidebarOpen(false)}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
              aria-label="Close menu"
            >
              <X className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            </button>
          </div>
          <AgentSidebar 
            onItemClick={() => setIsMobileSidebarOpen(false)}
            onOpenAIChat={() => setShowAIChat(true)}
          />
        </div>
      </div>

      {/* Main Layout Container */}
      <div className="layout-container flex h-full grow flex-col">
        {/* Mobile Header with Full Features */}
        <div className="lg:hidden sticky top-0 z-30 bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between px-3 py-2.5">
            {/* Hamburger Menu */}
            <button
              onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
              aria-label="Toggle menu"
            >
              <Menu className="w-5 h-5 text-gray-900 dark:text-gray-100" />
            </button>

            {/* Center Logo */}
            <div className="flex items-center gap-2">
              <img src="/logo.svg" alt="AsistanApp" className="w-6 h-6" />
              <h1 className="text-sm font-bold text-gray-900 dark:text-gray-100">Agent Panel</h1>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center gap-1">
              {/* Status Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowStatusMenu(!showStatusMenu)}
                  className="flex items-center gap-1 px-2 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                  aria-label="Status"
                >
                  <div className={`w-2 h-2 rounded-full ${currentStatus.color}`} />
                  <ChevronDown className="w-3 h-3 text-gray-500 dark:text-gray-400" />
                </button>

                {showStatusMenu && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setShowStatusMenu(false)}
                    />
                    <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg shadow-lg overflow-hidden z-50">
                      {Object.entries(statusConfig).map(([key, config]) => (
                        <button
                          key={key}
                          onClick={() => {
                            setStatus(key as typeof status);
                            setShowStatusMenu(false);
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors text-left"
                        >
                          <div className={`w-2 h-2 rounded-full ${config.color}`} />
                          <span className={`text-xs font-medium ${config.textColor}`}>
                            {config.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Notifications */}
              <button 
                onClick={() => setShowNotifications(true)}
                className="relative p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
                aria-label="Notifications"
              >
                <Bell className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-red-500 rounded-full" />
              </button>

              {/* Theme Switcher */}
              <ThemeSwitcher />
            </div>
          </div>

          {/* Notification Center Modal */}
          {showNotifications && (
            <NotificationCenter onClose={() => setShowNotifications(false)} />
          )}
        </div>

        {/* Desktop Layout */}
        <div className="gap-1 px-2 sm:px-4 lg:px-6 flex flex-1 justify-center py-2 lg:py-5">
          {/* Desktop Sidebar - Hidden on mobile */}
          <div className="layout-content-container flex-col flex-shrink-0 hidden lg:flex">
            <AgentSidebar onOpenAIChat={() => setShowAIChat(true)} />
          </div>

          {/* Main Content - Full width on mobile, flex on desktop */}
          <div className="layout-content-container flex flex-col flex-1 min-w-0 w-full">
            {/* Desktop Header - Hidden on mobile */}
            <div className="hidden lg:block">
              <AgentHeader />
            </div>
            
            {/* Page Content */}
            <div className="flex-1">
              {children}
            </div>
          </div>
        </div>
      </div>

      {/* AI Chat Modal */}
      {showAIChat && <AgentAIChatModal onClose={() => setShowAIChat(false)} />}

      {/* Incoming Call Alert */}
      {incomingCall && !activeCall && (
        <AgentIncomingCallAlert
          call={incomingCall}
          onAccept={() => {
            setActiveCall(incomingCall);
            setIncomingCall(null);
          }}
          onReject={() => {
            setIncomingCall(null);
          }}
        />
      )}

      {/* Active Call Screen */}
      {activeCall && (
        <ActiveCallScreen
          call={activeCall}
          mediaState={mediaState}
          onToggleMute={() => {
            setMediaState((prev) => ({
              ...prev,
              audio: { ...prev.audio, muted: !prev.audio.muted },
            }));
          }}
          onToggleSpeaker={() => {
            setMediaState((prev) => ({
              ...prev,
              audio: { ...prev.audio, volume: prev.audio.volume > 0 ? 0 : 80 },
            }));
          }}
          onHold={() => {
            setActiveCall({ ...activeCall, status: 'on_hold' });
          }}
          onResume={() => {
            setActiveCall({ ...activeCall, status: 'connected' });
          }}
          onTransfer={() => {
            // TODO: Transfer modal
          }}
          onEndCall={() => {
            setActiveCall(null);
          }}
        />
      )}
    </div>
  );
};

export default AgentLayout;

