/**
 * Agent Sidebar - Çalışan Paneli Sidebar
 */
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, MessageCircle, MessageSquare, User, LogOut, Bot } from 'lucide-react';

interface AgentSidebarProps {
  onItemClick?: () => void;
  onOpenAIChat?: () => void;
}

const AgentSidebar: React.FC<AgentSidebarProps> = ({ onItemClick, onOpenAIChat }) => {
  const location = useLocation();

  const menuItems = [
    { icon: Home, label: 'Ana Sayfa', path: '/agent/dashboard', type: 'link' },
    { icon: MessageCircle, label: 'Konuşmalar', path: '/agent/conversations', type: 'link' },
    { icon: MessageSquare, label: 'Ekip Chat', path: '/agent/team/chat', type: 'link' },
    { icon: Bot, label: 'AI Asistan', badge: 'YENİ', type: 'button' },
    { icon: User, label: 'Profil', path: '/agent/profile', type: 'link' },
  ];

  const isActive = (path?: string) => path && location.pathname === path;

  return (
    <div className="flex h-full min-h-[700px] flex-col justify-between bg-slate-50 dark:bg-slate-900 p-4 w-80">
      {/* Logo */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.svg" alt="AsistanApp" className="w-8 h-8 flex-shrink-0" />
            <div>
              <h1 className="text-[#0e131b] dark:text-gray-100 text-base font-medium leading-normal">Agent Panel</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Destek Ekibi</p>
            </div>
          </div>
        </div>
        
        {/* Menu Items */}
        <div className="flex flex-col gap-2">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            
            if (item.type === 'button') {
              return (
                <button
                  key={`button-${index}`}
                  onClick={() => {
                    onOpenAIChat?.();
                    onItemClick?.();
                  }}
                  className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-colors hover:bg-[#e7ecf3]/50 dark:hover:bg-slate-700/50`}
                >
                  <Icon className="text-[#0e131b] dark:text-gray-100 flex-shrink-0" size={24} />
                  <div className="flex items-center gap-2 flex-1">
                    <p className="text-[#0e131b] dark:text-gray-100 text-sm font-medium leading-normal">{item.label}</p>
                    {(item as any).badge && (
                      <span className="px-1.5 py-0.5 bg-green-500 text-white text-[10px] font-bold rounded uppercase">
                        {(item as any).badge}
                      </span>
                    )}
                  </div>
                </button>
              );
            }
            
            return (
              <Link
                key={item.path}
                to={item.path!}
                onClick={onItemClick}
                className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-colors ${
                  active ? 'bg-[#e7ecf3] dark:bg-slate-700' : 'hover:bg-[#e7ecf3]/50 dark:hover:bg-slate-700/50'
                }`}
              >
                <Icon className="text-[#0e131b] dark:text-gray-100 flex-shrink-0" size={24} />
                <div className="flex items-center gap-2 flex-1">
                  <p className="text-[#0e131b] dark:text-gray-100 text-sm font-medium leading-normal">{item.label}</p>
                  {(item as any).badge && (
                    <span className="px-1.5 py-0.5 bg-green-500 text-white text-[10px] font-bold rounded uppercase">
                      {(item as any).badge}
                    </span>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={() => {
          // TODO: Implement logout
          window.location.href = '/login';
        }}
        className="flex items-center gap-3 px-3 py-2 rounded-xl transition-colors hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600 dark:text-red-400"
      >
        <LogOut size={24} />
        <p className="text-sm font-medium">Çıkış Yap</p>
      </button>
    </div>
  );
};

export default AgentSidebar;

