/**
 * Assignment Modal - Konuşma Atama Modalı
 */
import React, { useState } from 'react';
import { X, UserPlus, Users, Zap } from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  status: 'online' | 'busy' | 'offline';
  activeConversations: number;
  avatar?: string;
}

interface AssignmentModalProps {
  conversationId: string;
  currentAssignee?: string;
  onClose: () => void;
  onAssign: (agentId: string, mode: 'manual' | 'auto') => void;
}

const AssignmentModal: React.FC<AssignmentModalProps> = ({
  conversationId,
  currentAssignee,
  onClose,
  onAssign,
}) => {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);

  const agents: Agent[] = [
    { id: '1', name: 'Ayşe Yılmaz', status: 'online', activeConversations: 3 },
    { id: '2', name: 'Mehmet Demir', status: 'online', activeConversations: 5 },
    { id: '3', name: 'Zeynep Kaya', status: 'busy', activeConversations: 8 },
    { id: '4', name: 'Ali Öztürk', status: 'offline', activeConversations: 0 },
    { id: '5', name: 'Fatma Şahin', status: 'online', activeConversations: 2 },
  ];

  const statusConfig = {
    online: { label: 'Çevrimiçi', color: 'bg-green-500' },
    busy: { label: 'Meşgul', color: 'bg-yellow-500' },
    offline: { label: 'Çevrimdışı', color: 'bg-gray-500' },
  };

  const handleAutoAssign = () => {
    // En az konuşması olan online agent'ı bul
    const onlineAgents = agents.filter(a => a.status === 'online');
    if (onlineAgents.length > 0) {
      const bestAgent = onlineAgents.reduce((prev, current) => 
        prev.activeConversations < current.activeConversations ? prev : current
      );
      onAssign(bestAgent.id, 'auto');
      onClose();
    }
  };

  const handleManualAssign = () => {
    if (selectedAgent) {
      onAssign(selectedAgent, 'manual');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <UserPlus className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                  Konuşma Ata
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Bir çalışan seçin veya otomatik ata
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Auto Assign */}
          <button
            onClick={handleAutoAssign}
            className="w-full p-4 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white rounded-lg transition-all flex items-center justify-between group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center">
                <Zap className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">Otomatik Ata</h3>
                <p className="text-sm text-orange-100">En uygun çalışana otomatik ata</p>
              </div>
            </div>
            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
              →
            </div>
          </button>

          {/* Manual Assign */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3 flex items-center gap-2">
              <Users className="w-4 h-4" />
              Manuel Atama
            </h3>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {agents.map((agent) => (
                <button
                  key={agent.id}
                  onClick={() => setSelectedAgent(agent.id)}
                  disabled={agent.status === 'offline'}
                  className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                    selectedAgent === agent.id
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-slate-700 hover:border-gray-300 dark:hover:border-slate-600'
                  } ${
                    agent.status === 'offline'
                      ? 'opacity-50 cursor-not-allowed'
                      : 'cursor-pointer'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                        {agent.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-gray-100">
                          {agent.name}
                          {currentAssignee === agent.name && (
                            <span className="ml-2 text-xs text-blue-600 dark:text-blue-400">
                              (Mevcut)
                            </span>
                          )}
                        </h4>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex items-center gap-1">
                            <div className={`w-2 h-2 rounded-full ${statusConfig[agent.status].color}`} />
                            <span className="text-xs text-gray-600 dark:text-gray-400">
                              {statusConfig[agent.status].label}
                            </span>
                          </div>
                          <span className="text-xs text-gray-500 dark:text-gray-500">
                            •
                          </span>
                          <span className="text-xs text-gray-600 dark:text-gray-400">
                            {agent.activeConversations} aktif konuşma
                          </span>
                        </div>
                      </div>
                    </div>
                    {selectedAgent === agent.id && (
                      <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 dark:border-slate-700 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 dark:border-slate-600 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
          >
            İptal
          </button>
          <button
            onClick={handleManualAssign}
            disabled={!selectedAgent}
            className="px-6 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Ata
          </button>
        </div>
      </div>
    </div>
  );
};

export default AssignmentModal;

