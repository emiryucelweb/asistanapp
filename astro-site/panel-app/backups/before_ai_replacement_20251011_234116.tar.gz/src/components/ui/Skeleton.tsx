/**
 * Skeleton Component
 * Reusable loading skeleton with shimmer effect
 */
import React from 'react';
import { cn } from '../../lib/utils';

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'text' | 'circular' | 'rectangular' | 'rounded';
  width?: string | number;
  height?: string | number;
  animation?: 'pulse' | 'wave' | 'none';
}

const Skeleton: React.FC<SkeletonProps> = ({
  variant = 'rectangular',
  width,
  height,
  animation = 'pulse',
  className,
  ...props
}) => {
  const baseClasses = 'bg-gray-200';
  
  const variantClasses = {
    text: 'rounded h-4',
    circular: 'rounded-full',
    rectangular: 'rounded-none',
    rounded: 'rounded-lg',
  };

  const animationClasses = {
    pulse: 'animate-pulse',
    wave: 'animate-shimmer bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 bg-[length:200%_100%]',
    none: '',
  };

  return (
    <div
      className={cn(
        baseClasses,
        variantClasses[variant],
        animationClasses[animation],
        className
      )}
      style={{
        width: width || undefined,
        height: height || undefined,
      }}
      {...props}
    />
  );
};

/**
 * Text Skeleton - For single line text
 */
export const SkeletonText: React.FC<Omit<SkeletonProps, 'variant'>> = (props) => {
  return <Skeleton variant="text" {...props} />;
};

/**
 * Avatar Skeleton - For circular avatars
 */
export const SkeletonAvatar: React.FC<Omit<SkeletonProps, 'variant'>> = ({
  width = 40,
  height = 40,
  ...props
}) => {
  return <Skeleton variant="circular" width={width} height={height} {...props} />;
};

/**
 * Card Skeleton - For card layouts
 */
export const SkeletonCard: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={cn('bg-white rounded-xl border border-gray-200 p-6', className)}>
      <div className="flex items-center gap-4 mb-4">
        <SkeletonAvatar />
        <div className="flex-1 space-y-2">
          <SkeletonText width="60%" />
          <SkeletonText width="40%" className="h-3" />
        </div>
      </div>
      <div className="space-y-2">
        <SkeletonText width="100%" />
        <SkeletonText width="90%" />
        <SkeletonText width="75%" />
      </div>
    </div>
  );
};

/**
 * Table Row Skeleton
 */
export const SkeletonTableRow: React.FC = () => {
  return (
    <tr className="border-b border-gray-200">
      {[1, 2, 3, 4, 5].map((i) => (
        <td key={i} className="px-6 py-4">
          <SkeletonText />
        </td>
      ))}
    </tr>
  );
};

/**
 * List Item Skeleton
 */
export const SkeletonListItem: React.FC = () => {
  return (
    <div className="flex items-center gap-4 p-4 border-b border-gray-200">
      <SkeletonAvatar width={48} height={48} />
      <div className="flex-1 space-y-2">
        <SkeletonText width="70%" />
        <SkeletonText width="50%" className="h-3" />
      </div>
      <Skeleton width={80} height={32} variant="rounded" />
    </div>
  );
};

export default Skeleton;

