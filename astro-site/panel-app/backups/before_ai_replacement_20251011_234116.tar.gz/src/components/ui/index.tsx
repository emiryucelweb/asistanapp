// Modern UI Components - Barrel Exports
import * as React from "react"
export { Button } from './button'

// Fallback components for missing UI elements
export const Card = ({ children, className, ...props }: any) => (
  <div className={`bg-white rounded-lg border shadow-sm ${className || ''}`} {...props}>
    {children}
  </div>
)

export const CardHeader = ({ children, className, ...props }: any) => (
  <div className={`flex flex-col space-y-1.5 p-6 ${className || ''}`} {...props}>
    {children}
  </div>
)

export const CardContent = ({ children, className, ...props }: any) => (
  <div className={`p-6 pt-0 ${className || ''}`} {...props}>
    {children}
  </div>
)

export const CardFooter = ({ children, className, ...props }: any) => (
  <div className={`flex items-center p-6 pt-0 ${className || ''}`} {...props}>
    {children}
  </div>
)

export const Input = ({ className, type = "text", ...props }: any) => (
  <input 
    type={type}
    className={`flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className || ''}`}
    {...props}
  />
)

export const Badge = ({ children, className, variant = "default", ...props }: any) => {
  const variants = {
    default: "bg-primary text-primary-foreground hover:bg-primary/80",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/80",
    outline: "text-foreground border border-input bg-background hover:bg-accent hover:text-accent-foreground",
  }
  
  return (
    <div className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 ${variants[variant] || variants.default} ${className || ''}`} {...props}>
      {children}
    </div>
  )
}

// Simplified component stubs that work
export const Switch = ({ checked, onCheckedChange, disabled, ...props }: any) => (
  <button
    role="switch"
    aria-checked={checked}
    onClick={() => !disabled && onCheckedChange?.(!checked)}
    className={`peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 ${checked ? 'bg-primary' : 'bg-input'}`}
    disabled={disabled}
    {...props}
  >
    <span className={`pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
  </button>
)

export const Slider = ({ value = [0], onValueChange, min = 0, max = 100, step = 1, className, ...props }: any) => (
  <div className={`relative flex w-full touch-none select-none items-center ${className || ''}`} {...props}>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value[0]}
      onChange={(e) => onValueChange?.([Number(e.target.value)])}
      className="flex-1 bg-transparent"
    />
  </div>
)

export const Select = ({ children, onValueChange, defaultValue, value, ...props }: any) => {
  const [internalValue, setInternalValue] = React.useState(defaultValue || value || "")
  
  const handleChange = (newValue: string) => {
    setInternalValue(newValue)
    onValueChange?.(newValue)
  }
  
  return (
    <div className="relative" {...props}>
      {React.Children.map(children, child => 
        React.isValidElement(child) 
          ? React.cloneElement(child, { onValueChange: handleChange, value: value || internalValue } as any)
          : child
      )}
    </div>
  )
}

export const SelectContent = ({ children, ...props }: any) => (
  <div className="relative z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md" {...props}>
    {children}
  </div>
)

export const SelectItem = ({ children, value, onSelect, ...props }: any) => (
  <div 
    className="relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none hover:bg-accent hover:text-accent-foreground"
    onClick={() => onSelect?.(value)}
    {...props}
  >
    {children}
  </div>
)

export const SelectTrigger = ({ children, className, ...props }: any) => (
  <button
    className={`flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className || ''}`}
    {...props}
  >
    {children}
  </button>
)

export const SelectValue = ({ placeholder, value, ...props }: any) => (
  <span className="block truncate" {...props}>
    {value || placeholder}
  </span>
)

// Tab components
export const Tabs = ({ children, defaultValue, value, onValueChange, ...props }: any) => {
  const [activeTab, setActiveTab] = React.useState(defaultValue || value)
  
  const handleTabChange = (newValue: string) => {
    setActiveTab(newValue)
    onValueChange?.(newValue)
  }
  
  return (
    <div {...props}>
      {React.Children.map(children, child =>
        React.isValidElement(child)
          ? React.cloneElement(child, { activeTab: value || activeTab, onTabChange: handleTabChange } as any)
          : child
      )}
    </div>
  )
}

export const TabsList = ({ children, className, activeTab, onTabChange, ...props }: any) => (
  <div className={`inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground ${className || ''}`} {...props}>
    {React.Children.map(children, child =>
      React.isValidElement(child)
        ? React.cloneElement(child, { activeTab, onTabChange } as any)
        : child
    )}
  </div>
)

export const TabsTrigger = ({ children, value, activeTab, onTabChange, className, ...props }: any) => (
  <button
    className={`inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 ${activeTab === value ? 'bg-background text-foreground shadow-sm' : ''} ${className || ''}`}
    onClick={() => onTabChange?.(value)}
    {...props}
  >
    {children}
  </button>
)

export const TabsContent = ({ children, value, activeTab, className, ...props }: any) => 
  activeTab === value ? (
    <div className={`mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${className || ''}`} {...props}>
      {children}
    </div>
  ) : null

// Simple implementations for missing components
export const Tooltip = ({ children }: any) => <>{children}</>
export const TooltipContent = ({ children, className, ...props }: any) => (
  <div className={`z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md ${className || ''}`} {...props}>
    {children}
  </div>
)
export const TooltipProvider = ({ children }: any) => <>{children}</>
export const TooltipTrigger = ({ children }: any) => <>{children}</>

export const Modal = ({ children, open, onOpenChange }: any) => 
  open ? (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed left-[50%] top-[50%] z-50 translate-x-[-50%] translate-y-[-50%]">
        {children}
      </div>
    </div>
  ) : null

export const ModalContent = ({ children, className, ...props }: any) => (
  <div className={`grid w-full max-w-lg gap-4 border bg-background p-6 shadow-lg duration-200 sm:rounded-lg ${className || ''}`} {...props}>
    {children}
  </div>
)

export const ModalHeader = ({ children, className, ...props }: any) => (
  <div className={`flex flex-col space-y-1.5 text-center sm:text-left ${className || ''}`} {...props}>
    {children}
  </div>
)

export const ModalFooter = ({ children, className, ...props }: any) => (
  <div className={`flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 ${className || ''}`} {...props}>
    {children}
  </div>
)

export const Popover = ({ children }: any) => <>{children}</>
export const PopoverContent = ({ children, className, ...props }: any) => (
  <div className={`z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none ${className || ''}`} {...props}>
    {children}
  </div>
)
export const PopoverTrigger = ({ children }: any) => <>{children}</>

export const DateRangePicker = ({ value, onChange, placeholder = "Pick a date range", className, ...props }: any) => (
  <div className={`grid gap-2 ${className || ''}`}>
    <input
      type="date"
      value={value?.from || ""}
      onChange={(e) => onChange?.({ from: e.target.value, to: value?.to })}
      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
      placeholder={placeholder}
      {...props}
    />
    <input
      type="date"
      value={value?.to || ""}
      onChange={(e) => onChange?.({ from: value?.from, to: e.target.value })}
      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
      placeholder="To date"
    />
  </div>
)

