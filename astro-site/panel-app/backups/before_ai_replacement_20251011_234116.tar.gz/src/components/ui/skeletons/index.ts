/**
 * Skeleton Components Index
 */
export { default as DashboardSkeleton } from './DashboardSkeleton';
export { default as ConversationsSkeleton } from './ConversationsSkeleton';

