/**
 * Conversations Page Skeleton
 * Loading state for conversations list
 */
import React from 'react';
import Skeleton, { SkeletonAvatar, SkeletonText } from '../Skeleton';

const ConversationsSkeleton: React.FC = () => {
  return (
    <div className="flex flex-col max-w-[1600px] mx-auto px-8 py-6 gap-6">
      {/* Header Skeleton */}
      <div className="flex justify-between items-center">
        <Skeleton width={250} height={32} className="rounded-lg" />
        <Skeleton width={200} height={40} className="rounded-lg" />
      </div>

      {/* Tabs Skeleton */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex gap-8 px-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} width={120} height={40} className="rounded-t-lg" />
          ))}
        </div>
      </div>

      {/* Conversations List Skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* List */}
        <div className="lg:col-span-1 bg-white rounded-xl border border-gray-200 p-4">
          <div className="mb-4">
            <Skeleton width="100%" height={40} className="rounded-lg" />
          </div>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="p-3 border-b border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <SkeletonAvatar width={40} height={40} />
                  <div className="flex-1 space-y-2">
                    <SkeletonText width="70%" />
                    <SkeletonText width="90%" className="h-3" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detail */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200">
          {/* Header */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <SkeletonAvatar width={48} height={48} />
                <div className="space-y-2">
                  <SkeletonText width={150} />
                  <SkeletonText width={100} className="h-3" />
                </div>
              </div>
              <Skeleton width={120} height={36} className="rounded-lg" />
            </div>
          </div>

          {/* Messages */}
          <div className="p-6 space-y-4 min-h-[400px]">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={`flex gap-3 ${i % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                {i % 2 === 1 && <SkeletonAvatar width={32} height={32} />}
                <div className={`max-w-[70%] space-y-2 ${i % 2 === 0 ? 'items-end' : 'items-start'}`}>
                  <Skeleton width={Math.random() * 200 + 150} height={60} className="rounded-lg" />
                  <SkeletonText width={80} className="h-2" />
                </div>
                {i % 2 === 0 && <SkeletonAvatar width={32} height={32} />}
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200">
            <Skeleton width="100%" height={44} className="rounded-lg" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConversationsSkeleton;

