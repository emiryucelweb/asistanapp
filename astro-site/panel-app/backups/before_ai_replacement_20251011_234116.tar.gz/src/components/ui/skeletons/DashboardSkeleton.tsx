/**
 * Dashboard Page Skeleton
 * Loading state for dashboard
 */
import React from 'react';
import Skeleton, { SkeletonText, SkeletonCard } from '../Skeleton';

const DashboardSkeleton: React.FC = () => {
  return (
    <div className="flex flex-col w-full">
      {/* Header Skeleton */}
      <div className="flex flex-wrap justify-between gap-3 p-4">
        <div className="flex min-w-72 flex-col gap-3">
          <Skeleton width={200} height={40} className="rounded-lg" />
          <Skeleton width={300} height={20} className="rounded-lg" />
        </div>
        <Skeleton width={200} height={44} className="rounded-lg" />
      </div>

      {/* KPI Cards Skeleton */}
      <div className="flex flex-wrap gap-4 p-4">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="flex min-w-[158px] flex-1 flex-col gap-2 rounded-xl p-6 border border-[#d0d9e7]"
          >
            <Skeleton width="60%" height={20} className="rounded" />
            <Skeleton width="80%" height={32} className="rounded" />
            <Skeleton width="40%" height={20} className="rounded" />
          </div>
        ))}
      </div>

      {/* Section Title */}
      <div className="px-4 pb-3 pt-5">
        <Skeleton width={150} height={28} className="rounded-lg" />
      </div>

      {/* Trend Charts Skeleton */}
      <div className="flex flex-wrap gap-4 px-4 py-6">
        {[1, 2].map((i) => (
          <div key={i} className="flex min-w-72 flex-1 flex-col gap-2 rounded-xl border border-[#d0d9e7] p-6">
            <Skeleton width="50%" height={20} className="rounded" />
            <Skeleton width="70%" height={36} className="rounded" />
            <div className="flex gap-1 mt-2">
              <Skeleton width={100} height={20} className="rounded" />
              <Skeleton width={60} height={20} className="rounded" />
            </div>
            <Skeleton width="100%" height={180} className="rounded-lg mt-4" />
          </div>
        ))}
      </div>

      {/* AI Performance Skeleton */}
      <div className="flex flex-wrap gap-4 px-4 py-6">
        <div className="flex min-w-72 flex-1 flex-col gap-2 rounded-xl border border-[#d0d9e7] p-6">
          <Skeleton width="60%" height={20} className="rounded" />
          <Skeleton width="50%" height={36} className="rounded" />
          <Skeleton width="100%" height={200} className="rounded-lg mt-4" />
        </div>
      </div>

      {/* Section Title */}
      <div className="px-4 pb-3 pt-5">
        <Skeleton width={150} height={28} className="rounded-lg" />
      </div>

      {/* Alerts Skeleton */}
      <div className="flex flex-col">
        {[1, 2].map((i) => (
          <div key={i} className="flex items-center gap-4 bg-slate-50 px-4 min-h-[72px] py-2">
            <Skeleton width={48} height={48} variant="circular" />
            <div className="flex flex-col justify-center gap-2 flex-1">
              <Skeleton width="40%" height={20} className="rounded" />
              <Skeleton width="20%" height={16} className="rounded" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DashboardSkeleton;

