/* =========================================
   AsistanApp - Module Guard Component
   Sektöre uygun olmayan modülleri kontrol eder
========================================= */

import React from 'react';
import { useBusiness } from '../../contexts/BusinessContext';
import DisabledModulePage from '../../pages/DisabledModulePage';

interface ModuleGuardProps {
  children: React.ReactNode;
  moduleId: string;
}

const ModuleGuard: React.FC<ModuleGuardProps> = ({ children, moduleId }) => {
  const { enabledModules, isLoading } = useBusiness();
  
  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  // Bu modülün etkin olup olmadığını kontrol et
  const isModuleEnabled = enabledModules.find(
    module => module.id === moduleId
  )?.enabled ?? false;
  
  console.log('🛡️ ModuleGuard check:', { moduleId, isModuleEnabled, availableModules: enabledModules.length });
  
  if (!isModuleEnabled) {
    return <DisabledModulePage />;
  }
  
  return <>{children}</>;
};

export default ModuleGuard;
