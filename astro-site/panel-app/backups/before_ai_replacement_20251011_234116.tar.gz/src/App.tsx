import React, { Suspense, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { QueryClientProvider } from 'react-query';
import { Toaster } from 'react-hot-toast';

// Components
import LoadingSpinner from './components/ui/LoadingSpinner';
import MainLayout from './components/layout/MainLayout';
import ProtectedRoute from './components/auth/ProtectedRoute';
import PublicRoute from './components/auth/PublicRoute';
import ErrorBoundary from './components/error/ErrorBoundary';

// Hooks
import { useAuthStore } from './stores/auth-store';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import { useWebSocket } from './hooks/useWebSocket';

// Contexts
import { BusinessProvider } from './contexts/BusinessContext';

// React Query
import { queryClient } from './lib/react-query/queryClient';

// Pages
const LoginPage = React.lazy(() => import('./pages/auth/LoginPage'));
const ForgotPasswordPage = React.lazy(() => import('./pages/auth/ForgotPasswordPage'));
const AdminLoginPage = React.lazy(() => import('./pages/auth/AdminLoginPage'));
const AdminForgotPasswordPage = React.lazy(() => import('./pages/auth/AdminForgotPasswordPage'));
const AgentLoginPage = React.lazy(() => import('./pages/auth/AgentLoginPage'));
const AgentForgotPasswordPage = React.lazy(() => import('./pages/auth/AgentForgotPasswordPage'));
const DashboardPage = React.lazy(() => import('./pages/dashboard/DashboardPage'));
const ConversationsPage = React.lazy(() => import('./pages/conversations/ConversationsPage'));
const ReportsPage = React.lazy(() => import('./pages/reports/ReportsPage'));
const SettingsPage = React.lazy(() => import('./pages/settings/SettingsPage'));
const TeamPage = React.lazy(() => import('./pages/team/TeamPage'));
const TeamChatPage = React.lazy(() => import('./pages/team/TeamChatPage'));
const HelpPage = React.lazy(() => import('./pages/help/HelpPage'));
const NotFoundPage = React.lazy(() => import('./pages/error/NotFoundPage'));
const ServerErrorPage = React.lazy(() => import('./pages/error/ServerErrorPage'));

// Agent Pages
const AgentDashboard = React.lazy(() => import('./pages/agent/dashboard/AgentDashboard'));
const AgentConversations = React.lazy(() => import('./pages/agent/conversations/AgentConversations'));
const AgentProfile = React.lazy(() => import('./pages/agent/profile/AgentProfile'));
const AgentAIChatPage = React.lazy(() => import('./pages/agent/ai-chat/AgentAIChatPage'));

// Super Admin Pages
const AdminDashboard = React.lazy(() => import('./pages/admin/AdminDashboard'));
const AdminUsers = React.lazy(() => import('./pages/admin/AdminUsers'));
const AdminAnalytics = React.lazy(() => import('./pages/admin/AdminAnalytics'));
const AdminSystem = React.lazy(() => import('./pages/admin/AdminSystem'));
const AdminSettings = React.lazy(() => import('./pages/admin/AdminSettings'));
const TenantsPage = React.lazy(() => import('./pages/tenants/TenantsPage'));
const TenantDetailPage = React.lazy(() => import('./pages/tenants/TenantDetailPage'));
const FinancialReportsPage = React.lazy(() => import('./pages/tenants/FinancialReportsPage'));

// Agent Layout
import AgentLayout from './components/agent/layout/AgentLayout';

// Admin Layout
import AdminLayout from './components/admin/layout/AdminLayout';

// Loading component
const PageLoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen">
    <LoadingSpinner size="lg" />
  </div>
);

function App() {
  console.log('🚀 App rendering...');
  const { isLoading, initializeAuth } = useAuthStore();

  // Initialize keyboard shortcuts
  useKeyboardShortcuts();

  // Initialize WebSocket for real-time notifications
  useWebSocket();

  useEffect(() => {
    console.log('🔧 Initializing auth...');
    initializeAuth();
  }, [initializeAuth]);

  console.log('📊 App state:', { isLoading });

  if (isLoading) {
    console.log('⏳ Showing loading spinner...');
    return <PageLoadingSpinner />;
  }

  console.log('✅ Rendering main app...');
  
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <div className="App">
          <BusinessProvider defaultBusinessType="dental_clinic">
            <Suspense fallback={<PageLoadingSpinner />}>
              <Routes>
            {/* Public routes - Firma Sahibi */}
            <Route
              path="/admin/login"
              element={
                <PublicRoute>
                  <LoginPage />
                </PublicRoute>
              }
            />
            <Route
              path="/admin/forgot-password"
              element={
                <PublicRoute>
                  <ForgotPasswordPage />
                </PublicRoute>
              }
            />

            {/* Public routes - AsistanApp Super Admin */}
            <Route
              path="/asistansuper/login"
              element={
                <PublicRoute>
                  <AdminLoginPage />
                </PublicRoute>
              }
            />
            <Route
              path="/asistansuper/forgot-password"
              element={
                <PublicRoute>
                  <AdminForgotPasswordPage />
                </PublicRoute>
              }
            />

            {/* Public routes - Agent Dashboard */}
            <Route
              path="/agent/login"
              element={
                <PublicRoute>
                  <AgentLoginPage />
                </PublicRoute>
              }
            />
            <Route
              path="/agent/forgot-password"
              element={
                <PublicRoute>
                  <AgentForgotPasswordPage />
                </PublicRoute>
              }
            />

            {/* Protected routes - Dashboard */}
            <Route
              path="/admin/dashboard"
              element={
                <ProtectedRoute>
                  <MainLayout>
                    <DashboardPage />
                  </MainLayout>
                </ProtectedRoute>
              }
            />

            {/* Protected routes - Conversations */}
            <Route
              path="/admin/conversations"
              element={
                <ProtectedRoute>
                  <MainLayout>
                    <ConversationsPage />
                  </MainLayout>
                </ProtectedRoute>
              }
            />

            {/* Protected routes - Reports */}
            <Route
              path="/admin/reports"
              element={
                <ProtectedRoute>
                  <MainLayout>
                    <ReportsPage />
                  </MainLayout>
                </ProtectedRoute>
              }
            />

            {/* Protected routes - Settings */}
            <Route
              path="/admin/settings"
              element={
                <ProtectedRoute>
                  <MainLayout>
                    <SettingsPage />
                  </MainLayout>
                </ProtectedRoute>
              }
            />

            {/* Protected routes - Team */}
            <Route
              path="/admin/team"
              element={
                <ProtectedRoute>
                  <MainLayout>
                    <TeamPage />
                  </MainLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/team/chat"
              element={
                <ProtectedRoute>
                  <TeamChatPage />
                </ProtectedRoute>
              }
            />

            {/* Protected routes - Help */}
            <Route
              path="/admin/help"
              element={
                <ProtectedRoute>
                  <MainLayout>
                    <HelpPage />
                  </MainLayout>
                </ProtectedRoute>
              }
            />

            {/* Super Admin Panel Routes */}
            <Route
              path="/asistansuper/dashboard"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <AdminDashboard />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/tenants"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <TenantsPage />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/tenants/:tenantId"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <TenantDetailPage />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/financial-reports"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <FinancialReportsPage />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/users"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <AdminUsers />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/analytics"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <AdminAnalytics />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/system"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <AdminSystem />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/asistansuper/settings"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <AdminSettings />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />

            {/* Agent Panel Routes */}
            <Route
              path="/agent/dashboard"
              element={
                <ProtectedRoute>
                  <AgentLayout>
                    <AgentDashboard />
                  </AgentLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/agent/conversations"
              element={
                <ProtectedRoute>
                  <AgentLayout>
                    <AgentConversations />
                  </AgentLayout>
                </ProtectedRoute>
              }
            />
            <Route
              path="/agent/team/chat"
              element={
                <ProtectedRoute>
                  <TeamChatPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/agent/profile"
              element={
                <ProtectedRoute>
                  <AgentLayout>
                    <AgentProfile />
                  </AgentLayout>
                </ProtectedRoute>
              }
            />

            {/* Root redirect */}
            <Route
              path="/"
              element={<Navigate to="/admin/dashboard" replace />}
            />

            {/* Error Pages */}
            <Route
              path="/error/500"
              element={<ServerErrorPage />}
            />

            {/* 404 - Catch all */}
            <Route
              path="*"
              element={<NotFoundPage />}
            />
          </Routes>
        </Suspense>
      </BusinessProvider>
      
      {/* Toast Notifications */}
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          className: 'dark:bg-slate-800 dark:text-gray-100',
          style: {
            padding: '16px',
            borderRadius: '12px',
          },
          success: {
            className: 'dark:bg-slate-800 dark:text-gray-100',
            iconTheme: {
              primary: '#10b981',
              secondary: '#fff',
            },
          },
          error: {
            className: 'dark:bg-slate-800 dark:text-gray-100',
            iconTheme: {
              primary: '#ef4444',
              secondary: '#fff',
            },
          },
        }}
      />
      </div>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
