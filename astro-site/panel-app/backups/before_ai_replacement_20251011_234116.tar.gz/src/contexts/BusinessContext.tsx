/* =========================================
   AsistanApp - Enhanced Business Context
   Kapsamlı refactor ile stabilize edildi
========================================= */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  BusinessType, 
  BusinessTypeConfig, 
  ModuleConfig,
  getBusinessTypeConfig, 
  getEnabledModules,
  isModuleEnabled,
  DEFAULT_BUSINESS_TYPE,
  detectBusinessType
} from '../config/business-types';

// Consistent localStorage key
const STORAGE_KEY = 'asistanapp_business_type';

interface BusinessContextType {
  // Current business configuration
  businessType: BusinessType;
  config: BusinessTypeConfig;
  enabledModules: ModuleConfig[];
  isLoading: boolean;
  
  // Business management
  setBusinessType: (type: BusinessType) => void;
  isModuleEnabled: (moduleId: string) => boolean;
  getTerminology: (key: keyof BusinessTypeConfig['terminology']) => string;
  
  // Auto-detection
  detectAndSetBusinessType: (businessName: string, description?: string) => BusinessType;
  resetToDefault: () => void;
}

const BusinessContext = createContext<BusinessContextType | undefined>(undefined);

interface BusinessProviderProps {
  children: ReactNode;
  defaultBusinessType?: BusinessType;
}

export const BusinessProvider: React.FC<BusinessProviderProps> = ({ 
  children, 
  defaultBusinessType = DEFAULT_BUSINESS_TYPE 
}) => {
  const [businessType, setBusinessTypeState] = useState<BusinessType>(defaultBusinessType);
  const [config, setConfig] = useState<BusinessTypeConfig>(getBusinessTypeConfig(defaultBusinessType));
  const [enabledModules, setEnabledModules] = useState<ModuleConfig[]>(getEnabledModules(defaultBusinessType));
  const [isLoading, setIsLoading] = useState(true);

  // Initialize from localStorage on mount
  useEffect(() => {
    try {
      const savedBusinessType = localStorage.getItem(STORAGE_KEY) as BusinessType;
      
      if (savedBusinessType && savedBusinessType !== businessType) {
        console.log('🔄 Loading saved business type:', savedBusinessType);
        setBusinessTypeState(savedBusinessType);
      }
    } catch (error) {
      console.warn('⚠️ Error loading business type from localStorage:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Update configuration when business type changes
  useEffect(() => {
    try {
      console.log('🏢 Business type changing to:', businessType);
      
      const newConfig = getBusinessTypeConfig(businessType);
      const newEnabledModules = getEnabledModules(businessType);
      
      setConfig(newConfig);
      setEnabledModules(newEnabledModules);
      
      // Update CSS custom properties for theming
      const root = document.documentElement;
      root.style.setProperty('--business-primary', newConfig.colors.primary);
      root.style.setProperty('--business-secondary', newConfig.colors.secondary);
      root.style.setProperty('--business-accent', newConfig.colors.accent);
      
      // Store in localStorage for persistence
      localStorage.setItem(STORAGE_KEY, businessType);
      
      console.log('✅ Business configuration updated:', {
        type: businessType,
        name: newConfig.name,
        enabledModules: newEnabledModules.length
      });
      
    } catch (error) {
      console.error('❌ Error updating business configuration:', error);
    }
  }, [businessType]);

  const setBusinessType = (type: BusinessType) => {
    console.log('🔄 Setting business type:', type);
    setBusinessTypeState(type);
    
    // Show enhanced notification
    try {
      const newConfig = getBusinessTypeConfig(type);
      const notification = document.createElement('div');
      notification.innerHTML = `
        <div style="
          position: fixed; 
          top: 20px; 
          right: 20px; 
          background: ${newConfig.colors.primary}; 
          color: white; 
          padding: 16px 24px; 
          border-radius: var(--radius-xl); 
          box-shadow: var(--shadow-xl); 
          z-index: 9999;
          font-size: var(--font-size-sm);
          font-weight: var(--font-weight-semibold);
          animation: slideIn 0.3s ease-out;
          max-width: 300px;
        ">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 18px;">${newConfig.emoji}</span>
            <div>
              <div>${newConfig.name} sektörüne geçildi!</div>
              <div style="font-size: var(--font-size-xs); opacity: 0.9; margin-top: 2px;">
                ${newConfig.description}
              </div>
            </div>
          </div>
        </div>
      `;
      
      // Add animation styles
      const style = document.createElement('style');
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
      
      document.body.appendChild(notification);
      
      // Auto remove after 4 seconds with animation
      setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => {
          try {
            document.body.removeChild(notification);
            document.head.removeChild(style);
          } catch (e) {
            // Element might already be removed
          }
        }, 300);
      }, 4000);
      
    } catch (error) {
      console.warn('⚠️ Error showing notification:', error);
    }
  };

  const checkModuleEnabled = (moduleId: string): boolean => {
    return isModuleEnabled(businessType, moduleId);
  };

  const getTerminology = (key: keyof BusinessTypeConfig['terminology']): string => {
    return config.terminology[key] || key;
  };

  const detectAndSetBusinessType = (businessName: string, description?: string): BusinessType => {
    const detectedType = detectBusinessType(businessName, description);
    console.log('🔍 Auto-detected business type:', detectedType, 'from:', businessName);
    setBusinessType(detectedType);
    return detectedType;
  };

  const resetToDefault = () => {
    console.log('🔄 Resetting to default business type:', DEFAULT_BUSINESS_TYPE);
    localStorage.removeItem(STORAGE_KEY);
    setBusinessType(DEFAULT_BUSINESS_TYPE);
  };

  const contextValue: BusinessContextType = {
    businessType,
    config,
    enabledModules,
    isLoading,
    setBusinessType,
    isModuleEnabled: checkModuleEnabled,
    getTerminology,
    detectAndSetBusinessType,
    resetToDefault
  };

  return (
    <BusinessContext.Provider value={contextValue}>
      {children}
    </BusinessContext.Provider>
  );
};

// Custom hook to use business context
export const useBusiness = (): BusinessContextType => {
  const context = useContext(BusinessContext);
  
  if (!context) {
    throw new Error('useBusiness must be used within a BusinessProvider');
  }
  
  return context;
};

// Helper hooks for common use cases
export const useBusinessConfig = (): BusinessTypeConfig => {
  const { config } = useBusiness();
  return config;
};

export const useEnabledModules = (): ModuleConfig[] => {
  const { enabledModules } = useBusiness();
  return enabledModules;
};

export const useBusinessTerminology = () => {
  const { getTerminology } = useBusiness();
  return getTerminology;
};

export const useModuleEnabled = (moduleId: string): boolean => {
  const { isModuleEnabled } = useBusiness();
  return isModuleEnabled(moduleId);
};