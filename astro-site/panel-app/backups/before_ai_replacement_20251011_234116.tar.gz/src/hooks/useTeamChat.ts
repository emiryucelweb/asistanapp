/* =========================================
   Team Chat Hook
   Agent-to-Agent Real-time Communication
========================================= */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useWebSocket } from '../services/websocket-service.jsx';
import { useBusiness } from '../providers/business-context';
import { useAuthStore } from '../stores/auth-store';

// ===========================================
// 🏗️ TYPES & INTERFACES
// ===========================================

export interface TeamChatMessage {
  id: string;
  channelId: string;
  threadId?: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  content: string;
  messageType: 'text' | 'file' | 'image' | 'customer_context' | 'system';
  mentions: string[];
  reactions: Array<{
    emoji: string;
    userId: string;
    timestamp: number;
  }>;
  attachments: Array<{
    id: string;
    name: string;
    type: string;
    size: number;
    url: string;
  }>;
  customerContext?: {
    conversationId: string;
    customerName: string;
    customerChannel: string;
    summary: string;
  };
  isEdited: boolean;
  isDeleted: boolean;
  timestamp: number;
  editedAt?: number;
}

export interface TeamChannel {
  id: string;
  name: string;
  description: string;
  type: 'public' | 'private' | 'direct';
  topic?: string;
  memberCount: number;
  messageCount: number;
  lastMessageAt?: number;
  unreadCount: number;
  isArchived: boolean;
  members?: Array<{
    userId: string;
    userName: string;
    role: 'admin' | 'member';
    joinedAt: number;
    isOnline: boolean;
  }>;
}

export interface TeamMember {
  userId: string;
  userName: string;
  avatar?: string;
  status: 'online' | 'away' | 'busy' | 'offline';
  customStatus?: string;
  currentChannel?: string;
  lastSeen: number;
}

export interface TypingIndicator {
  channelId: string;
  userId: string;
  userName: string;
  startedAt: number;
}

export interface MentionNotification {
  id: string;
  channelId: string;
  channelName: string;
  messageId: string;
  mentionedBy: string;
  mentionedByName: string;
  content: string;
  timestamp: number;
  isRead: boolean;
}

// ===========================================
// 🎯 TEAM CHAT HOOK
// ===========================================

export function useTeamChat() {
  const { business } = useBusiness();
  const { user } = useAuthStore();
  const { 
    isConnected, 
    send, 
    on, 
    off 
  } = useWebSocket();

  // ===========================================
  // 📊 STATE MANAGEMENT
  // ===========================================

  const [channels, setChannels] = useState<TeamChannel[]>([]);
  const [activeChannel, setActiveChannel] = useState<string | null>(null);
  const [messages, setMessages] = useState<Map<string, TeamChatMessage[]>>(new Map());
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [typingIndicators, setTypingIndicators] = useState<TypingIndicator[]>([]);
  const [mentionNotifications, setMentionNotifications] = useState<MentionNotification[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Typing timeout management
  const typingTimeouts = useRef<Map<string, NodeJS.Timeout>>(new Map());

  // ===========================================
  // 🔄 API FUNCTIONS
  // ===========================================

  const fetchChannels = useCallback(async () => {
    if (!business?.slug || !user?.id) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/v1/team/channels`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'X-Tenant-ID': business.slug,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch channels: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success && result.data) {
        setChannels(result.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch channels');
      console.error('Failed to fetch team channels:', err);
    } finally {
      setIsLoading(false);
    }
  }, [business?.slug, user?.id]);

  const fetchMessages = useCallback(async (channelId: string, limit = 50, offset = 0) => {
    if (!business?.slug || !channelId) return;

    try {
      const response = await fetch(
        `/api/v1/team/channels/${channelId}/messages?limit=${limit}&offset=${offset}`, 
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'X-Tenant-ID': business.slug,
          },
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to fetch messages: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success && result.data?.messages) {
        setMessages(prev => new Map(prev.set(channelId, result.data.messages)));
      }
    } catch (err) {
      console.error(`Failed to fetch messages for channel ${channelId}:`, err);
      setError(err instanceof Error ? err.message : 'Failed to fetch messages');
    }
  }, [business?.slug]);

  const createChannel = useCallback(async (channelData: {
    name: string;
    description: string;
    type?: 'public' | 'private';
    topic?: string;
  }) => {
    if (!business?.slug || !user?.id) return null;

    try {
      const response = await fetch('/api/v1/team/channels', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'X-Tenant-ID': business.slug,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(channelData),
      });

      if (!response.ok) {
        throw new Error(`Failed to create channel: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success && result.data?.channelId) {
        // Refresh channels list
        await fetchChannels();
        return result.data.channelId;
      }
    } catch (err) {
      console.error('Failed to create channel:', err);
      setError(err instanceof Error ? err.message : 'Failed to create channel');
    }

    return null;
  }, [business?.slug, user?.id, fetchChannels]);

  const joinChannel = useCallback(async (channelId: string) => {
    if (!business?.slug || !channelId) return false;

    try {
      const response = await fetch(`/api/v1/team/channels/${channelId}/join`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'X-Tenant-ID': business.slug,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to join channel: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success) {
        // Join WebSocket room
        send({
          type: 'join_team_channel',
          tenantId: business.slug || '',
          userId: user?.id || '',
          data: { channelId },
          timestamp: Date.now(),
        });
        
        // Refresh channels list
        await fetchChannels();
        
        return true;
      }
    } catch (err) {
      console.error(`Failed to join channel ${channelId}:`, err);
      setError(err instanceof Error ? err.message : 'Failed to join channel');
    }

    return false;
  }, [business?.slug, user?.id, send, fetchChannels]);

  const sendMessage = useCallback(async (channelId: string, messageData: {
    content: string;
    messageType?: 'text' | 'file' | 'image' | 'customer_context';
    threadId?: string;
    mentions?: string[];
    attachments?: TeamChatMessage['attachments'];
    customerContext?: TeamChatMessage['customerContext'];
  }) => {
    if (!business?.slug || !user?.id || !channelId) return null;

    const tempId = `temp_${Date.now()}`;
    
    // Optimistically add message to UI
    const optimisticMessage: TeamChatMessage = {
      id: tempId,
      channelId,
      threadId: messageData.threadId,
      senderId: user.id,
      senderName: user.name || 'Unknown User',
      senderAvatar: user.profile?.avatar,
      content: messageData.content,
      messageType: messageData.messageType || 'text',
      mentions: messageData.mentions || [],
      reactions: [],
      attachments: messageData.attachments || [],
      customerContext: messageData.customerContext,
      isEdited: false,
      isDeleted: false,
      timestamp: Date.now(),
    };

    // Add to local state immediately
    setMessages(prev => {
      const channelMessages = prev.get(channelId) || [];
      const newMap = new Map(prev);
      newMap.set(channelId, [...channelMessages, optimisticMessage]);
      return newMap;
    });

    try {
      const response = await fetch(`/api/v1/team/channels/${channelId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'X-Tenant-ID': business.slug,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messageData),
      });

      if (!response.ok) {
        throw new Error(`Failed to send message: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success && result.data?.messageId) {
        // Replace optimistic message with real message
        setMessages(prev => {
          const channelMessages = prev.get(channelId) || [];
          const newMap = new Map(prev);
          const updatedMessages = channelMessages.map(msg => 
            msg.id === tempId 
              ? { ...msg, id: result.data.messageId }
              : msg
          );
          newMap.set(channelId, updatedMessages);
          return newMap;
        });

        return result.data.messageId;
      }
    } catch (err) {
      // Remove optimistic message on error
      setMessages(prev => {
        const channelMessages = prev.get(channelId) || [];
        const newMap = new Map(prev);
        newMap.set(channelId, channelMessages.filter(msg => msg.id !== tempId));
        return newMap;
      });

      console.error('Failed to send team message:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message');
    }

    return null;
  }, [business?.slug, user]);

  // ===========================================
  // ⌨️ TYPING INDICATORS
  // ===========================================

  const startTyping = useCallback((channelId: string) => {
    if (!user?.id || !channelId || !isConnected) return;

    send({
      type: 'team_typing_start',
      tenantId: user.tenantId || '',
      userId: user.id,
      data: { 
        channelId,
        userId: user.id,
        userName: user.name || 'Unknown User',
      },
      timestamp: Date.now(),
    });

    // Set timeout to stop typing after 3 seconds of inactivity
    const existingTimeout = typingTimeouts.current.get(channelId);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
    }

    const newTimeout = setTimeout(() => {
      stopTyping(channelId);
    }, 3000);

    typingTimeouts.current.set(channelId, newTimeout);
  }, [user, send, isConnected]);

  const stopTyping = useCallback((channelId: string) => {
    if (!user?.id || !channelId || !isConnected) return;

    send({
      type: 'team_typing_stop',
      tenantId: user.tenantId || '',
      userId: user.id,
      data: { 
        channelId,
        userId: user.id,
        userName: user.name || 'Unknown User',
      },
      timestamp: Date.now(),
    });

    // Clear timeout
    const timeout = typingTimeouts.current.get(channelId);
    if (timeout) {
      clearTimeout(timeout);
      typingTimeouts.current.delete(channelId);
    }
  }, [user, send, isConnected]);

  // ===========================================
  // 🔔 REACTIONS & INTERACTIONS
  // ===========================================

  const addReaction = useCallback(async (channelId: string, messageId: string, emoji: string) => {
    if (!business?.slug) return false;

    try {
      const response = await fetch(`/api/v1/team/messages/${messageId}/reactions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'X-Tenant-ID': business.slug,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ channelId, emoji }),
      });

      if (!response.ok) {
        throw new Error(`Failed to add reaction: ${response.statusText}`);
      }

      const result = await response.json();
      return result.success;
    } catch (err) {
      console.error('Failed to add reaction:', err);
      setError(err instanceof Error ? err.message : 'Failed to add reaction');
      return false;
    }
  }, [business?.slug]);

  const shareCustomerContext = useCallback(async (params: {
    channelId: string;
    conversationId: string;
    customerName: string;
    customerChannel: string;
    summary: string;
  }) => {
    if (!business?.slug) return null;

    try {
      const response = await fetch('/api/v1/team/share-context', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'X-Tenant-ID': business.slug,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        throw new Error(`Failed to share context: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success && result.data?.messageId) {
        return result.data.messageId;
      }
    } catch (err) {
      console.error('Failed to share customer context:', err);
      setError(err instanceof Error ? err.message : 'Failed to share context');
    }

    return null;
  }, [business?.slug]);

  // ===========================================
  // 🔄 WEBSOCKET EVENT HANDLERS
  // ===========================================

  useEffect(() => {
    if (!isConnected) return;

    // Team message received
    const handleTeamMessageReceived = (data: any) => {
      const { channelId, message } = data;
      
      setMessages(prev => {
        const channelMessages = prev.get(channelId) || [];
        const newMap = new Map(prev);
        
        // Check if message already exists (avoid duplicates)
        if (!channelMessages.find(msg => msg.id === message.id)) {
          newMap.set(channelId, [...channelMessages, message]);
        }
        
        return newMap;
      });

      // Update channel last message time
      setChannels(prev => prev.map(channel =>
        channel.id === channelId
          ? { ...channel, lastMessageAt: message.timestamp, messageCount: channel.messageCount + 1 }
          : channel
      ));
    };

    // Team typing indicators
    const handleTeamTypingStart = (data: any) => {
      const { channelId, userId, userName } = data;
      
      setTypingIndicators(prev => {
        // Remove existing indicator for this user/channel
        const filtered = prev.filter(
          indicator => !(indicator.channelId === channelId && indicator.userId === userId)
        );
        
        // Add new indicator
        return [
          ...filtered,
          {
            channelId,
            userId,
            userName,
            startedAt: Date.now(),
          }
        ];
      });
    };

    const handleTeamTypingStop = (data: any) => {
      const { channelId, userId } = data;
      
      setTypingIndicators(prev => 
        prev.filter(
          indicator => !(indicator.channelId === channelId && indicator.userId === userId)
        )
      );
    };

    // Team presence updates
    const handleTeamUserPresence = (data: any) => {
      const { userId, presence } = data;
      
      setTeamMembers(prev => prev.map(member =>
        member.userId === userId
          ? {
              ...member,
              status: presence.status,
              customStatus: presence.customStatus,
              currentChannel: presence.currentChannel,
              lastSeen: presence.lastSeen,
            }
          : member
      ));
    };

    // Team mention notifications
    const handleTeamMentionNotification = (data: any) => {
      const notification: MentionNotification = {
        id: `mention_${Date.now()}`,
        channelId: data.channelId,
        channelName: data.channelName,
        messageId: data.message.id,
        mentionedBy: data.message.senderId,
        mentionedByName: data.message.senderName,
        content: data.message.content,
        timestamp: data.timestamp,
        isRead: false,
      };
      
      setMentionNotifications(prev => [notification, ...prev]);
    };

    // Team message reactions
    const handleTeamMessageReaction = (data: any) => {
      const { channelId, messageId, userId, userName, emoji, action } = data;
      
      setMessages(prev => {
        const channelMessages = prev.get(channelId) || [];
        const newMap = new Map(prev);
        
        const updatedMessages = channelMessages.map(message => {
          if (message.id === messageId) {
            let updatedReactions = [...message.reactions];
            
            if (action === 'added') {
              // Remove existing reaction from this user with this emoji (toggle)
              updatedReactions = updatedReactions.filter(
                reaction => !(reaction.userId === userId && reaction.emoji === emoji)
              );
              // Add new reaction
              updatedReactions.push({
                emoji,
                userId,
                timestamp: Date.now(),
              });
            } else {
              // Remove reaction
              updatedReactions = updatedReactions.filter(
                reaction => !(reaction.userId === userId && reaction.emoji === emoji)
              );
            }
            
            return { ...message, reactions: updatedReactions };
          }
          return message;
        });
        
        newMap.set(channelId, updatedMessages);
        return newMap;
      });
    };

    // Register event listeners
    on('team_message_received', handleTeamMessageReceived);
    on('team_typing_start', handleTeamTypingStart);
    on('team_typing_stop', handleTeamTypingStop);
    on('team_user_presence', handleTeamUserPresence);
    on('team_mention_notification', handleTeamMentionNotification);
    on('team_message_reaction', handleTeamMessageReaction);

    // Cleanup function
    return () => {
      off('team_message_received', handleTeamMessageReceived);
      off('team_typing_start', handleTeamTypingStart);
      off('team_typing_stop', handleTeamTypingStop);
      off('team_user_presence', handleTeamUserPresence);
      off('team_mention_notification', handleTeamMentionNotification);
      off('team_message_reaction', handleTeamMessageReaction);
    };
  }, [isConnected, on, off]);

  // Auto-cleanup typing indicators
  useEffect(() => {
    const cleanupInterval = setInterval(() => {
      const now = Date.now();
      setTypingIndicators(prev => 
        prev.filter(indicator => now - indicator.startedAt < 5000) // Remove indicators older than 5 seconds
      );
    }, 1000);

    return () => clearInterval(cleanupInterval);
  }, []);

  // ===========================================
  // 🏁 INITIALIZATION
  // ===========================================

  useEffect(() => {
    if (business?.slug && user?.id && isConnected) {
      fetchChannels();
    }
  }, [business?.slug, user?.id, isConnected, fetchChannels]);

  // ===========================================
  // 🎯 RETURN HOOK API
  // ===========================================

  return {
    // State
    channels,
    activeChannel,
    messages: messages.get(activeChannel || '') || [],
    teamMembers,
    typingIndicators: typingIndicators.filter(
      indicator => indicator.channelId === activeChannel
    ),
    mentionNotifications,
    isLoading,
    error,
    isConnected,

    // Actions
    setActiveChannel,
    fetchChannels,
    fetchMessages,
    createChannel,
    joinChannel,
    sendMessage,
    shareCustomerContext,
    addReaction,
    startTyping,
    stopTyping,

    // Computed values
    channelMessages: (channelId: string) => messages.get(channelId) || [],
    unreadCount: mentionNotifications.filter(n => !n.isRead).length,
    
    // Mark notification as read
    markNotificationRead: (notificationId: string) => {
      setMentionNotifications(prev => 
        prev.map(notification => 
          notification.id === notificationId
            ? { ...notification, isRead: true }
            : notification
        )
      );
    },

    // Clear error
    clearError: () => setError(null),
  };
}

export default useTeamChat;
