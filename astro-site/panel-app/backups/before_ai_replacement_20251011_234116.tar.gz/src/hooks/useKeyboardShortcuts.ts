/**
 * Global Keyboard Shortcuts Hook
 * Centralized keyboard shortcut management
 */
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useThemeStore } from '../stores/theme-store';

export const useKeyboardShortcuts = () => {
  const navigate = useNavigate();
  const { toggleTheme } = useThemeStore();

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Ctrl/Cmd + K: Search (future implementation)
      if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        // Future: Open global search modal
        console.log('🔍 Global search (to be implemented)');
      }

      // Ctrl/Cmd + D: Toggle Dark Mode
      if ((event.ctrlKey || event.metaKey) && event.key === 'd') {
        event.preventDefault();
        toggleTheme();
      }

      // Ctrl/Cmd + 1-6: Navigate to pages
      if ((event.ctrlKey || event.metaKey) && event.key >= '1' && event.key <= '6') {
        event.preventDefault();
        const routes = [
          '/dashboard',
          '/conversations',
          '/reports',
          '/settings',
          '/team',
          '/help'
        ];
        const index = parseInt(event.key) - 1;
        if (routes[index]) {
          navigate(routes[index]);
        }
      }

      // Escape: Close modals/dropdowns (to be implemented in components)
      if (event.key === 'Escape') {
        // Components will listen to this event
        const escapeEvent = new CustomEvent('closeAllDropdowns');
        window.dispatchEvent(escapeEvent);
      }

      // ? : Show keyboard shortcuts help (future)
      if (event.key === '?' && !event.shiftKey) {
        event.preventDefault();
        // Future: Show shortcuts modal
        console.log('⌨️ Keyboard shortcuts help (to be implemented)');
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate, toggleTheme]);
};

export const KEYBOARD_SHORTCUTS = {
  search: 'Ctrl/Cmd + K',
  darkMode: 'Ctrl/Cmd + D',
  dashboard: 'Ctrl/Cmd + 1',
  conversations: 'Ctrl/Cmd + 2',
  reports: 'Ctrl/Cmd + 3',
  settings: 'Ctrl/Cmd + 4',
  team: 'Ctrl/Cmd + 5',
  help: 'Ctrl/Cmd + 6',
  closeModal: 'Esc',
  showHelp: '?'
};


